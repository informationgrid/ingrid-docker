-- MySQL dump 10.13  Distrib 5.6.39, for Linux (x86_64)
--
-- Host: localhost    Database: ingrid_portal
-- ------------------------------------------------------
-- Server version	5.6.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ingrid_portal`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ingrid_portal` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ingrid_portal`;

--
-- Table structure for table `admin_activity`
--

DROP TABLE IF EXISTS `admin_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_activity` (
  `ACTIVITY` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CATEGORY` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADMIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_STAMP` datetime DEFAULT NULL,
  `IPADDRESS` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_VALUE_BEFORE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_VALUE_AFTER` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_activity`
--

LOCK TABLES `admin_activity` WRITE;
/*!40000 ALTER TABLE `admin_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capability`
--

DROP TABLE IF EXISTS `capability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capability` (
  `CAPABILITY_ID` int(11) NOT NULL,
  `CAPABILITY` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CAPABILITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capability`
--

LOCK TABLES `capability` WRITE;
/*!40000 ALTER TABLE `capability` DISABLE KEYS */;
INSERT INTO `capability` VALUES (1,'HTML_3_2'),(2,'HTML_4_0'),(3,'HTML_ACTIVEX'),(4,'HTML_CSS1'),(5,'HTML_CSS2'),(6,'HTML_CSSP'),(7,'HTML_DOM'),(8,'HTML_DOM_1'),(9,'HTML_DOM_2'),(10,'HTML_DOM_IE'),(11,'HTML_DOM_NS4'),(12,'HTML_FORM'),(13,'HTML_FRAME'),(14,'HTML_IFRAME'),(15,'HTML_IMAGE'),(16,'HTML_JAVA'),(17,'HTML_JAVA_JRE'),(18,'HTML_JAVA1_0'),(19,'HTML_JAVA1_1'),(20,'HTML_JAVA1_2'),(21,'HTML_JAVASCRIPT'),(22,'HTML_JAVASCRIPT_1_0'),(23,'HTML_JAVASCRIPT_1_1'),(24,'HTML_JAVASCRIPT_1_2'),(25,'HTML_JSCRIPT'),(26,'HTML_JSCRIPT1_0'),(27,'HTML_JSCRIPT1_1'),(28,'HTML_JSCRIPT1_2'),(29,'HTML_LAYER'),(30,'HTML_NESTED_TABLE'),(31,'HTML_PLUGIN'),(32,'HTML_TABLE'),(33,'HTML_XML'),(34,'HTML_XSL'),(35,'HTTP_1_1'),(36,'HTTP_COOKIE'),(37,'WML_1_0'),(38,'WML_1_1'),(39,'WML_TABLE'),(40,'XML_XINCLUDE'),(41,'XML_XPATH'),(42,'XML_XSLT');
/*!40000 ALTER TABLE `capability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `CLIENT_ID` int(11) NOT NULL,
  `EVAL_ORDER` int(11) NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `USER_AGENT_PATTERN` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MANUFACTURER` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODEL` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFERRED_MIMETYPE_ID` int(11) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,1,'ie5mac','.*MSIE 5.*Mac.*','Microsoft','None','5.*',2),(2,2,'safari','.*Mac.*Safari.*','Apple','None','5.*',2),(3,3,'ie6','.*MSIE 6.*','Microsoft','None','6.0',2),(4,4,'ie5','.*MSIE 5.*','Microsoft','None','5.5',2),(5,5,'ns4','.*Mozilla/4.*','Netscape','None','4.75',2),(6,6,'mozilla','.*Mozilla/5.*','Mozilla','Mozilla','1.x',2),(7,7,'lynx','Lynx.*','GNU','None','',2),(8,8,'nokia_generic','Nokia.*','Nokia','Generic','',3),(9,9,'xhtml-basic','DoCoMo/2.0.*|KDDI-.*UP.Browser.*|J-PHONE/5.0.*|Vodafone/1.0/.*','WAP','Generic','',1),(10,10,'up','UP.*|.*UP.Browser.*','United Planet','Generic','',3),(11,11,'sonyericsson','Ercis.*|SonyE.*','SonyEricsson','Generic','',3),(12,12,'wapalizer','Wapalizer.*','Wapalizer','Generic','',3),(13,13,'klondike','Klondike.*','Klondike','Generic','',3),(14,14,'wml_generic','.*WML.*|.*WAP.*|.*Wap.*|.*wml.*','Generic','Generic','',3),(15,15,'vxml_generic','.*VoiceXML.*','Generic','Generic','',4),(16,16,'nuance','Nuance.*','Nuance','Generic','',4),(17,17,'agentxml','agentxml/1.0.*','Unknown','Generic','',6),(18,18,'opera7','.*Opera/7.*','Opera','Opera7','7.x',2);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_to_capability`
--

DROP TABLE IF EXISTS `client_to_capability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_to_capability` (
  `CLIENT_ID` int(11) NOT NULL,
  `CAPABILITY_ID` int(11) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`CAPABILITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_to_capability`
--

LOCK TABLES `client_to_capability` WRITE;
/*!40000 ALTER TABLE `client_to_capability` DISABLE KEYS */;
INSERT INTO `client_to_capability` VALUES (1,1),(1,4),(1,11),(1,12),(1,13),(1,15),(1,16),(1,21),(1,31),(1,32),(1,36),(2,1),(2,3),(2,4),(2,5),(2,6),(2,10),(2,12),(2,13),(2,14),(2,15),(2,16),(2,21),(2,30),(2,32),(2,36),(3,1),(3,3),(3,4),(3,5),(3,6),(3,10),(3,12),(3,13),(3,14),(3,15),(3,16),(3,21),(3,30),(3,32),(3,36),(4,1),(4,3),(4,4),(4,5),(4,6),(4,10),(4,12),(4,13),(4,14),(4,15),(4,16),(4,21),(4,30),(4,32),(4,36),(5,1),(5,4),(5,11),(5,12),(5,13),(5,15),(5,16),(5,21),(5,29),(5,31),(5,32),(5,36),(6,1),(6,2),(6,4),(6,5),(6,6),(6,8),(6,12),(6,13),(6,14),(6,15),(6,16),(6,17),(6,21),(6,30),(6,31),(6,32),(6,36),(7,12),(7,13),(7,30),(7,32),(7,36),(18,1),(18,2),(18,4),(18,5),(18,6),(18,8),(18,12),(18,13),(18,14),(18,15),(18,16),(18,17),(18,21),(18,30),(18,31),(18,32),(18,36);
/*!40000 ALTER TABLE `client_to_capability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_to_mimetype`
--

DROP TABLE IF EXISTS `client_to_mimetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_to_mimetype` (
  `CLIENT_ID` int(11) NOT NULL,
  `MIMETYPE_ID` int(11) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`MIMETYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_to_mimetype`
--

LOCK TABLES `client_to_mimetype` WRITE;
/*!40000 ALTER TABLE `client_to_mimetype` DISABLE KEYS */;
INSERT INTO `client_to_mimetype` VALUES (1,2),(2,2),(2,5),(2,6),(3,2),(3,5),(3,6),(4,2),(4,6),(5,2),(6,2),(6,5),(6,6),(7,2),(8,3),(9,1),(10,3),(11,3),(12,3),(13,3),(14,3),(15,4),(16,4),(17,6),(18,2),(18,5),(18,6);
/*!40000 ALTER TABLE `client_to_mimetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clubs`
--

DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clubs` (
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `COUNTRY` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `CITY` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `STADIUM` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CAPACITY` int(11) DEFAULT NULL,
  `FOUNDED` int(11) DEFAULT NULL,
  `PITCH` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NICKNAME` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clubs`
--

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_portlet_mode`
--

DROP TABLE IF EXISTS `custom_portlet_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_portlet_mode` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `CUSTOM_NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `MAPPED_NAME` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PORTAL_MANAGED` smallint(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_portlet_mode`
--

LOCK TABLES `custom_portlet_mode` WRITE;
/*!40000 ALTER TABLE `custom_portlet_mode` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_portlet_mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_window_state`
--

DROP TABLE IF EXISTS `custom_window_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_window_state` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `CUSTOM_NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `MAPPED_NAME` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_window_state`
--

LOCK TABLES `custom_window_state` WRITE;
/*!40000 ALTER TABLE `custom_window_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_window_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_alias`
--

DROP TABLE IF EXISTS `event_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_alias` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_alias`
--

LOCK TABLES `event_alias` WRITE;
/*!40000 ALTER TABLE `event_alias` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_definition`
--

DROP TABLE IF EXISTS `event_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_definition` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_definition`
--

LOCK TABLES `event_definition` WRITE;
/*!40000 ALTER TABLE `event_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_lifecycle`
--

DROP TABLE IF EXISTS `filter_lifecycle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_lifecycle` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_lifecycle`
--

LOCK TABLES `filter_lifecycle` WRITE;
/*!40000 ALTER TABLE `filter_lifecycle` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_lifecycle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_mapping`
--

DROP TABLE IF EXISTS `filter_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_mapping` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `FILTER_NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_mapping`
--

LOCK TABLES `filter_mapping` WRITE;
/*!40000 ALTER TABLE `filter_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filtered_portlet`
--

DROP TABLE IF EXISTS `filtered_portlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filtered_portlet` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filtered_portlet`
--

LOCK TABLES `filtered_portlet` WRITE;
/*!40000 ALTER TABLE `filtered_portlet` DISABLE KEYS */;
/*!40000 ALTER TABLE `filtered_portlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder`
--

DROP TABLE IF EXISTS `folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder` (
  `FOLDER_ID` int(11) NOT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `PATH` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_HIDDEN` smallint(6) NOT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_LAYOUT_DECORATOR` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_PORTLET_DECORATOR` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_PAGE_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSITE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MEDIATYPE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_NAME` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_VALUE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OWNER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`FOLDER_ID`),
  UNIQUE KEY `UN_FOLDER_1` (`PATH`),
  KEY `IX_FOLDER_1` (`PARENT_ID`),
  CONSTRAINT `FK_FOLDER_1` FOREIGN KEY (`PARENT_ID`) REFERENCES `folder` (`FOLDER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder`
--

LOCK TABLES `folder` WRITE;
/*!40000 ALTER TABLE `folder` DISABLE KEYS */;
INSERT INTO `folder` VALUES (1,NULL,'/','/','Root Folder','Root Folder',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,'/_role','_role','Role','Role',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,2,'/_role/user','user','User','User',0,NULL,NULL,NULL,NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(4,1,'/_user','_user','User','User',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,4,'/_user/mdek','mdek','Template','Template',0,NULL,NULL,NULL,NULL,NULL,'mdek',NULL,NULL,NULL,NULL,NULL,NULL,'mdek'),(6,4,'/_user/noqa','noqa','Template','Template',0,NULL,NULL,NULL,NULL,NULL,'noqa',NULL,NULL,NULL,NULL,NULL,NULL,'noqa'),(7,4,'/_user/qa','qa','Template','Template',0,NULL,NULL,NULL,NULL,NULL,'qa',NULL,NULL,NULL,NULL,NULL,NULL,'qa'),(8,4,'/_user/template','template','Template','Template',0,NULL,NULL,NULL,NULL,NULL,'template',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,1,'/administration','administration','ingrid.page.administration','ingrid.page.administration',0,NULL,NULL,NULL,'admin-cms.psml',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,1,'/application','application','ingrid.page.application','ingrid.page.application',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,1,'/cms','cms','ingrid.page.cms','ingrid.page.cms',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,1,'/mdek','mdek','ingrid.page.mdek','ingrid.page.mdek',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,1,'/search-catalog','search-catalog','Search Catalog','Search Catalog',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,1,'/search-extended','search-extended','Search Extended','Search Extended',0,NULL,NULL,NULL,'search-ext-env-topic-terms.psml',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_constraint`
--

DROP TABLE IF EXISTS `folder_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_constraint` (
  `CONSTRAINT_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `USER_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CONSTRAINT_ID`),
  KEY `IX_FOLDER_CONSTRAINT_1` (`FOLDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_constraint`
--

LOCK TABLES `folder_constraint` WRITE;
/*!40000 ALTER TABLE `folder_constraint` DISABLE KEYS */;
INSERT INTO `folder_constraint` VALUES (1,14,0,NULL,'mdek',NULL,'view');
/*!40000 ALTER TABLE `folder_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_constraints_ref`
--

DROP TABLE IF EXISTS `folder_constraints_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_constraints_ref` (
  `CONSTRAINTS_REF_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_REF_ID`),
  UNIQUE KEY `UN_FOLDER_CONSTRAINTS_REF_1` (`FOLDER_ID`,`NAME`),
  KEY `IX_FOLDER_CONSTRAINTS_REF_1` (`FOLDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_constraints_ref`
--

LOCK TABLES `folder_constraints_ref` WRITE;
/*!40000 ALTER TABLE `folder_constraints_ref` DISABLE KEYS */;
INSERT INTO `folder_constraints_ref` VALUES (1,1,0,'public-view'),(2,11,0,'admin'),(3,11,1,'admin-portal'),(4,11,2,'admin-partner'),(5,11,3,'admin-provider'),(6,14,0,'admin-portal');
/*!40000 ALTER TABLE `folder_constraints_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_menu`
--

DROP TABLE IF EXISTS `folder_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_menu` (
  `MENU_ID` int(11) NOT NULL,
  `CLASS_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `FOLDER_ID` int(11) DEFAULT NULL,
  `ELEMENT_ORDER` int(11) DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEXT` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OPTIONS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEPTH` int(11) DEFAULT NULL,
  `IS_PATHS` smallint(6) DEFAULT NULL,
  `IS_REGEXP` smallint(6) DEFAULT NULL,
  `PROFILE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OPTIONS_ORDER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_NEST` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`),
  KEY `IX_FOLDER_MENU_1` (`PARENT_ID`),
  KEY `IX_FOLDER_MENU_2` (`FOLDER_ID`),
  KEY `UN_FOLDER_MENU_1` (`FOLDER_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_menu`
--

LOCK TABLES `folder_menu` WRITE;
/*!40000 ALTER TABLE `folder_menu` DISABLE KEYS */;
INSERT INTO `folder_menu` VALUES (1,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'footer-menu',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(2,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',1,NULL,3,NULL,NULL,NULL,NULL,'/disclaimer.psml',0,0,0,NULL,NULL,NULL,NULL),(3,'org.apache.jetspeed.om.folder.impl.FolderMenuSeparatorDefinitionImpl',1,NULL,1,NULL,NULL,NULL,'separator1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'org.apache.jetspeed.om.folder.impl.FolderMenuSeparatorDefinitionImpl',1,NULL,3,NULL,NULL,NULL,'separator1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'org.apache.jetspeed.om.folder.impl.FolderMenuSeparatorDefinitionImpl',1,NULL,5,NULL,NULL,NULL,'separator1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'main-menu',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(10,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,0,NULL,NULL,NULL,NULL,'/main-search.psml',0,0,0,NULL,NULL,NULL,NULL),(12,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,1,NULL,NULL,NULL,NULL,'/main-measures.psml',0,0,0,NULL,NULL,NULL,NULL),(13,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,3,NULL,NULL,NULL,NULL,'/main-service.psml',0,0,0,NULL,NULL,NULL,NULL),(14,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,2,NULL,NULL,NULL,NULL,'/search-catalog/search-catalog-hierarchy.psml',0,0,0,NULL,NULL,NULL,NULL),(15,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,3,NULL,NULL,NULL,NULL,'/main-maps.psml',0,0,0,NULL,NULL,NULL,NULL),(16,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,4,NULL,NULL,NULL,NULL,'/main-chronicle.psml',0,0,0,NULL,NULL,NULL,NULL),(17,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,5,NULL,NULL,NULL,NULL,'/main-about.psml',0,0,0,NULL,NULL,NULL,NULL),(18,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,6,NULL,NULL,NULL,NULL,'/application/main-application.psml',0,0,0,NULL,NULL,NULL,NULL),(20,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,10,NULL,NULL,NULL,NULL,'/Administrative',0,0,0,NULL,NULL,NULL,NULL),(21,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,9,NULL,NULL,NULL,NULL,'/mdek',0,0,0,NULL,NULL,NULL,NULL),(22,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'service-menu',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(27,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',1,NULL,2,NULL,NULL,NULL,NULL,'/service-sitemap.psml',0,0,0,NULL,NULL,NULL,NULL),(29,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',1,NULL,0,NULL,NULL,NULL,NULL,'/help.psml',0,0,0,NULL,NULL,NULL,NULL),(31,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',1,NULL,1,NULL,NULL,NULL,NULL,'/service-contact.psml',0,0,0,NULL,NULL,NULL,NULL),(34,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'sub-menu-about',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(36,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',34,NULL,0,NULL,NULL,NULL,NULL,'/main-about.psml',0,0,0,NULL,NULL,NULL,NULL),(37,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',34,NULL,1,NULL,NULL,NULL,NULL,'/main-about-partner.psml',0,0,0,NULL,NULL,NULL,NULL),(38,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',34,NULL,2,NULL,NULL,NULL,NULL,'/main-about-data-source.psml',0,0,0,NULL,NULL,NULL,NULL),(44,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'sub-menu-catalog',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(45,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',44,NULL,0,NULL,NULL,NULL,NULL,'/search-catalog/search-catalog-hierarchy.psml',0,0,0,NULL,NULL,NULL,NULL),(47,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'sub-menu-search',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(51,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,7,NULL,NULL,NULL,NULL,'/cms/cms-1.psml',0,0,0,NULL,NULL,NULL,NULL),(52,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',9,NULL,8,NULL,NULL,NULL,NULL,'/cms/cms-2.psml',0,0,0,NULL,NULL,NULL,NULL),(53,'org.apache.jetspeed.om.folder.impl.FolderMenuDefinitionImpl',NULL,1,0,'sub-menu',NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL),(54,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,0,NULL,NULL,NULL,NULL,'/administration/admin-usermanagement.psml',0,0,0,NULL,NULL,NULL,NULL),(55,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,1,NULL,NULL,NULL,NULL,'/administration/admin-homepage.psml',0,0,0,NULL,NULL,NULL,NULL),(56,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,2,NULL,NULL,NULL,NULL,'/administration/admin-content-rss.psml',0,0,0,NULL,NULL,NULL,NULL),(57,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,3,NULL,NULL,NULL,NULL,'/administration/admin-content-partner.psml',0,0,0,NULL,NULL,NULL,NULL),(58,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,4,NULL,NULL,NULL,NULL,'/administration/admin-content-provider.psml',0,0,0,NULL,NULL,NULL,NULL),(59,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,5,NULL,NULL,NULL,NULL,'/administration/admin-iplugs.psml',0,0,0,NULL,NULL,NULL,NULL),(60,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,6,NULL,NULL,NULL,NULL,'/administration/admin-cms.psml',0,0,0,NULL,NULL,NULL,NULL),(62,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,7,NULL,NULL,NULL,NULL,'/administration/admin-statistics.psml',0,0,0,NULL,NULL,NULL,NULL),(63,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,8,NULL,NULL,NULL,NULL,'/administration/admin-portal-profile.psml',0,0,0,NULL,NULL,NULL,NULL),(64,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',53,NULL,9,NULL,NULL,NULL,NULL,'/administration/admin-component-monitor.psml',0,0,0,NULL,NULL,NULL,NULL),(80,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',1,NULL,5,NULL,NULL,NULL,NULL,'/privacy.psml',0,0,0,NULL,NULL,NULL,NULL),(100,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',22,NULL,0,NULL,NULL,NULL,NULL,'/language.link',0,0,0,NULL,NULL,NULL,NULL),(101,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',22,NULL,1,NULL,NULL,NULL,NULL,'/home.link',0,0,0,NULL,NULL,NULL,NULL),(102,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',22,NULL,2,NULL,NULL,NULL,NULL,'/service-myportal.psml',0,0,0,NULL,NULL,NULL,NULL),(103,'org.apache.jetspeed.om.folder.impl.FolderMenuOptionsDefinitionImpl',22,NULL,3,NULL,NULL,NULL,NULL,'/administration',0,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `folder_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_menu_metadata`
--

DROP TABLE IF EXISTS `folder_menu_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_menu_metadata` (
  `METADATA_ID` int(11) NOT NULL,
  `MENU_ID` int(11) NOT NULL,
  `NAME` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`METADATA_ID`),
  UNIQUE KEY `UN_FOLDER_MENU_METADATA_1` (`MENU_ID`,`NAME`,`LOCALE`,`VALUE`),
  KEY `IX_FOLDER_MENU_METADATA_1` (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_menu_metadata`
--

LOCK TABLES `folder_menu_metadata` WRITE;
/*!40000 ALTER TABLE `folder_menu_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder_menu_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_metadata`
--

DROP TABLE IF EXISTS `folder_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_metadata` (
  `METADATA_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `NAME` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`METADATA_ID`),
  UNIQUE KEY `UN_FOLDER_METADATA_1` (`FOLDER_ID`,`NAME`,`LOCALE`,`VALUE`),
  KEY `IX_FOLDER_METADATA_1` (`FOLDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_metadata`
--

LOCK TABLES `folder_metadata` WRITE;
/*!40000 ALTER TABLE `folder_metadata` DISABLE KEYS */;
INSERT INTO `folder_metadata` VALUES (1,1,'title','es,,','Carpeta raiz'),(2,1,'title','fr,,','Répertoire racine');
/*!40000 ALTER TABLE `folder_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_order`
--

DROP TABLE IF EXISTS `folder_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_order` (
  `ORDER_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `SORT_ORDER` int(11) NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ORDER_ID`),
  UNIQUE KEY `UN_FOLDER_ORDER_1` (`FOLDER_ID`,`NAME`),
  KEY `IX_FOLDER_ORDER_1` (`FOLDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_order`
--

LOCK TABLES `folder_order` WRITE;
/*!40000 ALTER TABLE `folder_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment`
--

DROP TABLE IF EXISTS `fragment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment` (
  `FRAGMENT_ID` int(11) NOT NULL,
  `CLASS_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `PAGE_ID` int(11) DEFAULT NULL,
  `FRAGMENT_STRING_ID` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FRAGMENT_STRING_REFID` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DECORATOR` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PMODE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAYOUT_ROW` int(11) DEFAULT NULL,
  `LAYOUT_COLUMN` int(11) DEFAULT NULL,
  `LAYOUT_SIZES` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAYOUT_X` float DEFAULT NULL,
  `LAYOUT_Y` float DEFAULT NULL,
  `LAYOUT_Z` float DEFAULT NULL,
  `LAYOUT_WIDTH` float DEFAULT NULL,
  `LAYOUT_HEIGHT` float DEFAULT NULL,
  `OWNER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`FRAGMENT_ID`),
  KEY `IX_FRAGMENT_1` (`PARENT_ID`),
  KEY `UN_FRAGMENT_1` (`PAGE_ID`),
  KEY `IX_FRAGMENT_2` (`FRAGMENT_STRING_REFID`),
  KEY `IX_FRAGMENT_3` (`FRAGMENT_STRING_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment`
--

LOCK TABLES `fragment` WRITE;
/*!40000 ALTER TABLE `fragment` DISABLE KEYS */;
INSERT INTO `fragment` VALUES (1,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,1,'1',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(2,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,'741',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(3,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,'742',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,4,0,NULL,-1,-1,-1,-1,-1,NULL),(4,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,'743',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,3,0,NULL,-1,-1,-1,-1,-1,NULL),(5,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,'744',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(11,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,2,'9',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(12,'org.apache.jetspeed.om.page.impl.FragmentImpl',11,NULL,'10',NULL,'ingrid-portal-apps::DetectJavaScriptPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(14,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,3,'11',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(15,'org.apache.jetspeed.om.page.impl.FragmentImpl',14,NULL,'12',NULL,'ingrid-portal-apps::CMSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(18,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,4,'14',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(19,'org.apache.jetspeed.om.page.impl.FragmentImpl',18,NULL,'15',NULL,'ingrid-portal-apps::HelpPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(21,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,5,'900',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(22,'org.apache.jetspeed.om.page.impl.FragmentImpl',21,NULL,'901',NULL,'ingrid-portal-apps::ShowDataSourcePortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(24,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,6,'16',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(25,'org.apache.jetspeed.om.page.impl.FragmentImpl',24,NULL,'17',NULL,'ingrid-portal-apps::ShowPartnerPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(27,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,7,'18',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(28,'org.apache.jetspeed.om.page.impl.FragmentImpl',27,NULL,'19',NULL,'ingrid-portal-apps::CMSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(32,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,8,'22',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(33,'org.apache.jetspeed.om.page.impl.FragmentImpl',32,NULL,'23',NULL,'ingrid-portal-apps::ChronicleSearch',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(34,'org.apache.jetspeed.om.page.impl.FragmentImpl',32,NULL,'24',NULL,'ingrid-portal-apps::ChronicleResult',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(38,'org.apache.jetspeed.om.page.impl.FragmentImpl',37,NULL,'27',NULL,'ingrid-portal-apps::EnvironmentSearch',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(39,'org.apache.jetspeed.om.page.impl.FragmentImpl',37,NULL,'28',NULL,'ingrid-portal-apps::EnvironmentResult',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(40,'org.apache.jetspeed.om.page.impl.FragmentImpl',37,NULL,'29',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-header',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(43,'org.apache.jetspeed.om.page.impl.FragmentImpl',42,NULL,'801',NULL,'ingrid-portal-apps::ShowFeaturesPortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(45,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,11,'30',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(46,'org.apache.jetspeed.om.page.impl.FragmentImpl',45,NULL,'31',NULL,'ingrid-portal-apps::ShowMapsPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(48,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,12,'32',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(49,'org.apache.jetspeed.om.page.impl.FragmentImpl',48,NULL,'33',NULL,'ingrid-portal-apps::MeasuresSearch',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(53,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,13,'36',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(55,'org.apache.jetspeed.om.page.impl.FragmentImpl',53,NULL,'38',NULL,'ingrid-portal-apps::SearchSimpleResult',NULL,NULL,'portlet',NULL,'ingrid-clear',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(57,'org.apache.jetspeed.om.page.impl.FragmentImpl',53,NULL,'40',NULL,'ingrid-portal-apps::SearchSimilar',NULL,NULL,'portlet',NULL,'ingrid-clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(59,'org.apache.jetspeed.om.page.impl.FragmentImpl',53,NULL,'42',NULL,'ingrid-portal-apps::SearchResult',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(62,'org.apache.jetspeed.om.page.impl.FragmentImpl',61,NULL,'44',NULL,'ingrid-portal-apps::ServiceSearch',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(63,'org.apache.jetspeed.om.page.impl.FragmentImpl',61,NULL,'45',NULL,'ingrid-portal-apps::ServiceResult',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(64,'org.apache.jetspeed.om.page.impl.FragmentImpl',61,NULL,'46',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-header',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(66,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,15,'47',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(67,'org.apache.jetspeed.om.page.impl.FragmentImpl',66,NULL,'48',NULL,'ingrid-portal-apps::MyPortalCreateAccountPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(70,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,16,'50',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(71,'org.apache.jetspeed.om.page.impl.FragmentImpl',70,NULL,'51',NULL,'ingrid-portal-apps::MyPortalPasswordForgottenPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(75,'org.apache.jetspeed.om.page.impl.FragmentImpl',74,NULL,'54',NULL,'ingrid-portal-apps::CMSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(77,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,18,'55',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(78,'org.apache.jetspeed.om.page.impl.FragmentImpl',77,NULL,'56',NULL,'ingrid-portal-apps::RssNews',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(80,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,19,'57',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(81,'org.apache.jetspeed.om.page.impl.FragmentImpl',80,NULL,'58',NULL,'ingrid-portal-apps::SearchDetail',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(84,'org.apache.jetspeed.om.page.impl.FragmentImpl',83,NULL,'60',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(85,'org.apache.jetspeed.om.page.impl.FragmentImpl',83,NULL,'61',NULL,'ingrid-portal-apps::SearchHistory',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(86,'org.apache.jetspeed.om.page.impl.FragmentImpl',83,NULL,'62',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(89,'org.apache.jetspeed.om.page.impl.FragmentImpl',88,NULL,'64',NULL,'ingrid-portal-apps::SearchResult',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(92,'org.apache.jetspeed.om.page.impl.FragmentImpl',91,NULL,'66',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(93,'org.apache.jetspeed.om.page.impl.FragmentImpl',91,NULL,'67',NULL,'ingrid-portal-apps::SearchSavePortlet',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(96,'org.apache.jetspeed.om.page.impl.FragmentImpl',95,NULL,'69',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(97,'org.apache.jetspeed.om.page.impl.FragmentImpl',95,NULL,'70',NULL,'ingrid-portal-apps::SearchSettings',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(98,'org.apache.jetspeed.om.page.impl.FragmentImpl',95,NULL,'71',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(101,'org.apache.jetspeed.om.page.impl.FragmentImpl',100,NULL,'73',NULL,'ingrid-portal-apps::ContactNewsletterPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(102,'org.apache.jetspeed.om.page.impl.FragmentImpl',100,NULL,'74',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(103,'org.apache.jetspeed.om.page.impl.FragmentImpl',100,NULL,'75',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,1,NULL,-1,-1,-1,-1,-1,NULL),(105,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,25,'76',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(106,'org.apache.jetspeed.om.page.impl.FragmentImpl',105,NULL,'763',NULL,'ingrid-portal-apps::Contact',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(109,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,26,'79',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(110,'org.apache.jetspeed.om.page.impl.FragmentImpl',109,NULL,'80',NULL,'ingrid-portal-apps::MyPortalLoginPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(113,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,27,'82',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(114,'org.apache.jetspeed.om.page.impl.FragmentImpl',113,NULL,'83',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(116,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,28,'84',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(117,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,'749',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(118,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,'750',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,4,0,NULL,-1,-1,-1,-1,-1,NULL),(119,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,'751',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,3,0,NULL,-1,-1,-1,-1,-1,NULL),(120,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,'752',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(125,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,29,'92',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(126,'org.apache.jetspeed.om.page.impl.FragmentImpl',125,NULL,'765',NULL,'ingrid-portal-apps::MyPortalEditAccountPortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(131,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,30,'97',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(133,'org.apache.jetspeed.om.page.impl.FragmentImpl',131,NULL,'99',NULL,'ingrid-portal-apps::MyPortalPersonalizeHomePortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(140,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,31,'105',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(141,'org.apache.jetspeed.om.page.impl.FragmentImpl',140,NULL,'106',NULL,'ingrid-portal-apps::MyPortalOverviewPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(144,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,32,'401',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(145,'org.apache.jetspeed.om.page.impl.FragmentImpl',144,NULL,'402',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(146,'org.apache.jetspeed.om.page.impl.FragmentImpl',144,NULL,'403',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(147,'org.apache.jetspeed.om.page.impl.FragmentImpl',144,NULL,'404',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(148,'org.apache.jetspeed.om.page.impl.FragmentImpl',144,NULL,'405',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(153,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,33,'869',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(154,'org.apache.jetspeed.om.page.impl.FragmentImpl',153,NULL,'870',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(155,'org.apache.jetspeed.om.page.impl.FragmentImpl',153,NULL,'871',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(156,'org.apache.jetspeed.om.page.impl.FragmentImpl',153,NULL,'872',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(157,'org.apache.jetspeed.om.page.impl.FragmentImpl',153,NULL,'873',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(162,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,34,'861',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(163,'org.apache.jetspeed.om.page.impl.FragmentImpl',162,NULL,'862',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(164,'org.apache.jetspeed.om.page.impl.FragmentImpl',162,NULL,'863',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(165,'org.apache.jetspeed.om.page.impl.FragmentImpl',162,NULL,'864',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(166,'org.apache.jetspeed.om.page.impl.FragmentImpl',162,NULL,'865',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(171,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,35,'108',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(172,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,'756',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(173,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,'757',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,4,0,NULL,-1,-1,-1,-1,-1,NULL),(174,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,'758',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,3,0,NULL,-1,-1,-1,-1,-1,NULL),(175,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,'759',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(180,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,36,'425',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(181,'org.apache.jetspeed.om.page.impl.FragmentImpl',180,NULL,'426',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(182,'org.apache.jetspeed.om.page.impl.FragmentImpl',180,NULL,'427',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(183,'org.apache.jetspeed.om.page.impl.FragmentImpl',180,NULL,'428',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(184,'org.apache.jetspeed.om.page.impl.FragmentImpl',180,NULL,'429',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(189,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,37,'433',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(190,'org.apache.jetspeed.om.page.impl.FragmentImpl',189,NULL,'434',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(191,'org.apache.jetspeed.om.page.impl.FragmentImpl',189,NULL,'435',NULL,'ingrid-portal-apps::EnvironmentTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(192,'org.apache.jetspeed.om.page.impl.FragmentImpl',189,NULL,'436',NULL,'ingrid-portal-apps::RssNewsTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(193,'org.apache.jetspeed.om.page.impl.FragmentImpl',189,NULL,'437',NULL,'ingrid-portal-apps::IngridInformPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(198,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,38,'116',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(199,'org.apache.jetspeed.om.page.impl.FragmentImpl',198,NULL,'117',NULL,'ingrid-portal-apps::AdminCMSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(201,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,39,'118',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(202,'org.apache.jetspeed.om.page.impl.FragmentImpl',201,NULL,'119',NULL,'ingrid-portal-apps::AdminComponentMonitorPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(204,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,40,'120',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(205,'org.apache.jetspeed.om.page.impl.FragmentImpl',204,NULL,'121',NULL,'ingrid-portal-apps::ContentPartnerPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(207,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,41,'122',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(208,'org.apache.jetspeed.om.page.impl.FragmentImpl',207,NULL,'123',NULL,'ingrid-portal-apps::ContentProviderPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(210,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,42,'124',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(211,'org.apache.jetspeed.om.page.impl.FragmentImpl',210,NULL,'125',NULL,'ingrid-portal-apps::ContentRSSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(213,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,43,'126',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(214,'org.apache.jetspeed.om.page.impl.FragmentImpl',213,NULL,'127',NULL,'ingrid-portal-apps::AdminHomepagePortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(216,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,44,'128',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(217,'org.apache.jetspeed.om.page.impl.FragmentImpl',216,NULL,'129',NULL,'ingrid-portal-apps::AdminIPlugPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(219,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,45,'130',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(220,'org.apache.jetspeed.om.page.impl.FragmentImpl',219,NULL,'131',NULL,'ingrid-portal-apps::AdminPortalProfilePortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(222,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,46,'132',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(223,'org.apache.jetspeed.om.page.impl.FragmentImpl',222,NULL,'133',NULL,'ingrid-portal-apps::AdminStatisticsPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(225,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,47,'134',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(226,'org.apache.jetspeed.om.page.impl.FragmentImpl',225,NULL,'135',NULL,'ingrid-portal-apps::AdminUserPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(229,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,48,'137',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(230,'org.apache.jetspeed.om.page.impl.FragmentImpl',229,NULL,'138',NULL,'ingrid-portal-apps::AdminWMSPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(233,'org.apache.jetspeed.om.page.impl.FragmentImpl',232,NULL,'845',NULL,'ingrid-portal-apps::IFramePortalPortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(236,'org.apache.jetspeed.om.page.impl.FragmentImpl',235,NULL,'843',NULL,'ingrid-portal-apps::IFramePortalPortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(239,'org.apache.jetspeed.om.page.impl.FragmentImpl',238,NULL,'847',NULL,'ingrid-portal-apps::IFramePortalPortlet',NULL,NULL,'portlet',NULL,'ingrid-teaser',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(241,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,52,'840',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(242,'org.apache.jetspeed.om.page.impl.FragmentImpl',241,NULL,'841',NULL,'ingrid-portal-apps::CMSPortlet3',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(245,'org.apache.jetspeed.om.page.impl.FragmentImpl',244,NULL,'881',NULL,'ingrid-portal-apps::CMSPortlet0',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(247,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,54,'882',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(248,'org.apache.jetspeed.om.page.impl.FragmentImpl',247,NULL,'883',NULL,'ingrid-portal-apps::CMSPortlet1',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(250,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,55,'884',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(251,'org.apache.jetspeed.om.page.impl.FragmentImpl',250,NULL,'885',NULL,'ingrid-portal-apps::CMSPortlet2',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(253,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,56,'280',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(254,'org.apache.jetspeed.om.page.impl.FragmentImpl',253,NULL,'281',NULL,'ingrid-portal-mdek::MdekPortalAdminPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(255,'org.apache.jetspeed.om.page.impl.FragmentImpl',253,NULL,'283',NULL,'ingrid-portal-mdek::MdekEntryPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,-1,NULL,-1,-1,-1,-1,-1,NULL),(256,'org.apache.jetspeed.om.page.impl.FragmentImpl',253,NULL,'300',NULL,'ingrid-portal-mdek::MdekAdminLoginPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(258,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,57,'200',NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(259,'org.apache.jetspeed.om.page.impl.FragmentImpl',258,NULL,'201',NULL,'ingrid-portal-apps::SearchCatalogHierarchy',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(262,'org.apache.jetspeed.om.page.impl.FragmentImpl',261,NULL,'203',NULL,'ingrid-portal-apps::SearchCatalogThesaurus',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(263,'org.apache.jetspeed.om.page.impl.FragmentImpl',261,NULL,'220',NULL,'ingrid-portal-apps::SearchCatalogThesaurusResult',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(264,'org.apache.jetspeed.om.page.impl.FragmentImpl',261,NULL,'240',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,1,1,NULL,-1,-1,-1,-1,-1,NULL),(267,'org.apache.jetspeed.om.page.impl.FragmentImpl',266,NULL,'142',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(268,'org.apache.jetspeed.om.page.impl.FragmentImpl',266,NULL,'143',NULL,'ingrid-portal-apps::SearchExtAdrAreaPartner',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(269,'org.apache.jetspeed.om.page.impl.FragmentImpl',266,NULL,'144',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(272,'org.apache.jetspeed.om.page.impl.FragmentImpl',271,NULL,'146',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(273,'org.apache.jetspeed.om.page.impl.FragmentImpl',271,NULL,'147',NULL,'ingrid-portal-apps::SearchExtAdrPlaceReference',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(274,'org.apache.jetspeed.om.page.impl.FragmentImpl',271,NULL,'148',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(277,'org.apache.jetspeed.om.page.impl.FragmentImpl',276,NULL,'150',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(278,'org.apache.jetspeed.om.page.impl.FragmentImpl',276,NULL,'151',NULL,'ingrid-portal-apps::SearchExtAdrTopicMode',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(279,'org.apache.jetspeed.om.page.impl.FragmentImpl',276,NULL,'152',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(282,'org.apache.jetspeed.om.page.impl.FragmentImpl',281,NULL,'154',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(283,'org.apache.jetspeed.om.page.impl.FragmentImpl',281,NULL,'155',NULL,'ingrid-portal-apps::SearchExtAdrTopicTerms',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(284,'org.apache.jetspeed.om.page.impl.FragmentImpl',281,NULL,'156',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(287,'org.apache.jetspeed.om.page.impl.FragmentImpl',286,NULL,'158',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(288,'org.apache.jetspeed.om.page.impl.FragmentImpl',286,NULL,'159',NULL,'ingrid-portal-apps::SearchExtEnvAreaContents',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(289,'org.apache.jetspeed.om.page.impl.FragmentImpl',286,NULL,'160',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(292,'org.apache.jetspeed.om.page.impl.FragmentImpl',291,NULL,'162',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(293,'org.apache.jetspeed.om.page.impl.FragmentImpl',291,NULL,'163',NULL,'ingrid-portal-apps::SearchExtEnvAreaPartner',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(294,'org.apache.jetspeed.om.page.impl.FragmentImpl',291,NULL,'164',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(297,'org.apache.jetspeed.om.page.impl.FragmentImpl',296,NULL,'166',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(298,'org.apache.jetspeed.om.page.impl.FragmentImpl',296,NULL,'167',NULL,'ingrid-portal-apps::SearchExtEnvAreaSources',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(299,'org.apache.jetspeed.om.page.impl.FragmentImpl',296,NULL,'168',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(302,'org.apache.jetspeed.om.page.impl.FragmentImpl',301,NULL,'170',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(303,'org.apache.jetspeed.om.page.impl.FragmentImpl',301,NULL,'171',NULL,'ingrid-portal-apps::SearchExtEnvPlaceGeothesaurus',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(304,'org.apache.jetspeed.om.page.impl.FragmentImpl',301,NULL,'172',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(307,'org.apache.jetspeed.om.page.impl.FragmentImpl',306,NULL,'174',NULL,'jetspeed-layouts::IngridTwoColumns',NULL,NULL,'layout',NULL,NULL,NULL,NULL,0,-1,NULL,-1,-1,-1,-1,-1,NULL),(308,'org.apache.jetspeed.om.page.impl.FragmentImpl',307,NULL,'175',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(309,'org.apache.jetspeed.om.page.impl.FragmentImpl',306,NULL,'176',NULL,'ingrid-portal-apps::SearchExtEnvPlaceMap',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,-1,NULL,-1,-1,-1,-1,-1,NULL),(312,'org.apache.jetspeed.om.page.impl.FragmentImpl',311,NULL,'178',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(313,'org.apache.jetspeed.om.page.impl.FragmentImpl',311,NULL,'179',NULL,'ingrid-portal-apps::SearchExtEnvTimeConstraint',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(314,'org.apache.jetspeed.om.page.impl.FragmentImpl',311,NULL,'180',NULL,'ingrid-portal-apps::SearchExtEnvTimeChronicle',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(315,'org.apache.jetspeed.om.page.impl.FragmentImpl',311,NULL,'181',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(318,'org.apache.jetspeed.om.page.impl.FragmentImpl',317,NULL,'183',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(319,'org.apache.jetspeed.om.page.impl.FragmentImpl',317,NULL,'184',NULL,'ingrid-portal-apps::SearchExtEnvTopicTerms',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(320,'org.apache.jetspeed.om.page.impl.FragmentImpl',317,NULL,'185',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(323,'org.apache.jetspeed.om.page.impl.FragmentImpl',322,NULL,'187',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(324,'org.apache.jetspeed.om.page.impl.FragmentImpl',322,NULL,'188',NULL,'ingrid-portal-apps::SearchExtEnvTopicThesaurus',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(325,'org.apache.jetspeed.om.page.impl.FragmentImpl',322,NULL,'189',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(328,'org.apache.jetspeed.om.page.impl.FragmentImpl',327,NULL,'269',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(329,'org.apache.jetspeed.om.page.impl.FragmentImpl',327,NULL,'270',NULL,'ingrid-portal-apps::SearchExtLawAreaPartner',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(330,'org.apache.jetspeed.om.page.impl.FragmentImpl',327,NULL,'271',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(333,'org.apache.jetspeed.om.page.impl.FragmentImpl',332,NULL,'261',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(334,'org.apache.jetspeed.om.page.impl.FragmentImpl',332,NULL,'262',NULL,'ingrid-portal-apps::SearchExtLawTopicTerms',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(335,'org.apache.jetspeed.om.page.impl.FragmentImpl',332,NULL,'263',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(338,'org.apache.jetspeed.om.page.impl.FragmentImpl',337,NULL,'265',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(339,'org.apache.jetspeed.om.page.impl.FragmentImpl',337,NULL,'266',NULL,'ingrid-portal-apps::SearchExtLawTopicThesaurus',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(340,'org.apache.jetspeed.om.page.impl.FragmentImpl',337,NULL,'267',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(343,'org.apache.jetspeed.om.page.impl.FragmentImpl',342,NULL,'191',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(344,'org.apache.jetspeed.om.page.impl.FragmentImpl',342,NULL,'192',NULL,'ingrid-portal-apps::SearchExtResTopicAttributes',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(345,'org.apache.jetspeed.om.page.impl.FragmentImpl',342,NULL,'193',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(348,'org.apache.jetspeed.om.page.impl.FragmentImpl',347,NULL,'195',NULL,'ingrid-portal-apps::SearchSimple',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL),(349,'org.apache.jetspeed.om.page.impl.FragmentImpl',347,NULL,'196',NULL,'ingrid-portal-apps::SearchExtResTopicTerms',NULL,NULL,'portlet',NULL,'clear',NULL,NULL,1,0,NULL,-1,-1,-1,-1,-1,NULL),(350,'org.apache.jetspeed.om.page.impl.FragmentImpl',347,NULL,'197',NULL,'ingrid-portal-apps::InfoPortlet',NULL,NULL,'portlet',NULL,'ingrid-marginal-teaser',NULL,NULL,0,1,NULL,-1,-1,-1,-1,-1,NULL),(360,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,NULL,NULL,'ingrid-portal-apps::CategoryTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(361,'org.apache.jetspeed.om.page.impl.FragmentImpl',1,NULL,NULL,NULL,'ingrid-portal-apps::InfoDefaultPageTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,5,0,NULL,-1,-1,-1,-1,-1,NULL),(363,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,NULL,NULL,'ingrid-portal-apps::CategoryTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(364,'org.apache.jetspeed.om.page.impl.FragmentImpl',116,NULL,NULL,NULL,'ingrid-portal-apps::InfoDefaultPageTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,5,0,NULL,-1,-1,-1,-1,-1,NULL),(365,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,NULL,NULL,'ingrid-portal-apps::CategoryTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,2,0,NULL,-1,-1,-1,-1,-1,NULL),(366,'org.apache.jetspeed.om.page.impl.FragmentImpl',171,NULL,NULL,NULL,'ingrid-portal-apps::InfoDefaultPageTeaser',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,5,0,NULL,-1,-1,-1,-1,-1,NULL),(460,'org.apache.jetspeed.om.page.impl.FragmentImpl',NULL,100,NULL,NULL,'jetspeed-layouts::IngridClearLayout',NULL,NULL,'layout',NULL,NULL,NULL,NULL,-1,-1,NULL,-1,-1,-1,-1,-1,NULL),(461,'org.apache.jetspeed.om.page.impl.FragmentImpl',460,NULL,NULL,NULL,'ingrid-portal-apps::PrivacyPortlet',NULL,NULL,'portlet',NULL,NULL,NULL,NULL,0,0,NULL,-1,-1,-1,-1,-1,NULL);
/*!40000 ALTER TABLE `fragment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment_constraint`
--

DROP TABLE IF EXISTS `fragment_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment_constraint` (
  `CONSTRAINT_ID` int(11) NOT NULL,
  `FRAGMENT_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `USER_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CONSTRAINT_ID`),
  KEY `IX_FRAGMENT_CONSTRAINT_1` (`FRAGMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment_constraint`
--

LOCK TABLES `fragment_constraint` WRITE;
/*!40000 ALTER TABLE `fragment_constraint` DISABLE KEYS */;
INSERT INTO `fragment_constraint` VALUES (1,255,0,NULL,'mdek',NULL,'view'),(2,255,1,'admin','admin-portal',NULL,NULL),(3,255,2,NULL,'mdek',NULL,'view'),(4,255,3,NULL,'mdek',NULL,'view'),(5,255,4,NULL,'mdek',NULL,'view'),(6,255,5,NULL,'mdek',NULL,'view'),(7,255,6,NULL,'mdek',NULL,'view'),(8,255,7,NULL,'mdek',NULL,'view'),(9,255,8,NULL,'mdek',NULL,'view'),(10,255,9,NULL,'mdek',NULL,'view');
/*!40000 ALTER TABLE `fragment_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment_constraints_ref`
--

DROP TABLE IF EXISTS `fragment_constraints_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment_constraints_ref` (
  `CONSTRAINTS_REF_ID` int(11) NOT NULL,
  `FRAGMENT_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_REF_ID`),
  UNIQUE KEY `UN_FRAGMENT_CONSTRAINTS_REF_1` (`FRAGMENT_ID`,`NAME`),
  KEY `IX_FRAGMENT_CONSTRAINTS_REF_1` (`FRAGMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment_constraints_ref`
--

LOCK TABLES `fragment_constraints_ref` WRITE;
/*!40000 ALTER TABLE `fragment_constraints_ref` DISABLE KEYS */;
INSERT INTO `fragment_constraints_ref` VALUES (1,227,0,'admin'),(2,254,0,'admin-portal'),(3,256,0,'admin');
/*!40000 ALTER TABLE `fragment_constraints_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment_pref`
--

DROP TABLE IF EXISTS `fragment_pref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment_pref` (
  `PREF_ID` int(11) NOT NULL,
  `FRAGMENT_ID` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `IS_READ_ONLY` smallint(6) NOT NULL,
  PRIMARY KEY (`PREF_ID`),
  UNIQUE KEY `UN_FRAGMENT_PREF_1` (`FRAGMENT_ID`,`NAME`),
  KEY `IX_FRAGMENT_PREF_1` (`FRAGMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment_pref`
--

LOCK TABLES `fragment_pref` WRITE;
/*!40000 ALTER TABLE `fragment_pref` DISABLE KEYS */;
INSERT INTO `fragment_pref` VALUES (1,8,'titleKey',0),(2,15,'cmsKey',0),(3,15,'infoTemplate',0),(4,15,'titleKey',0),(5,16,'infoTemplate',0),(6,16,'titleKey',0),(7,28,'cmsKey',0),(8,28,'helpKey',0),(9,28,'infoTemplate',0),(10,29,'infoTemplate',0),(11,29,'titleKey',0),(12,30,'infoTemplate',0),(13,30,'titleKey',0),(14,33,'helpKey',0),(15,35,'infoTemplate',0),(16,35,'titleKey',0),(17,38,'helpKey',0),(18,40,'infoLink',0),(19,40,'infoTemplate',0),(20,40,'titleKey',0),(21,42,'helpKey',0),(22,49,'helpKey',0),(23,51,'infoTemplate',0),(24,51,'titleKey',0),(25,55,'helpKey',0),(26,55,'titleKey',0),(27,56,'infoTemplate',0),(28,56,'titleKey',0),(29,62,'helpKey',0),(30,64,'infoLink',0),(31,64,'infoTemplate',0),(32,64,'titleKey',0),(33,68,'infoTemplate',0),(34,68,'titleKey',0),(35,72,'infoTemplate',0),(36,72,'titleKey',0),(37,75,'cmsKey',0),(38,75,'infoTemplate',0),(39,78,'startWithEntry',0),(40,84,'helpKey',0),(41,84,'titleKey',0),(42,86,'infoTemplate',0),(43,86,'titleKey',0),(44,92,'helpKey',0),(45,92,'titleKey',0),(46,96,'helpKey',0),(47,96,'titleKey',0),(48,98,'infoTemplate',0),(49,98,'titleKey',0),(50,101,'helpKey',0),(51,102,'infoTemplate',0),(52,102,'titleKey',0),(53,103,'infoTemplate',0),(54,103,'titleKey',0),(55,107,'infoTemplate',0),(56,107,'titleKey',0),(57,111,'helpKey',0),(58,111,'infoTemplate',0),(59,111,'titleKey',0),(60,114,'infoTemplate',0),(61,114,'titleKey',0),(62,123,'titleKey',0),(63,132,'titleKey',0),(64,133,'titleKey',0),(65,134,'titleKey',0),(66,135,'titleKey',0),(67,136,'titleKey',0),(68,137,'currPage',0),(69,137,'infoTemplate',0),(70,137,'titleKey',0),(71,138,'helpKey',0),(72,138,'infoTemplate',0),(73,138,'titleKey',0),(74,142,'infoTemplate',0),(75,142,'titleKey',0),(76,145,'helpKey',0),(77,145,'titleKey',0),(78,146,'helpKey',0),(79,146,'titleKey',0),(80,147,'helpKey',0),(81,147,'noOfEntriesDisplayed',0),(82,147,'titleKey',0),(83,148,'helpKey',0),(84,148,'infoTemplate',0),(85,148,'titleKey',0),(86,149,'titleKey',0),(87,150,'titleKey',0),(88,151,'titleKey',0),(89,160,'titleKey',0),(90,169,'titleKey',0),(91,178,'titleKey',0),(92,181,'helpKey',0),(93,181,'titleKey',0),(94,182,'helpKey',0),(95,182,'titleKey',0),(96,183,'helpKey',0),(97,183,'noOfEntriesDisplayed',0),(98,183,'titleKey',0),(99,184,'helpKey',0),(100,184,'infoTemplate',0),(101,184,'titleKey',0),(102,185,'titleKey',0),(103,186,'titleKey',0),(104,187,'titleKey',0),(105,190,'helpKey',0),(106,190,'titleKey',0),(107,191,'helpKey',0),(108,191,'titleKey',0),(109,192,'helpKey',0),(110,192,'noOfEntriesDisplayed',0),(111,192,'titleKey',0),(112,193,'helpKey',0),(113,193,'infoTemplate',0),(114,193,'titleKey',0),(115,194,'titleKey',0),(116,195,'titleKey',0),(117,196,'titleKey',0),(118,233,'HEIGHT',0),(119,233,'SRC',0),(120,233,'titleKey',0),(121,233,'WIDTH',0),(122,236,'HEIGHT',0),(123,236,'SRC',0),(124,236,'titleKey',0),(125,236,'WIDTH',0),(126,239,'HEIGHT',0),(127,239,'SRC',0),(128,239,'titleKey',0),(129,239,'WIDTH',0),(130,264,'infoTemplate',0),(131,264,'titleKey',0),(132,267,'helpKey',0),(133,267,'titleKey',0),(134,269,'infoTemplate',0),(135,269,'titleKey',0),(136,272,'helpKey',0),(137,272,'titleKey',0),(138,274,'infoTemplate',0),(139,274,'titleKey',0),(140,277,'helpKey',0),(141,277,'titleKey',0),(142,279,'infoTemplate',0),(143,279,'titleKey',0),(144,282,'helpKey',0),(145,282,'titleKey',0),(146,284,'infoTemplate',0),(147,284,'titleKey',0),(148,287,'helpKey',0),(149,287,'titleKey',0),(150,289,'infoTemplate',0),(151,289,'titleKey',0),(152,292,'helpKey',0),(153,292,'titleKey',0),(154,294,'infoTemplate',0),(155,294,'titleKey',0),(156,297,'helpKey',0),(157,297,'titleKey',0),(158,299,'infoTemplate',0),(159,299,'titleKey',0),(160,302,'helpKey',0),(161,302,'titleKey',0),(162,304,'infoTemplate',0),(163,304,'titleKey',0),(164,308,'helpKey',0),(165,308,'titleKey',0),(166,312,'helpKey',0),(167,312,'titleKey',0),(168,315,'infoTemplate',0),(169,315,'titleKey',0),(170,318,'helpKey',0),(171,318,'titleKey',0),(172,320,'infoTemplate',0),(173,320,'titleKey',0),(174,323,'helpKey',0),(175,323,'titleKey',0),(176,325,'infoTemplate',0),(177,325,'titleKey',0),(178,328,'helpKey',0),(179,328,'titleKey',0),(180,330,'infoTemplate',0),(181,330,'titleKey',0),(182,333,'helpKey',0),(183,333,'titleKey',0),(184,335,'infoTemplate',0),(185,335,'titleKey',0),(186,338,'helpKey',0),(187,338,'titleKey',0),(188,340,'infoTemplate',0),(189,340,'titleKey',0),(190,343,'helpKey',0),(191,343,'titleKey',0),(192,345,'infoTemplate',0),(193,345,'titleKey',0),(194,348,'helpKey',0),(195,348,'titleKey',0),(196,350,'infoTemplate',0),(197,350,'titleKey',0),(201,15,'sectionStyle',0),(202,15,'articleStyle',0),(203,28,'sectionStyle',0),(204,114,'sectionStyle',0),(205,15,'titleTag',0),(206,28,'titleTag',0),(207,114,'titleTag',0);
/*!40000 ALTER TABLE `fragment_pref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment_pref_value`
--

DROP TABLE IF EXISTS `fragment_pref_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment_pref_value` (
  `PREF_VALUE_ID` int(11) NOT NULL,
  `PREF_ID` int(11) NOT NULL,
  `VALUE_ORDER` int(11) NOT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PREF_VALUE_ID`),
  KEY `IX_FRAGMENT_PREF_VALUE_1` (`PREF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment_pref_value`
--

LOCK TABLES `fragment_pref_value` WRITE;
/*!40000 ALTER TABLE `fragment_pref_value` DISABLE KEYS */;
INSERT INTO `fragment_pref_value` VALUES (1,1,0,'teaser.weather.title'),(2,2,0,'ingrid.disclaimer'),(3,3,0,'/WEB-INF/templates/default_cms.vm'),(4,4,0,'disclaimer.title'),(5,5,0,'/WEB-INF/templates/disclaimer_info.vm'),(6,6,0,'disclaimer.info.title'),(7,7,0,'ingrid.about'),(8,8,0,'about-1'),(9,9,0,'/WEB-INF/templates/default_cms.vm'),(10,10,0,'/WEB-INF/templates/about_links.vm'),(11,11,0,'about.links.title'),(12,12,0,'/WEB-INF/templates/about_partner.vm'),(13,13,0,'about.partner.title'),(14,14,0,'search-chronicle-1'),(15,15,0,'/WEB-INF/templates/chronicle_info_new.vm'),(16,16,0,'chronicleSearch.info.title'),(17,17,0,'search-topics-1'),(18,18,0,'/portal/search-extended/search-ext-env-area-contents.psml?select=2'),(19,19,0,'/WEB-INF/templates/environment_info_new.vm'),(20,20,0,'envSearch.info.title'),(21,22,0,'search-measure-1'),(22,23,0,'/WEB-INF/templates/measures_info_new.vm'),(23,24,0,'measuresSearch.info.title'),(24,25,0,'search-1'),(25,26,0,'searchSimple.title.result'),(26,27,0,'/WEB-INF/templates/search_simple_info_new.vm'),(27,28,0,'searchSimple.info.title'),(28,29,0,'search-service-1'),(29,30,0,'/portal/search-extended/search-ext-env-area-contents.psml?select=3'),(30,31,0,'/WEB-INF/templates/service_info_new.vm'),(31,32,0,'serviceSearch.info.title'),(32,33,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(33,34,0,'teaser.login.title'),(34,35,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(35,36,0,'teaser.login.title'),(36,37,0,'ingrid.privacy'),(37,38,0,'/WEB-INF/templates/default_cms.vm'),(38,39,0,'4'),(39,40,0,'search-history-1'),(40,41,0,'searchSimple.title.history'),(41,42,0,'/WEB-INF/templates/search_history_info.vm'),(42,43,0,'searchHistory.info.title'),(43,44,0,'search-save-1'),(44,45,0,'searchSimple.title.save'),(45,46,0,'search-settings-1'),(46,47,0,'searchSimple.title.settings'),(47,48,0,'/WEB-INF/templates/search_settings_info.vm'),(48,49,0,'searchSettings.info.title'),(49,50,0,'ingrid-newsletter-1'),(50,51,0,'/WEB-INF/templates/contact_back.vm'),(51,52,0,'teaser.newsletter.contact'),(52,53,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(53,54,0,'teaser.newsletter.more_info'),(54,55,0,'/WEB-INF/templates/newsletter_teaser.vm'),(55,56,0,'teaser.newsletter.title'),(56,57,0,'myingrid-1'),(57,58,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(58,59,0,'teaser.login.title'),(59,60,0,'/WEB-INF/templates/sitemap.vm'),(60,61,0,'sitemap.title'),(61,62,0,'teaser.weather.title'),(62,63,0,'personalize.overview.title'),(63,64,0,'personalize.home.title'),(64,65,0,'personalize.partner.title'),(65,66,0,'personalize.sources.title'),(66,67,0,'personalize.settings.title'),(67,68,0,'personalize'),(68,69,0,'/WEB-INF/templates/myportal/myportal_navigation.vm'),(69,70,0,'myPortal.info.navigation.title'),(70,71,0,'myingrid-1'),(71,72,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(72,73,0,'teaser.login.title'),(73,74,0,'/WEB-INF/templates/myportal/myportal_navigation.vm'),(74,75,0,'myPortal.info.navigation.title'),(75,76,0,'search-1'),(76,77,0,'searchSimple.title.search'),(77,78,0,'search-topics-1'),(78,79,0,'teaser.environment.title'),(79,80,0,'rss-news-1'),(80,81,0,'4'),(81,82,0,'news.teaser.title'),(82,83,0,'ingrid-inform-1'),(83,84,0,'/WEB-INF/templates/ingrid_inform_teaser.vm'),(84,85,0,'teaser.ingridInform.title'),(85,86,0,'teaser.service.title'),(86,87,0,'teaser.measures.title'),(87,88,0,'chronicle.teaser.title'),(88,89,0,'teaser.weather.title'),(89,90,0,'teaser.weather.title'),(90,91,0,'teaser.weather.title'),(91,92,0,'search-1'),(92,93,0,'searchSimple.title.search'),(93,94,0,'search-topics-1'),(94,95,0,'teaser.environment.title'),(95,96,0,'rss-news-1'),(96,97,0,'4'),(97,98,0,'news.teaser.title'),(98,99,0,'ingrid-inform-1'),(99,100,0,'/WEB-INF/templates/ingrid_inform_teaser.vm'),(100,101,0,'teaser.ingridInform.title'),(101,102,0,'teaser.service.title'),(102,103,0,'teaser.measures.title'),(103,104,0,'chronicle.teaser.title'),(104,105,0,'search-1'),(105,106,0,'searchSimple.title.search'),(106,107,0,'search-topics-1'),(107,108,0,'teaser.environment.title'),(108,109,0,'rss-news-1'),(109,110,0,'4'),(110,111,0,'news.teaser.title'),(111,112,0,'ingrid-inform-1'),(112,113,0,'/WEB-INF/templates/ingrid_inform_teaser.vm'),(113,114,0,'teaser.ingridInform.title'),(114,115,0,'teaser.service.title'),(115,116,0,'teaser.measures.title'),(116,117,0,'chronicle.teaser.title'),(117,118,0,'450'),(118,119,0,''),(119,120,0,'ingrid.application.0.title'),(120,121,0,'883'),(121,122,0,'450'),(122,123,0,''),(123,124,0,'ingrid.application.1.title'),(124,125,0,'883'),(125,126,0,'450'),(126,127,0,''),(127,128,0,'ingrid.application.2.title'),(128,129,0,'883'),(129,130,0,'/WEB-INF/templates/search_catalog/search_cat_thesaurus_info_sns.vm'),(130,131,0,'searchCatThesaurus.info.title'),(131,132,0,'ext-search-address-1'),(132,133,0,'searchSimple.title.extended'),(133,134,0,'/WEB-INF/templates/search_extended/search_ext_adr_info.vm'),(134,135,0,'searchExtAdr.info.title'),(135,136,0,'ext-search-address-1'),(136,137,0,'searchSimple.title.extended'),(137,138,0,'/WEB-INF/templates/search_extended/search_ext_adr_info.vm'),(138,139,0,'searchExtAdr.info.title'),(139,140,0,'ext-search-address-1'),(140,141,0,'searchSimple.title.extended'),(141,142,0,'/WEB-INF/templates/search_extended/search_ext_adr_info.vm'),(142,143,0,'searchExtAdr.info.title'),(143,144,0,'ext-search-address-1'),(144,145,0,'searchSimple.title.extended'),(145,146,0,'/WEB-INF/templates/search_extended/search_ext_adr_info.vm'),(146,147,0,'searchExtAdr.info.title'),(147,148,0,'ext-search-area-1'),(148,149,0,'searchSimple.title.extended'),(149,150,0,'/WEB-INF/templates/search_extended/search_ext_env_area_contents_info.vm'),(150,151,0,'searchExtEnvAreaContents.info.title'),(151,152,0,'ext-search-area-1'),(152,153,0,'searchSimple.title.extended'),(153,154,0,'/WEB-INF/templates/search_extended/search_ext_env_area_partner_info.vm'),(154,155,0,'searchExtEnvAreaPartner.info.title'),(155,156,0,'ext-search-area-1'),(156,157,0,'searchSimple.title.extended'),(157,158,0,'/WEB-INF/templates/search_extended/search_ext_env_area_sources_info.vm'),(158,159,0,'searchExtEnvAreaSources.info.title'),(159,160,0,'ext-search-spacial-1'),(160,161,0,'searchSimple.title.extended'),(161,162,0,'/WEB-INF/templates/search_extended/search_ext_env_place_geothesaurus_info.vm'),(162,163,0,'searchExtEnvPlaceGeothesaurus.info.title'),(163,164,0,'ext-search-spacial-1'),(164,165,0,'searchSimple.title.extended'),(165,166,0,'ext-search-time-1'),(166,167,0,'searchSimple.title.extended'),(167,168,0,'/WEB-INF/templates/search_extended/search_ext_env_time_constraint_info.vm'),(168,169,0,'searchExtEnvTimeConstraint.info.title'),(169,170,0,'ext-search-subject-1'),(170,171,0,'searchSimple.title.extended'),(171,172,0,'/WEB-INF/templates/search_extended/search_ext_env_topic_terms_info.vm'),(172,173,0,'searchExtEnvTopicTerms.info.title'),(173,174,0,'ext-search-subject-1'),(174,175,0,'searchSimple.title.extended'),(175,176,0,'/WEB-INF/templates/search_extended/search_ext_env_topic_thesaurus_info.vm'),(176,177,0,'searchExtEnvTopicThesaurus.info.title'),(177,178,0,'ext-search-area-1'),(178,179,0,'searchSimple.title.extended'),(179,180,0,'/WEB-INF/templates/search_extended/search_ext_law_area_partner_info.vm'),(180,181,0,'searchExtEnvAreaPartner.info.title'),(181,182,0,'ext-search-subject-1'),(182,183,0,'searchSimple.title.extended'),(183,184,0,'/WEB-INF/templates/search_extended/search_ext_law_topic_terms_info.vm'),(184,185,0,'searchExtEnvTopicTerms.info.title'),(185,186,0,'ext-search-subject-1'),(186,187,0,'searchSimple.title.extended'),(187,188,0,'/WEB-INF/templates/search_extended/search_ext_law_topic_thesaurus_info.vm'),(188,189,0,'searchExtEnvTopicThesaurus.info.title'),(189,190,0,'ext-search-research-2'),(190,191,0,'searchSimple.title.extended'),(191,192,0,'/WEB-INF/templates/search_extended/search_ext_res_topic_attributes_info.vm'),(192,193,0,'searchExtResTopicAttributes.info.title'),(193,194,0,'ext-search-research-1'),(194,195,0,'searchSimple.title.extended'),(195,196,0,'/WEB-INF/templates/search_extended/search_ext_res_topic_terms_info.vm'),(196,197,0,'searchExtResTopicTerms.info.title'),(201,201,0,'block--padded'),(202,202,0,'content ob-container ob-box-narrow ob-box-center'),(203,203,0,'block--padded'),(204,204,0,'block--padded'),(205,205,0,'h1'),(206,206,0,'h1'),(207,207,0,'h1');
/*!40000 ALTER TABLE `fragment_pref_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fragment_prop`
--

DROP TABLE IF EXISTS `fragment_prop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fragment_prop` (
  `PROP_ID` int(11) NOT NULL,
  `FRAGMENT_ID` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `SCOPE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCOPE_VALUE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PROP_ID`),
  UNIQUE KEY `UN_FRAGMENT_PROP_1` (`FRAGMENT_ID`,`NAME`,`SCOPE`,`SCOPE_VALUE`),
  KEY `IX_FRAGMENT_PROP_1` (`FRAGMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragment_prop`
--

LOCK TABLES `fragment_prop` WRITE;
/*!40000 ALTER TABLE `fragment_prop` DISABLE KEYS */;
/*!40000 ALTER TABLE `fragment_prop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_anniversary`
--

DROP TABLE IF EXISTS `ingrid_anniversary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_anniversary` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `topic_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `topic_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_from_year` mediumint(9) DEFAULT NULL,
  `date_from_month` mediumint(9) DEFAULT NULL,
  `date_from_day` mediumint(9) DEFAULT NULL,
  `date_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_to_year` mediumint(9) DEFAULT NULL,
  `date_to_month` mediumint(9) DEFAULT NULL,
  `date_to_day` mediumint(9) DEFAULT NULL,
  `administrative_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fetched` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fetched_for` datetime NOT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT 'de',
  PRIMARY KEY (`id`),
  KEY `IX_ingrid_anniversary_1` (`fetched_for`),
  KEY `IX_ingrid_anniversary_2` (`language`)
) ENGINE=MyISAM AUTO_INCREMENT=1217 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_anniversary`
--

LOCK TABLES `ingrid_anniversary` WRITE;
/*!40000 ALTER TABLE `ingrid_anniversary` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingrid_anniversary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_chron_eventtypes`
--

DROP TABLE IF EXISTS `ingrid_chron_eventtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_chron_eventtypes` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `form_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_chron_eventtypes`
--

LOCK TABLES `ingrid_chron_eventtypes` WRITE;
/*!40000 ALTER TABLE `ingrid_chron_eventtypes` DISABLE KEYS */;
INSERT INTO `ingrid_chron_eventtypes` VALUES (1,'act','activity',1),(2,'his','historical',2),(3,'leg','legal',3),(5,'dis','disaster',4),(6,'cfe','conference',5),(8,'yea','natureOfTheYear',6),(9,'pub','publication',7),(13,'ann','anniversary',8),(14,'int','interYear',9),(15,'obs','observation',10);
/*!40000 ALTER TABLE `ingrid_chron_eventtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_cms`
--

DROP TABLE IF EXISTS `ingrid_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_cms` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `item_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `item_changed_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_cms`
--

LOCK TABLES `ingrid_cms` WRITE;
/*!40000 ALTER TABLE `ingrid_cms` DISABLE KEYS */;
INSERT INTO `ingrid_cms` VALUES (1,'ingrid.teaser.inform','InGrid informiert Text','2018-04-04 00:00:00','admin'),(15,'ingrid.disclaimer','Impressum','2018-04-04 00:00:00','admin'),(16,'ingrid.about','Über InGrid','2018-04-04 00:00:00','admin'),(17,'ingrid.privacy','Haftungsausschluss','2018-04-04 00:00:00','admin'),(18,'ingrid.contact.intro.postEmail','Adresse auf der Kontaktseite','2018-04-04 00:00:00','admin'),(19,'ingrid.home.welcome','Ingrid Willkommens Portlet','2006-09-14 22:00:00','admin'),(20,'portal.teaser.shortcut','Anwendungen','2011-10-28 07:44:44','admin'),(21,'portal.teaser.shortcut.query','Schnellsuche','2011-10-28 07:44:44','admin'),(25,'portal.cms.portlet.3','Anwendungen Übersicht','2016-12-13 14:30:28','admin'),(23,'portal.cms.portlet.1','Anleitungen','2016-12-13 14:30:28','admin'),(24,'portal.cms.portlet.2','Veranstaltungen','2016-12-13 14:30:28','admin');
/*!40000 ALTER TABLE `ingrid_cms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_cms_item`
--

DROP TABLE IF EXISTS `ingrid_cms_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_cms_item` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `fk_ingrid_cms_id` mediumint(9) NOT NULL,
  `item_lang` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `item_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_value` text COLLATE utf8_unicode_ci,
  `item_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `item_changed_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_cms_item`
--

LOCK TABLES `ingrid_cms_item` WRITE;
/*!40000 ALTER TABLE `ingrid_cms_item` DISABLE KEYS */;
INSERT INTO `ingrid_cms_item` VALUES (1,1,'de','<span style=\'text-transform: none;\'>InGrid INFORMIERT</span>','<p>Bitte ergänzen...</p>','2018-04-04 00:00:00','admin'),(2,1,'en','<span style=\'text-transform: none;\'>InGrid informs</span>','<p>Please complete...</p>','2018-04-04 00:00:00','admin'),(27,15,'en','Disclaimer','Please complete...','2018-04-04 00:00:00','admin'),(28,15,'de','Impressum','Bitte ergänzen...','2018-04-04 00:00:00','admin'),(29,16,'de','Über InGrid','Bitte ergänzen...','2018-04-04 00:00:00','admin'),(30,16,'en','About InGrid','Please complete...','2018-04-04 00:00:00','admin'),(31,17,'de','Datenschutz','Bitte ergänzen...','2018-04-04 00:00:00','admin'),(32,17,'en','Privacy','Please complete...','2018-04-04 00:00:00','admin'),(33,18,'de','','Bitte ergänzen...','2018-04-04 00:00:00','admin'),(34,18,'en','','Please complete...','2018-04-04 00:00:00','admin'),(35,19,'de','Willkommen bei PortalU','<p>Willkommen bei PortalU, dem Umweltportal Deutschland! Wir bieten Ihnen einen zentralen Zugriff auf mehrere hunderttausend Internetseiten und Datenbankeinträge von öffentlichen Institutionen und Organisationen. Zusätzlich können Sie aktuelle Nachrichten und Veranstaltungshinweise, Umweltmesswerte, Hintergrundinformationen und historische Umweltereignisse über PortalU abrufen.</p><p>Die integrierte Suchmaschine ist eine zentrale Komponente von PortalU. Mit ihrer Hilfe können Sie Webseiten und Datenbankeinträge nach Stichworten durchsuchen. Über die Option \"Erweiterte Suche\" können Sie zusätzlich ein differenziertes Fachvokabular und deutschlandweite Hintergrundkarten zur Zusammenstellung Ihrer Suchanfrage nutzen.</p><p>PortalU ist eine Kooperation der Umweltverwaltungen im Bund und in den Ländern. Inhaltlich und technisch wird PortalU von der <a href=\"http://www.kst.portalu.de/\" target=\"_new\" title=\"Link öffnet in neuem Fenster\">Koordinierungsstelle PortalU</a> im Niedersächsischen Ministerium für Umwelt und Klimaschutz verwaltet. Wir sind darum bemüht, das System kontinuierlich zu erweitern und zu optimieren. Bei Fragen und Verbesserungsvorschlägen wenden Sie sich bitte an die <a href=\"mailto:kst@portalu.de\">Koordinierungsstelle PortalU</a>.</p>','2011-04-27 10:25:05','admin'),(36,19,'en','Welcome to PortalU','<p>Welcome to PortalU, the German Environmental Information Portal! We offer a comfortable and central access to over 1.000.000 web-pages and database entries from public agencies in Germany. We also guide you directly to up-to-date environmental news, upcoming and past environmental events, environmental monitoring data, and interesting background information on many environmental topics.</p><p>Core-component of PortalU is a powerful search-engine that you can use to look up your terms of interest in web-pages and databases. In the \"Extended Search\" mode, you can use an environmental thesaurus and a digital mapping tool to compose complex spatio-thematic queries.</p><p>PortalU is the result of a cooperation between the German \"Länder\" and the German Federal Government. The project is managed by the <a href=\"http://www.kst.portalu.de/\" target=\"_new\" title=\"Link opens new window\">Coordination Center PortalU</a>, a group of environmental and IT experts attached to the Environment Ministry of Lower Saxony in Hannover, Germany. We strive to continuously improve and extend the portal. Please help us in this effort and mail your suggestions or questions to <a href=\"mailto:kst@portalu.de\">Coordination Center PortalU</a>.</p>','2006-09-14 22:00:00','admin'),(37,20,'de','Anwendungen','','2011-10-28 07:44:44','admin'),(38,20,'en','Application','','2011-10-28 07:44:44','admin'),(39,21,'de','Schnellsuche','','2011-10-28 07:44:44','admin'),(40,21,'en','Quick Search','','2011-10-28 07:44:44','admin'),(48,25,'en','CMSPortlet3','','2016-12-13 14:30:28','admin'),(47,25,'de','CMSPortlet3','','2016-12-13 14:30:28','admin'),(43,23,'de','CMSPortlet1','','2012-10-04 09:27:07','admin'),(44,23,'en','CMSPortlet1','','2012-10-04 09:27:07','admin'),(45,24,'de','CMSPortlet2','','2012-10-04 09:27:07','admin'),(46,24,'en','CMSPortlet2','','2012-10-04 09:27:07','admin');
/*!40000 ALTER TABLE `ingrid_cms_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_env_topic`
--

DROP TABLE IF EXISTS `ingrid_env_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_env_topic` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `form_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_env_topic`
--

LOCK TABLES `ingrid_env_topic` WRITE;
/*!40000 ALTER TABLE `ingrid_env_topic` DISABLE KEYS */;
INSERT INTO `ingrid_env_topic` VALUES (1,'abf','abfall',1),(2,'alt','altlasten',2),(3,'bau','bauen',3),(4,'bod','boden',4),(5,'che','chemikalien',5),(6,'ene','energie',6),(7,'for','forstwirtschaft',7),(8,'gen','gentechnik',8),(9,'geo','geologie',9),(10,'ges','gesundheit',10),(11,'lae','laermerschuetterung',11),(12,'lan','landwirtschaft',12),(13,'luf','luftklima',13),(14,'nac','nachhaltigeentwicklung',14),(15,'nat','naturlandschaft',15),(16,'str','strahlung',16),(17,'tie','tierschutz',17),(18,'uin','umweltinformation',18),(19,'uwi','umweltwirtschaft',19),(20,'ver','verkehr',20),(21,'was','wasser',21);
/*!40000 ALTER TABLE `ingrid_env_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_lookup`
--

DROP TABLE IF EXISTS `ingrid_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_lookup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_lookup`
--

LOCK TABLES `ingrid_lookup` WRITE;
/*!40000 ALTER TABLE `ingrid_lookup` DISABLE KEYS */;
INSERT INTO `ingrid_lookup` VALUES (1,'ingrid_db_version','4.2.0','2018-04-04 16:26:47');
/*!40000 ALTER TABLE `ingrid_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_measures_rubric`
--

DROP TABLE IF EXISTS `ingrid_measures_rubric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_measures_rubric` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `form_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_measures_rubric`
--

LOCK TABLES `ingrid_measures_rubric` WRITE;
/*!40000 ALTER TABLE `ingrid_measures_rubric` DISABLE KEYS */;
INSERT INTO `ingrid_measures_rubric` VALUES (1,'str','radiation',1),(2,'luf','air',2),(3,'was','water',3),(4,'wei','misc',4);
/*!40000 ALTER TABLE `ingrid_measures_rubric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_newsletter_data`
--

DROP TABLE IF EXISTS `ingrid_newsletter_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_newsletter_data` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IX_email_1` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_newsletter_data`
--

LOCK TABLES `ingrid_newsletter_data` WRITE;
/*!40000 ALTER TABLE `ingrid_newsletter_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingrid_newsletter_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_partner`
--

DROP TABLE IF EXISTS `ingrid_partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_partner` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `ident` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_ingrid_partner_1` (`sortkey`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_partner`
--

LOCK TABLES `ingrid_partner` WRITE;
/*!40000 ALTER TABLE `ingrid_partner` DISABLE KEYS */;
INSERT INTO `ingrid_partner` VALUES (1,'bund','Bund',1),(2,'bw','Baden-Württemberg',2),(3,'by','Bayern',3),(4,'be','Berlin',4),(5,'bb','Brandenburg',5),(6,'hb','Bremen',6),(7,'hh','Hamburg',7),(8,'he','Hessen',8),(9,'mv','Mecklenburg-Vorpommern',9),(10,'ni','Niedersachsen',10),(11,'nw','Nordrhein-Westfalen',11),(12,'rp','Rheinland-Pfalz',12),(13,'sl','Saarland',13),(14,'sn','Sachsen',14),(15,'st','Sachsen-Anhalt',15),(16,'sh','Schleswig-Holstein',16),(17,'th','Thüringen',17);
/*!40000 ALTER TABLE `ingrid_partner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_principal_pref`
--

DROP TABLE IF EXISTS `ingrid_principal_pref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_principal_pref` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `principal_name` varchar(251) COLLATE utf8_unicode_ci NOT NULL,
  `pref_name` varchar(251) COLLATE utf8_unicode_ci NOT NULL,
  `pref_value` mediumtext COLLATE utf8_unicode_ci,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_principal_pref`
--

LOCK TABLES `ingrid_principal_pref` WRITE;
/*!40000 ALTER TABLE `ingrid_principal_pref` DISABLE KEYS */;
INSERT INTO `ingrid_principal_pref` VALUES (1,'admin','searchSources','<map>\n  <entry>\n    <string>sources</string>\n    <string-array/>\n  </entry>\n  <entry>\n    <string>meta</string>\n    <string-array/>\n  </entry>\n</map>','2011-08-31 10:45:24');
/*!40000 ALTER TABLE `ingrid_principal_pref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_provider`
--

DROP TABLE IF EXISTS `ingrid_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_provider` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `ident` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  `sortkey_partner` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_ingrid_provider_1` (`sortkey_partner`),
  KEY `IX_ingrid_provider_2` (`sortkey`),
  KEY `IX_ingrid_provider_3` (`ident`)
) ENGINE=MyISAM AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_provider`
--

LOCK TABLES `ingrid_provider` WRITE;
/*!40000 ALTER TABLE `ingrid_provider` DISABLE KEYS */;
INSERT INTO `ingrid_provider` VALUES (1,'bu_bmu','Bundesministerium für Umwelt, Naturschutz und Reaktorsicherheit','http://www.bmu.de/',1,1),(2,'bu_uba','Umweltbundesamt','http://www.umweltbundesamt.de/',2,1),(3,'bu_bfn','Bundesamt für Naturschutz','http://www.bfn.de/',3,1),(4,'bu_bfs','Bundesamt für Strahlenschutz','http://www.bfs.de/',4,1),(5,'bu_bmf','Bundesministerium der Finanzen','http://www.bundesfinanzministerium.de/',5,1),(6,'bu_bmbf','Bundesministerium für Bildung und Forschung','http://www.bmbf.de/',6,1),(7,'bu_bmelv','Bundesministerium für Ernährung, Landwirtschaft und Verbraucherschutz','http://www.bmelv.de/cln_044/DE/00-Home/__Homepage__node.html__nnn=true',7,1),(8,'bu_bmz','Bundesministerium für wirtschaftliche Zusammenarbeit und Entwicklung','http://www.bmz.de/',8,1),(9,'bu_aa','Auswärtiges Amt','http://www.auswaertiges-amt.de/',10,1),(10,'bu_bsh','Bundesamt für Seeschifffahrt und Hydrographie','http://www.bsh.de/',11,1),(11,'bu_bvl','Bundesamt für Verbraucherschutz und Lebensmittelsicherheit','http://www.bvl.bund.de/',12,1),(12,'bu_bgr','Bundesanstalt für Geowissenschaften und Rohstoffe','http://www.bgr.bund.de/',13,1),(13,'bu_bfg','Bundesanstalt für Gewässerkunde','http://www.bafg.de/',14,1),(14,'bu_nokis','Bundesanstalt für Wasserbau - Dienststelle Hamburg','http://www.hamburg.baw.de/',15,1),(15,'bu_bfr','Bundesinstitut für Risikobewertung','http://www.bfr.bund.de/',16,1),(16,'bu_bka','Bundeskriminalamt','http://www.bka.de/',17,1),(17,'bu_rki','Robert-Koch-Institut','http://www.rki.de/',18,1),(18,'bu_stba','Statistisches Bundesamt','http://www.destatis.de/',19,1),(19,'bu_ble','Bundesanstalt für Landwirtschaft und Ernährung','http://www.ble.de',20,1),(20,'bu_bpb','Bundeszentrale für politische Bildung','http://www.bpb.de/',21,1),(21,'bu_gtz','Deutsche Gesellschaft für Technische Zusammenarbeit (GTZ) GmbH','http://www.gtz.de/',22,1),(22,'bu_dwd','Deutscher Wetterdienst','http://www.dwd.de/',23,1),(23,'bu_dlr','Deutsches Zentrum für Luft- und Raumfahrt DLR e.V.','http://www.dlr.de/',24,1),(24,'bu_kug','Koordinierungsstelle PortalU','http://www.kst.portalu.de/',25,1),(25,'bu_labo','Länderarbeitsgemeinschaft Boden LABO','http://www.labo-deutschland.de/',26,1),(26,'bu_lawa','Länderarbeitsgemeinschaft Wasser','http://www.lawa.de/',27,1),(27,'bu_laofdh','Leitstelle des Bundes für Abwassertechnik, Boden- und Grundwasserschutz, Kampfmittelräumung und das Liegenschaftsinformationssystem Außenanlagen LISA','http://www.ofd-hannover.de/la/',28,1),(28,'bu_bpa','Presse- und Informationsamt der Bundesregierung','http://www.bundesregierung.de/',29,1),(29,'bu_blauerengel','RAL/Umweltbundesamt Umweltzeichen \"Blauer Engel\"','http://www.blauer-engel.de/',30,1),(30,'bu_sru','Rat von Sachverständigen für Umweltfragen (SRU)','http://www.umweltrat.de/',31,1),(31,'bu_ssk','Strahlenschutzkommission','http://www.ssk.de/',32,1),(32,'bu_umk','Umweltministerkonferenz','http://www.umweltministerkonferenz.de/',33,1),(33,'bu_wbgu','Wissenschaftlicher Beirat der Bundesregierung Globale Umweltveränderungen - WBGU','http://www.wbgu.de/',34,1),(34,'bu_agenda','Agenda-Transfer. Agentur für Nachhaltigkeit GmbH','http://www.agenda-transfer.de/',35,1),(35,'bu_uga','Umweltgutachterausschuss (UGA)','http://www.uga.de/',36,1),(36,'bu_co2','co2online gGmbH Klimaschutzkampagne','http://www.co2online.de/',37,1),(37,'bu_dekade','Weltdekade ?Bildung für nachhaltige Entwicklung?','http://www.dekade.org/index.htm',38,1),(38,'bw_um','Umweltministerium Baden-Württemberg','http://www.um.baden-wuerttemberg.de/',1,2),(39,'bw_mi','Innenministerium Baden-Württemberg','http://www.innenministerium.baden-wuerttemberg.de/',2,2),(40,'bw_mlr','Ministerium für Ernährung und Ländlichen Raum Baden-Württemberg','http://www.mlr.baden-wuerttemberg.de/',3,2),(41,'bw_mw','Wirtschaftsministerium Baden-Württemberg','http://www.wm.baden-wuerttemberg.de/',4,2),(42,'bw_lu','Landesanstalt für Umwelt, Messungen und Naturschutz Baden-Württemberg','http://www.lubw.baden-wuerttemberg.de/',5,2),(43,'bw_lgrb','Regierungspräsidium Freiburg - Abt. 9 Landesamt für Geologie, Rohstoffe und Boden','http://www.lgrb.uni-freiburg.de/lgrb/home/index_html',6,2),(44,'bw_lvm','Landesvermessungsamt Baden-Württemberg','http://www.lv-bw.de/lvshop2/index.htm',7,2),(45,'bw_lel','Informationsdienst der Landwirtschaftsverwaltung Baden-Württemberg','http://www.landwirtschaft-mlr.baden-wuerttemberg.de/servlet/PB/-s/153h2f7ajcsu0yhrl7ib9karcotj9kv/menu/1034707_l1/index.html',8,2),(46,'bw_gaa','Gewerbeaufsicht Baden-Württemberg','http://www.gewerbeaufsicht.baden-wuerttemberg.de/',9,2),(47,'bw_stla','Statistisches Landesamt Baden-Württemberg','http://www.statistik-bw.de/',10,2),(48,'bw_fzk','Forschungszentrum Karlsruhe GmbH','http://www.fzk.de/',11,2),(49,'by_sugv','Bayerisches Staatsministerium für Umwelt, Gesundheit und Verbraucherschutz','http://www.stmugv.bayern.de/',1,3),(50,'by_gla','Bayerisches Geologisches Landesamt','http://www.geologie.bayern.de/',2,3),(51,'by_lfstad','Bayerisches Landesamt für Statistik und Datenverarbeitung','http://www.statistik.bayern.de/',3,3),(52,'by_lfu','Bayerisches Landesamt für Umweltschutz','http://www.bayern.de/lfu/',4,3),(53,'by_lfw','Bayerisches Landesamt für Wasserwirtschaft','http://www.bayern.de/lfw',5,3),(54,'by_brrhoen','Biosphärenreservat Rhön','http://www.biosphaerenreservat-rhoen.de/',6,3),(55,'by_npbayw','Nationalpark Bayerischer Wald','http://www.nationalpark-bayerischer-wald.de/',7,3),(56,'by_npbg','Nationalpark Berchtesgaden','http://www.nationalpark-berchtesgaden.de/',8,3),(57,'be_senst','Senatsverwaltung für Stadtentwicklung','http://www.stadtentwicklung.berlin.de/umwelt/',1,4),(58,'be_snb','Stiftung Naturschutz Berlin','http://www.stiftung-naturschutz.de/',2,4),(59,'be_uacw','Amt für Umwelt, Natur und Verkehr Charlottenburg-Wilmersdorf','http://www.charlottenburg-wilmersdorf.de/umweltamt',3,4),(60,'bb_mluv','Ministerium für Ländliche Entwicklung, Umwelt und Verbraucherschutz des Landes Brandenburg','http://www.mluv.brandenburg.de/',1,5),(61,'hb_sbu','Senator für Bau und Umwelt Bremen','http://www.umwelt.bremen.de/buisy/scripts/buisy.asp',1,6),(62,'hh_su','Behörde für Stadtentwicklung und Umwelt Hamburg','http://fhh.hamburg.de/stadt/Aktuell/behoerden/stadtentwicklung-umwelt/start.html',1,7),(63,'hh_wa','Behörde für Wirtschaft und Arbeit Hamburg','http://fhh.hamburg.de/stadt/Aktuell/behoerden/wirtschaft-arbeit/start.html',2,7),(64,'hh_bsg','Behörde für Soziales, Familie, Gesundheit und Verbraucherschutz','http://fhh.hamburg.de/stadt/Aktuell/behoerden/bsg/start.html',3,7),(65,'hh_lgv','Landesbetrieb Geoinformation und Vermessung Hamburg','http://fhh.hamburg.de/stadt/Aktuell/weitere-einrichtungen/landesbetrieb-geoinformation-und-vermessung',4,7),(66,'hh_npwatt','Nationalpark Hamburgisches Wattenmeer','http://fhh1.hamburg.de/Behoerden/Umweltbehoerde/nphw/',5,7),(67,'hh_argeelbe','Arbeitsgemeinschaft für die Reinhaltung der Elbe','http://www.arge-elbe.de/',6,7),(68,'hh_sth','Statistisches Amt für Hamburg und Schleswig-Holstein','http://www.statistik-nord.de/index.php?id=32',7,7),(69,'he_hmulv','Hessisches Ministerium für Umwelt, ländlichen Raum und Verbraucherschutz','http://www.hmulv.hessen.de/',1,8),(70,'he_hlug','Hessisches Landesamt für Umwelt und Geologie','http://www.hlug.de/',2,8),(71,'he_umwelt','Umweltatlas Hessen','http://atlas.umwelt.hessen.de/',3,8),(72,'mv_um','Umweltministerium Mecklenburg-Vorpommern','http://www.um.mv-regierung.de/',1,9),(73,'mv_sm','Sozialministerium Mecklenburg-Vorpommern','http://www.sozial-mv.de/',2,9),(74,'mv_lung','Landesamt für Umwelt, Naturschutz und Geologie Mecklenburg-Vorpommern (LUNG)','http://www.lung.mv-regierung.de/',3,9),(75,'mv_lfmv','Landesforst Mecklenburg-Vorpommern AöR','http://www.wald-mv.de/',4,9),(76,'mv_schaalsee','Amt für das Biosphärenreservat Schaalsee','http://www.schaalsee.de/',5,9),(77,'mv_npmueritz','Nationalparkamt Müritz','http://www.nationalpark-mueritz.de/',6,9),(78,'mv_nvblmv','Nationalparkamt Vorpommersche Boddenlandschaft','http://www.nationalpark-vorpommersche-bodde/nlandschaft.de/',7,9),(79,'mv_fhstr','Fachhochschule Stralsund','http://www.fh-stralsund.de/',8,9),(80,'mv_fhnb','Hochschule Neubrandenburg','http://www.fh-nb.de/',9,9),(81,'mv_hswi','Hochschule Wismar','http://www.hs-wismar.de/',10,9),(82,'mv_iow','Institut für Ostseeforschung Warnemünde','http://www.io-warnemuende/.de/',11,9),(83,'mv_unigr','Universität Greifswald','http://www.uni-greifswald.de/',12,9),(84,'mv_uniro','Universität Rostock','http://www.uni-rostock.de/',13,9),(85,'ni_mu','Niedersächsisches Umweltministerium','http://www.mu.niedersachsen.de/',1,10),(86,'ni_mw','Niedersächsisches Ministerium für Wirtschaft, Arbeit und Verkehr','http://www.mw.niedersachsen.de/',2,10),(87,'ni_ms','Niedersächsisches Ministerium für Soziales, Frauen, Familie und Gesundheit','http://www.ms.niedersachsen.de/',3,10),(88,'ni_mi','Niedersächsisches Ministerium für Inneres und Sport','http://www.mi.niedersachsen.de/',4,10),(89,'ni_ml','Niedersächsisches Ministerium für den ländlichen Raum, Ernährung, Landwirtschaft und Verbraucherschutz','http://www.ml.niedersachsen.de/',5,10),(90,'ni_nlwkn','Niedersächsischer Landesbetrieb für Wasserwirtschaft, Küsten- und Naturschutz','http://www.nlwkn.de/',6,10),(91,'ni_lbeg','Landesamt für Bergbau, Energie und Geologie','http://www.lbeg.niedersachsen.de/master/C17456312_L20_D0.html',7,10),(92,'ni_nls','Niedersächsisches Landesamt für Statistik','http://www.nls.niedersachsen.de/',8,10),(93,'ni_laves','Niedersächsisches Landesamt für Verbraucherschutz und Lebensmittelsicherheit','http://www.laves.niedersachsen.de/',9,10),(94,'ni_lga','Niedersächsisches Landesgesundheitsamt','http://www.nlga.niedersachsen.de/',10,10),(95,'ni_sbv','Niedersächsische Landesbehörde für Straßenbau und Verkehr','http://www.strassenbau.niedersachsen.de/',11,10),(96,'ni_nna','Alfred Toepfer Akademie für Naturschutz','http://www.nna.de/',12,10),(97,'ni_gll','Behörden für Geoinformation, Landentwicklung und Liegenschaften Niedersachsen','http://www.gll.niedersachsen.de',13,10),(98,'ni_gga','Institut für Geowissenschaftliche Gemeinschaftsaufgaben ','http://www.gga-hannover.de',14,10),(99,'ni_lgn','Landesvermessung und Geobasisinformation Niedersachsen','http://www.lgn.niedersachsen.de/',15,10),(100,'ni_lwkh','Landwirtschaftskammer Hannover','http://www.lwk-hannover.de/',16,10),(101,'ni_npwatt','Nationalpark Wattenmeer','http://www.nationalpark-wattenmeer.niedersachsen.de/master/C5912120_L20_D0.html',17,10),(102,'ni_npharz','Nationalparkverwaltung Harz','http://www.nationalpark-harz.de/',18,10),(103,'ni_gaa','Niedersächsische Gewerbeaufsicht','http://www.gewerbeaufsicht.niedersachsen.de/master/C1717445_N1717446_L20_D0_I1717444.html',19,10),(104,'ni_elbtal','Biosphärenreservat Elbtalaue','http://www.elbtalaue.niedersachsen.de/master/C6933729_L20_D0.html',20,10),(105,'nw_munlv','Ministerium für Umwelt und Naturschutz, Landwirtschaft und Verbraucherschutz des Landes Nordrhein-Westfalen','http://www.munlv.nrw.de/',1,11),(106,'nw_lua','Landesumweltamt Nordrhein-Westfalen','http://www.lua.nrw.de/',2,11),(107,'nw_loebf','Landesanstalt für Ökologie, Bodenordnung und Forsten des Landes Nordrhein-Westfalen (LÖBF)','http://www.loebf.nrw.de/',3,11),(108,'nw_gd','Geologischer Dienst Nordrhein-Westfalen','http://www.gd.nrw.de/',4,11),(109,'nw_stuaha','Staatliches Umweltamt Hagen','http://www.stua-ha.nrw.de/',5,11),(110,'nw_stualp','Staatliches Umweltamt Lippstadt','http://www.stua-lp.nrw.de/',6,11),(111,'nw_ldvst','Landesamt für Datenverarbeitung und Statistik Nordrhein-Westfalen','http://www.ugrdl.de/index.html',7,11),(112,'rp_mufv','Ministerium für Umwelt, Forsten und Verbraucherschutz Rheinland-Pfalz','http://www.mufv.rlp.de/',1,12),(115,'rp_forst','Landesforsten Rheinland-Pfalz','http://www.wald-rlp.de/',2,12),(116,'rp_lzu','Landeszentrale für Umweltaufklärung Rheinland-Pfalz','http://www.umdenken.de/',3,12),(117,'sl_mfu','Ministerium für Umwelt Saarland','http://www.umwelt.saarland.de/',1,13),(118,'sl_lua','Landesamt für Umwelt- und Arbeitsschutz Saarland','http://www.lua.saarland.de/',2,13),(119,'sn_smul','Sächsisches Staatsministerium für Umwelt und Landwirtschaft','http://www.umwelt.sachsen.de/de/wu/umwelt/index.html',1,14),(120,'sn_lfug','Sächsisches Landesamt für Umwelt und Geologie','http://www.umwelt.sachsen.de/lfug/',2,14),(121,'sn_lanu','Sächsische Landesstiftung Natur und Umwelt','http://www.lanu.de/templates/intro.php',3,14),(122,'st_mlu','Ministerium für Landwirtschaft und Umwelt Sachsen-Anhalt','http://www.sachsen-anhalt.de/rcs/LSA/pub/Ch1/fld8311011390180834/mainfldmtgpollxof/pgnotsi64lb6/index.jsp',1,15),(123,'st_lau','Landesamt für Umweltschutz Sachsen-Anhalt','http://www.mu.sachsen-anhalt.de/lau/de/fault.htm',2,15),(124,'st_lue','Luftüberwachungssystem Sachsen-Anhalt','http://www.mu.sachsen-anhalt.de/lau/luesa/',3,15),(125,'st_unimd','Otto-von-Guericke Universität Magdeburg','http://www.uni-magde/burg.de/',4,15),(126,'sh_munl','Ministerium für Landwirtschaft, Umwelt und ländliche Räume des Landes Schleswig-Holstein','http://www.umwelt.schleswig-holstein.de/servlet/is/154/',1,16),(127,'sh_lanu','Landesamt für Natur und Umwelt Schleswig-Holstein','http://www.lanu.landsh.de/',2,16),(128,'sh_luesh','Lufthygienische Überwachung Schleswig-Holstein','http://www.umwelt.schleswig-holstein.de/?196',3,16),(129,'sh_kfue','Kernreaktorfernüberwachung Schleswig-Holstein','http://www.kfue-sh.de/',4,16),(130,'sh_umweltaka','Akademie für Natur und Umwelt des Landes Schleswig-Holstein','http://www.umweltakademie-sh.de/',5,16),(131,'sh_npa','Nationalpark Schleswig-Holsteinisches Wattenmeer','http://www.wattenmeer-nationalpark.de/',6,16),(132,'th_tmlnu','Thüringer Ministerium für Landwirtschaft, Naturschutz und Umwelt','http://www.thueringen.de/de/tmlnu/',1,17),(133,'th_tlug','Thüringer Landesanstalt für Umwelt und Geologie','http://www.tlug-jena.de/index.html',2,17),(134,'ni_geomdk','geoMDK Niedersachsen','http://www.geomdk.niedersachsen.de/',21,10),(137,'rp_luwg','Landesamt für Umwelt, Wasserwirtschaft und Gewerbeaufsicht Rheinland-Pfalz','http://www.luwg.rlp.de/',4,12),(138,'rp_lua','Landesuntersuchungsamt Rheinland-Pfalz','http://www.lua.rlp.de/',5,12),(139,'bw_saa','SAA Sonderabfallagentur','http://www.saa.de/',12,2),(140,'bw_rp','Regierungspräsidien Baden-Württemberg','http://www.rp.baden-wuerttemberg.de/',13,2),(141,'bw_rps','Regierungspräsidium Stuttgart','http://www.landentwicklung-mlr.baden-wuerttemberg.de/',14,2);
/*!40000 ALTER TABLE `ingrid_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_rss_source`
--

DROP TABLE IF EXISTS `ingrid_rss_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_rss_source` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1023) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numLastCount` smallint(3) DEFAULT NULL,
  `lastUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_rss_source`
--

LOCK TABLES `ingrid_rss_source` WRITE;
/*!40000 ALTER TABLE `ingrid_rss_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingrid_rss_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_rss_store`
--

DROP TABLE IF EXISTS `ingrid_rss_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_rss_store` (
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(1023) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `published_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` varchar(1023) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`link`),
  KEY `IX_ingrid_rss_store_1` (`published_date`),
  KEY `IX_ingrid_rss_store_2` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_rss_store`
--

LOCK TABLES `ingrid_rss_store` WRITE;
/*!40000 ALTER TABLE `ingrid_rss_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingrid_rss_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_service_rubric`
--

DROP TABLE IF EXISTS `ingrid_service_rubric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_service_rubric` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `form_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortkey` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_service_rubric`
--

LOCK TABLES `ingrid_service_rubric` WRITE;
/*!40000 ALTER TABLE `ingrid_service_rubric` DISABLE KEYS */;
INSERT INTO `ingrid_service_rubric` VALUES (1,'pre','press',1),(2,'pub','publication',2),(3,'ver','event',3);
/*!40000 ALTER TABLE `ingrid_service_rubric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrid_tiny_url`
--

DROP TABLE IF EXISTS `ingrid_tiny_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrid_tiny_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_ref` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `tiny_key` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `tiny_name` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `tiny_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tiny_config` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrid_tiny_url`
--

LOCK TABLES `ingrid_tiny_url` WRITE;
/*!40000 ALTER TABLE `ingrid_tiny_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingrid_tiny_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jetspeed_service`
--

DROP TABLE IF EXISTS `jetspeed_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jetspeed_service` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jetspeed_service`
--

LOCK TABLES `jetspeed_service` WRITE;
/*!40000 ALTER TABLE `jetspeed_service` DISABLE KEYS */;
INSERT INTO `jetspeed_service` VALUES (54,22,'UserManager'),(55,22,'RoleManager'),(56,22,'GroupManager'),(57,22,'Profiler'),(58,22,'PortletRegistryComponent'),(59,22,'PageManager'),(60,22,'PortalAdministration'),(61,22,'PermissionManager'),(81,41,'UserManager'),(82,41,'RoleManager'),(83,41,'GroupManager'),(84,41,'Profiler'),(85,41,'PortletRegistryComponent'),(86,41,'PageManager'),(87,41,'PortalAdministration'),(88,41,'PermissionManager'),(101,61,'IdGenerator'),(102,61,'PortletRegistryComponent'),(103,61,'PageManager'),(104,61,'TemplateLocator'),(105,61,'DecorationLocator'),(106,61,'Powertools'),(107,61,'DecorationFactory'),(108,61,'EntityAccessor'),(109,61,'WindowAccessor'),(110,61,'Desktop'),(111,61,'decorationContentCache'),(112,61,'portletContentCache'),(113,61,'PortalConfiguration');
/*!40000 ALTER TABLE `jetspeed_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `ID` int(11) NOT NULL,
  `PORTLET_ID` int(11) NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SUPPORTED_LOCALE` smallint(6) NOT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES (159,139,'en,,',0,'mdek','mdek','mdek'),(160,140,'en,,',0,'mdek','mdek','mdek'),(161,141,'en,,',0,'mdek','mdek','mdek'),(241,201,'en,,',0,'Info Portlet','Info Portlet','Information'),(242,202,'en,,',0,'javascript detection portlet','javascript detection portlet',NULL),(243,203,'en,,',0,'Help Portlet','Help Portlet','Help Portlet'),(244,204,'en,,',0,'Jobübersicht','Jobübersicht',NULL),(245,205,'en,,',0,'RSS Feeds administrieren','RSS Feeds administrieren',NULL),(246,206,'en,,',0,'Partner administrieren','Partner administrieren',NULL),(247,207,'en,,',0,'Anbieter administrieren','Anbieter administrieren',NULL),(248,208,'en,,',0,'Benutzer administrieren','Benutzer administrieren',NULL),(249,209,'en,,',0,'iPlugs/iBus administrieren','iPlugs/iBus administrieren',NULL),(250,210,'en,,',0,'Inhalte administrieren','Inhalte administrieren',NULL),(251,211,'en,,',0,'WMS Administration','WMS Administration',NULL),(252,212,'en,,',0,'Statistiken','Statistiken',NULL),(253,213,'en,,',0,'Startseite administrieren','Startseite administrieren',NULL),(254,214,'en,,',0,'Portal Profile','Portal Profile',NULL),(255,215,'en,,',0,'Portal User Migration','Portal User Migration',NULL),(256,216,'en,,',0,'Search','Search','Search'),(257,217,'en,,',0,'Search','Search','Search'),(258,218,'en,,',0,'Search Result','Search Result','Search Result'),(259,219,'en,,',0,'Environmental Topics','Environmental Topics','Environmental Topics'),(260,220,'en,,',0,'Other News','RssNews','RssNews'),(261,221,'en,,',1,'Other News','RssNews','RssNews'),(262,221,'de,,',1,'Aktuelles','RssNews','RssNews'),(263,222,'en,,',0,'Info Portlet','Info Portlet','Information'),(264,223,'en,,',0,'Info Portlet','Info Portlet','Information'),(265,224,'en,,',0,'Info Portlet','Info Portlet','Information'),(266,225,'en,,',0,'Info Portlet','Info Portlet','Information'),(267,226,'en,,',0,'Info Portlet','Info Portlet','Information'),(268,227,'en,,',0,'Info Portlet','Info Portlet','Information'),(269,228,'en,,',0,'Info Portlet','Info Portlet','Information'),(270,229,'en,,',1,'Contact','Contact','Contact'),(271,229,'de,,',1,'Kontakt','Kontakt','Kontakt'),(272,230,'en,,',1,'Login','Login','Login'),(273,230,'de,,',1,'Anmeldung','Anmeldung','Anmeldung'),(274,231,'en,,',1,'Login','Login','Login'),(275,231,'de,,',1,'Anmeldung','Anmeldung','Anmeldung'),(276,232,'en,,',1,'Login','Login','Login'),(277,232,'de,,',1,'Anmeldung','Anmeldung','Anmeldung'),(278,233,'en,,',1,'Login','Login','Login'),(279,233,'de,,',1,'Anmeldung','Anmeldung','Anmeldung'),(280,234,'en,,',1,'Login','Login','Login'),(281,234,'de,,',1,'Anmeldung','Anmeldung','Anmeldung'),(282,235,'en,,',1,'Information Providers','Information Providers','Information Providers'),(283,235,'de,,',1,'Informationsanbieter','Informationsanbieter','Informationsanbieter'),(284,236,'en,,',1,'Data sources','Data sources','Data sources'),(285,236,'de,,',1,'Datenquellen','Datenquellen','Datenquellen'),(286,237,'en,,',1,'Environmental Monitoring Data','Environmental Monitoring Data','Environmental Monitoring Data'),(287,237,'de,,',1,'Messwerte','Messwerte','Messwerte'),(288,238,'en,,',0,'Karten','ShowMapsPortlet',NULL),(289,239,'en,,',1,'Environmental Almanac','Environmental Almanac','Environmental Almanac'),(290,239,'de,,',1,'Chronik','Chronik','Chronik'),(291,240,'en,,',0,'Environmental Almanac','Environmental Almanac','Environmental Almanac'),(292,241,'en,,',0,'Search Result','Search Result','Search Result'),(293,242,'en,,',0,'Search Result','Search Result','Search Result'),(294,243,'en,,',0,'Search','Search','Search'),(295,244,'en,,',0,'Data Catalogues','Data Catalogues','Data Catalogues'),(296,245,'en,,',0,'SprachUmsteller','LangSwitch',NULL),(297,246,'en,,',0,'SprachUmsteller','LangSwitch',NULL),(301,261,'en,,',0,'IngridClearLayout','IngridClearLayout',NULL),(302,262,'en,,',0,'IngridOneColumn','OneColumn',NULL),(303,263,'en,,',0,'IngridTwoColumns','IngridTwoColumns',NULL),(304,264,'en,,',0,'SimpleLayoutPortlet','SimpleLayout',NULL),(305,265,'en,,',0,'One Column','OneColumn',NULL),(306,266,'en,,',0,'One Column with Tables','OneColumnTable',NULL),(307,267,'en,,',0,'Two Columns','TwoColumns',NULL),(308,268,'en,,',0,'Two Columns (15%/85%)','Two Columns (15%/85%)',NULL),(309,269,'en,,',0,'Three Columns','ThreeColumns',NULL),(310,270,'en,,',0,'Three Columns with Tables','ThreeColumnsTable',NULL),(311,271,'en,,',0,'One Column - No Actions','OneColumnNoActions',NULL),(312,272,'en,,',0,'Two Columns - No Actions','TwoColumnsNoActions',NULL),(313,273,'en,,',0,'Three Columns - No Actions','ThreeColumnsNoActions',NULL),(314,274,'en,,',0,'Two Columns (25%/75%) No Actions','VelocityTwoColumns2575NoActions',NULL),(315,275,'en,,',0,'Two Columns (25%/75%)','VelocityTwoColumns2575',NULL),(316,276,'en,,',0,'Two Columns (15%,85%) No Actions','2 Columns 15,85 No Actions',NULL),(317,277,'en,,',0,'Two Columns with Tables','Two Columns Tables',NULL),(318,278,'en,,',0,'Four Columns','FourColumns',NULL);
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link`
--

DROP TABLE IF EXISTS `link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link` (
  `LINK_ID` int(11) NOT NULL,
  `PARENT_ID` int(11) NOT NULL,
  `PATH` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `VERSION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_HIDDEN` smallint(6) NOT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TARGET` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSITE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MEDIATYPE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_NAME` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_VALUE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OWNER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`LINK_ID`),
  UNIQUE KEY `UN_LINK_1` (`PATH`),
  KEY `IX_LINK_1` (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link`
--

LOCK TABLES `link` WRITE;
/*!40000 ALTER TABLE `link` DISABLE KEYS */;
INSERT INTO `link` VALUES (1,1,'/language.link','language.link',NULL,'ingrid.page.language','ingrid.page.language',0,NULL,'top','/default-page.psml',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,'/webmaster.link','webmaster.link',NULL,'ingrid.page.webmaster.tooltip','ingrid.page.webmaster',0,NULL,'top','mailto:info@informationgrid.eu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,1,'/home.link','home.link',NULL,'ingrid.page.home','ingrid.page.home',1,NULL,'top','/default-page.psml',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_constraint`
--

DROP TABLE IF EXISTS `link_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_constraint` (
  `CONSTRAINT_ID` int(11) NOT NULL,
  `LINK_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `USER_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CONSTRAINT_ID`),
  KEY `IX_LINK_CONSTRAINT_1` (`LINK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_constraint`
--

LOCK TABLES `link_constraint` WRITE;
/*!40000 ALTER TABLE `link_constraint` DISABLE KEYS */;
/*!40000 ALTER TABLE `link_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_constraints_ref`
--

DROP TABLE IF EXISTS `link_constraints_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_constraints_ref` (
  `CONSTRAINTS_REF_ID` int(11) NOT NULL,
  `LINK_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_REF_ID`),
  UNIQUE KEY `UN_LINK_CONSTRAINTS_REF_1` (`LINK_ID`,`NAME`),
  KEY `IX_LINK_CONSTRAINTS_REF_1` (`LINK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_constraints_ref`
--

LOCK TABLES `link_constraints_ref` WRITE;
/*!40000 ALTER TABLE `link_constraints_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `link_constraints_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_metadata`
--

DROP TABLE IF EXISTS `link_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_metadata` (
  `METADATA_ID` int(11) NOT NULL,
  `LINK_ID` int(11) NOT NULL,
  `NAME` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`METADATA_ID`),
  UNIQUE KEY `UN_LINK_METADATA_1` (`LINK_ID`,`NAME`,`LOCALE`,`VALUE`),
  KEY `IX_LINK_METADATA_1` (`LINK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_metadata`
--

LOCK TABLES `link_metadata` WRITE;
/*!40000 ALTER TABLE `link_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `link_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locale_encoding_mapping`
--

DROP TABLE IF EXISTS `locale_encoding_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locale_encoding_mapping` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENCODING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locale_encoding_mapping`
--

LOCK TABLES `locale_encoding_mapping` WRITE;
/*!40000 ALTER TABLE `locale_encoding_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `locale_encoding_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localized_description`
--

DROP TABLE IF EXISTS `localized_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localized_description` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `OWNER_CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` longtext COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localized_description`
--

LOCK TABLES `localized_description` WRITE;
/*!40000 ALTER TABLE `localized_description` DISABLE KEYS */;
INSERT INTO `localized_description` VALUES (183,288,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','Entry point to the mdek application','en,,'),(184,289,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','Catalog administration portlet for the portal admin','en,,'),(185,290,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','SuperAdmin-Login to each Catalog with each User','en,,'),(186,22,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','InGrid-Portal Application',',,'),(301,361,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(302,201,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Info Portlet displays useful information to the user. The Information template and title can be set via preferences.','en,,'),(303,202,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet is called only via javascript','en,,'),(304,362,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(305,203,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays help content.','en,,'),(306,363,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(307,204,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the monitor component of the portlet.','en,,'),(308,364,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(309,205,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the editor for the RSS feeds.','en,,'),(310,365,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(311,206,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the editor for the Partners.','en,,'),(312,366,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(313,207,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the editor for the Providers.','en,,'),(314,367,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(315,368,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This is the template in which you setup an email to be sent after user exists','en,,'),(316,369,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the roles a new user will be registered with','en,,'),(317,370,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the groups a new user will be registered with','en,,'),(318,371,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the rule names a new user will be registered with','en,,'),(319,372,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the rule values a new user will be registered with','en,,'),(320,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the user administration.','en,,'),(321,373,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(322,209,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the editor for the iPlugs.','en,,'),(323,374,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(324,210,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the editor for the free text content.','en,,'),(325,375,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(326,211,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the wms admin interface links.','en,,'),(327,376,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(328,212,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the links to several statistics.','en,,'),(329,377,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(330,213,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the home page personalization dialog.','en,,'),(331,378,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(332,214,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the portal profile admin interface.','en,,'),(333,379,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(334,215,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Portlet displays the portal user migration interface.','en,,'),(335,380,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(336,216,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a search box for the home AND main search page.','en,,'),(337,381,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(338,217,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a search box for the home AND main search page.','en,,'),(339,382,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(340,218,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a search box for the home AND main search page.','en,,'),(341,383,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(342,219,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the rubrics of the Environment catalogue page on the home page for quick search.','en,,'),(343,384,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(344,220,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the rss news list.','en,,'),(345,385,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(346,221,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the rss news list.','en,,'),(347,386,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(348,222,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays a content entry from the cms, specified by the preference \'cmsKey\'.','en,,'),(349,387,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(350,223,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays a content entry from the cms, specified by the preference \'cmsKey\'.','en,,'),(351,388,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(352,224,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays a content entry from the cms, specified by the preference \'cmsKey\'.','en,,'),(353,389,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(354,225,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays a content entry from the cms, specified by the preference \'cmsKey\'.','en,,'),(355,390,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(356,226,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Info Portlet displays useful information to the user. The Information template and title can be set via preferences.','en,,'),(357,391,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(358,227,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Info Portlet displays useful information to the user. The Information template and title can be set via preferences.','en,,'),(359,392,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(360,228,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The Info Portlet displays useful information to the user. The Information template and title can be set via preferences.','en,,'),(361,393,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(362,229,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes an environment search box.','en,,'),(363,394,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(364,230,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes the login dialog.','en,,'),(365,395,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(366,231,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the myportal overview.','en,,'),(367,396,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(368,397,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the url to which folks will return after they receive an email','en,,'),(369,398,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This is the template in which you setup an email to be sent after user exists','en,,'),(370,399,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the rule names a new user will be registered with','en,,'),(371,400,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This option defines the rule values a new user will be registered with','en,,'),(372,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the myportal create account dialog.','en,,'),(373,401,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(374,233,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the myportal edit account dialog.','en,,'),(375,402,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(376,403,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This is the template in which you setup an email to be sent after user exists','en,,'),(377,234,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the myportal password forgotten dialog.','en,,'),(378,404,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(379,235,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','TODO: describe the portlet','en,,'),(380,405,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(381,236,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','TODO: describe the portlet','en,,'),(382,406,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(383,237,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a service search box.','en,,'),(384,407,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(385,238,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the search results.','en,,'),(386,408,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(387,239,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a environment search box.','en,,'),(388,409,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(389,240,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the search results of the environment chronicle search.','en,,'),(390,410,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(391,241,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet handles the \"Similar Terms\" fragment of the search result page.','en,,'),(392,411,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(393,242,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the search results.','en,,'),(394,412,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(395,243,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displays the search detail for dsc results.','en,,'),(396,413,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(397,244,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet handles the browsing of the UDK in the catalog search.','en,,'),(398,414,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(399,245,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a combo box containing different languages.','en,,'),(400,415,'org.apache.jetspeed.om.portlet.impl.InitParamImpl','This parameter sets the template used in view mode.','en,,'),(401,246,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','This portlet displayes a combo box containing different languages.','en,,'),(402,41,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','InGrid-Portal Application',',,'),(421,264,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','The SimpleLayoutPortlet requires a ViewPage layout template set through the portlet preferences which provides its own layout algorithm','en,,'),(422,61,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','Jetspeed 2 Layout Portlets Applications',',,');
/*!40000 ALTER TABLE `localized_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localized_display_name`
--

DROP TABLE IF EXISTS `localized_display_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localized_display_name` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `OWNER_CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISPLAY_NAME` longtext COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localized_display_name`
--

LOCK TABLES `localized_display_name` WRITE;
/*!40000 ALTER TABLE `localized_display_name` DISABLE KEYS */;
INSERT INTO `localized_display_name` VALUES (221,139,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Entry to Mdek App','en,,'),(222,140,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Kataloge administrieren','en,,'),(223,141,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','SuperAdmin-Login','en,,'),(224,22,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','InGrid-Portal Application',',,'),(281,201,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Generisches Informationsportlet','en,,'),(282,202,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','javascript detection portlet','en,,'),(283,203,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Help Portlet','en,,'),(284,204,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminComponentMonitorPortlet','en,,'),(285,205,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Content RSS Portlet','en,,'),(286,206,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Content Partner Portlet','en,,'),(287,207,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Content Provider Portlet','en,,'),(288,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminUserPortlet','en,,'),(289,209,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminIPlugPortlet','en,,'),(290,210,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminCMSPortlet','en,,'),(291,211,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminWMSPortlet','en,,'),(292,212,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminStatisticsPortlet','en,,'),(293,213,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminHomepagePortlet','en,,'),(294,214,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminPortalProfilePortlet','en,,'),(295,215,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','AdminUserMigrationPortlet','en,,'),(296,216,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Einfache Suche','en,,'),(297,217,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Einfache Suche Result','en,,'),(298,218,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Einfache Suche Ergebnisliste','en,,'),(299,219,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Environment Teaser','en,,'),(300,220,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Aktuelles','en,,'),(301,221,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Weitere Meldungen','en,,'),(302,222,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','CMS portlet','en,,'),(303,223,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','CMS portlet','en,,'),(304,224,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','CMS portlet','en,,'),(305,225,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','CMS portlet','en,,'),(306,226,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Generisches Informationsportlet','en,,'),(307,227,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Generisches Informationsportlet','en,,'),(308,228,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Generisches Willkommens-Portlet','en,,'),(309,229,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Contact','en,,'),(310,230,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MyPortalLoginPortlet','en,,'),(311,231,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MyPortalOverviewPortlet','en,,'),(312,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MyPortalCreateAccountPortlet','en,,'),(313,233,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MyPortalEditAccountPortlet','en,,'),(314,234,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MyPortalPasswordForgottenPortlet','en,,'),(315,235,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ShowPartnerPortlet','en,,'),(316,236,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ShowDataSourcePortlet','en,,'),(317,237,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Messwerte','en,,'),(318,238,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Karten','en,,'),(319,239,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Chronik','en,,'),(320,240,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Chronik Suchergebnis','en,,'),(321,241,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Similar Terms','en,,'),(322,242,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Suchergebnis','en,,'),(323,243,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Detailinformation','en,,'),(324,244,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','KatalogSucheHierarchiebaum','en,,'),(325,245,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Sprachauswahl','en,,'),(326,246,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Sprachauswahl','en,,'),(327,41,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','InGrid-Portal Application',',,'),(341,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Layout for Ingrid Portal Using Velocity, no layout decoration','en,,'),(342,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','One Column Layout for Ingrid Portal Using Velocity','en,,'),(343,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns Layout for Ingrid Portal Using Velocity','en,,'),(344,264,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Simple readonly fixed Layout','en,,'),(345,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','One Column','en,,'),(346,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocityを利用した 1 列レイアウト','ja,,'),(347,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity的单列布局','zh,,'),(348,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity的單列佈局','zh,TW,'),(349,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','One Column with Tables','en,,'),(350,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity とテーブルを利用した 1 列レイアウト','ja,,'),(351,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity表格的单列布局','zh,,'),(352,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity表格的單列佈局','zh,TW,'),(353,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns','en,,'),(354,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity を利用した 2 列レイアウト','ja,,'),(355,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity的双列布局','zh,,'),(356,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity的雙列佈局','zh,TW,'),(357,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns (15%/85%)','en,,'),(358,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity を利用した左側にナビゲーションコントロール用の小さな列を持つ 2 列','ja,,'),(359,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity，导航栏较窄的双列布局','zh,,'),(360,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity，導航欄較窄的雙列佈局','zh,TW,'),(361,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Three Columns','en,,'),(362,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity を利用した 3 列レイアウト','ja,,'),(363,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity的3列布局','zh,,'),(364,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity的3列佈局','zh,TW,'),(365,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Three Columns with Tables','en,,'),(366,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity とテーブルを利用した 3 列レイアウト','ja,,'),(367,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity表格的3列布局','zh,,'),(368,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity表格的3列佈局','zh,TW,'),(369,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','One Column - No Actions','en,,'),(370,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ページアクションのない Velocity を利用した 1 列レイアウト','ja,,'),(371,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','没有页面状态、基于Velocity的单列布局','zh,,'),(372,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','沒有頁面狀態、基於Velocity的單列佈局','zh,TW,'),(373,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns Layout - No Actions','en,,'),(374,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ページアクションのない Velocity を利用した 2 列レイアウト','ja,,'),(375,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','没有页面状态、基于Velocity的双列布局','zh,,'),(376,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','沒有頁面狀態、基於Velocity的雙列佈局','zh,TW,'),(377,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Three Columns - No Actions','en,,'),(378,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ページアクションのない Velocity を利用した 3 列レイアウト','ja,,'),(379,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','没有页面状态、基于Velocity的3列布局','zh,,'),(380,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','沒有頁面狀態、基於Velocity的3列佈局','zh,TW,'),(381,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns (25%/75%) No Actions','en,,'),(382,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ページアクションのない Velocity を利用した 2 列レイアウト','ja,,'),(383,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','没有页面状态、基于Velocity的双列布局','zh,,'),(384,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','沒有頁面狀態、基於Velocity的雙列佈局','zh,TW,'),(385,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns (25%/75%)','en,,'),(386,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity を利用した 25/75 の 2 列レイアウト','ja,,'),(387,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity的双列布局','zh,,'),(388,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity的雙列佈局','zh,TW,'),(389,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns (15%,85%) No Actions','en,,'),(390,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','アクションのない Velocity を利用した左側にナビゲーションコントロール用の小さな列を持つ 2 列','ja,,'),(391,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','没有页面状态、基于Velocity，导航栏较窄的单列布局','zh,,'),(392,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','沒有頁面狀態、基於Velocity，導航欄較窄的雙列佈局','zh,TW,'),(393,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Two Columns with Tables','en,,'),(394,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Velocity とテーブルを利用した 2 列レイアウト','ja,,'),(395,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity表格的双列布局','zh,,'),(396,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity表格的雙列佈局','zh,TW,'),(397,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','Four Columns','en,,'),(398,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基于Velocity表格的4列布局','zh,,'),(399,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','基於Velocity表格的4列佈局','zh,TW,'),(400,61,'org.apache.jetspeed.om.portlet.impl.PortletApplicationDefinitionImpl','Jetspeed 2 Layout Portlets Application',',,');
/*!40000 ALTER TABLE `localized_display_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_type`
--

DROP TABLE IF EXISTS `media_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_type` (
  `MEDIATYPE_ID` int(11) NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CHARACTER_SET` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`MEDIATYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type`
--

LOCK TABLES `media_type` WRITE;
/*!40000 ALTER TABLE `media_type` DISABLE KEYS */;
INSERT INTO `media_type` VALUES (1,'html','UTF-8','HTML','Rich HTML for HTML 4.0 compliants browsers'),(2,'vxml','UTF-8','VoiceXML','Format suitable for use with an audio VoiceXML server'),(3,'wml','UTF-8','WML','Format for mobile phones and PDAs compatible with WML 1.1'),(4,'xhtml-basic','UTF-8','XHTML','XHTML Basic'),(5,'xml','','XML','XML 1.0');
/*!40000 ALTER TABLE `media_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mediatype_to_capability`
--

DROP TABLE IF EXISTS `mediatype_to_capability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mediatype_to_capability` (
  `MEDIATYPE_ID` int(11) NOT NULL,
  `CAPABILITY_ID` int(11) NOT NULL,
  PRIMARY KEY (`MEDIATYPE_ID`,`CAPABILITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mediatype_to_capability`
--

LOCK TABLES `mediatype_to_capability` WRITE;
/*!40000 ALTER TABLE `mediatype_to_capability` DISABLE KEYS */;
/*!40000 ALTER TABLE `mediatype_to_capability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mediatype_to_mimetype`
--

DROP TABLE IF EXISTS `mediatype_to_mimetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mediatype_to_mimetype` (
  `MEDIATYPE_ID` int(11) NOT NULL,
  `MIMETYPE_ID` int(11) NOT NULL,
  PRIMARY KEY (`MEDIATYPE_ID`,`MIMETYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mediatype_to_mimetype`
--

LOCK TABLES `mediatype_to_mimetype` WRITE;
/*!40000 ALTER TABLE `mediatype_to_mimetype` DISABLE KEYS */;
INSERT INTO `mediatype_to_mimetype` VALUES (1,2),(2,4),(3,3),(4,1),(5,6);
/*!40000 ALTER TABLE `mediatype_to_mimetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mimetype`
--

DROP TABLE IF EXISTS `mimetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mimetype` (
  `MIMETYPE_ID` int(11) NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`MIMETYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mimetype`
--

LOCK TABLES `mimetype` WRITE;
/*!40000 ALTER TABLE `mimetype` DISABLE KEYS */;
INSERT INTO `mimetype` VALUES (1,'application/xhtml+xml'),(2,'text/html'),(3,'text/vnd.wap.wml'),(4,'text/vxml'),(5,'text/xhtml'),(6,'text/xml');
/*!40000 ALTER TABLE `mimetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `named_parameter`
--

DROP TABLE IF EXISTS `named_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `named_parameter` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `named_parameter`
--

LOCK TABLES `named_parameter` WRITE;
/*!40000 ALTER TABLE `named_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `named_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_dlist`
--

DROP TABLE IF EXISTS `ojb_dlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_dlist` (
  `ID` int(11) NOT NULL,
  `SIZE_` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_dlist`
--

LOCK TABLES `ojb_dlist` WRITE;
/*!40000 ALTER TABLE `ojb_dlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_dlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_dlist_entries`
--

DROP TABLE IF EXISTS `ojb_dlist_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_dlist_entries` (
  `ID` int(11) NOT NULL,
  `DLIST_ID` int(11) DEFAULT NULL,
  `POSITION_` int(11) DEFAULT NULL,
  `OID_` mediumblob,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_dlist_entries`
--

LOCK TABLES `ojb_dlist_entries` WRITE;
/*!40000 ALTER TABLE `ojb_dlist_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_dlist_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_dmap`
--

DROP TABLE IF EXISTS `ojb_dmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_dmap` (
  `ID` int(11) NOT NULL,
  `SIZE_` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_dmap`
--

LOCK TABLES `ojb_dmap` WRITE;
/*!40000 ALTER TABLE `ojb_dmap` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_dmap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_dset`
--

DROP TABLE IF EXISTS `ojb_dset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_dset` (
  `ID` int(11) NOT NULL,
  `SIZE_` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_dset`
--

LOCK TABLES `ojb_dset` WRITE;
/*!40000 ALTER TABLE `ojb_dset` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_dset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_dset_entries`
--

DROP TABLE IF EXISTS `ojb_dset_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_dset_entries` (
  `ID` int(11) NOT NULL,
  `DLIST_ID` int(11) DEFAULT NULL,
  `POSITION_` int(11) DEFAULT NULL,
  `OID_` mediumblob,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_dset_entries`
--

LOCK TABLES `ojb_dset_entries` WRITE;
/*!40000 ALTER TABLE `ojb_dset_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_dset_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_hl_seq`
--

DROP TABLE IF EXISTS `ojb_hl_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_hl_seq` (
  `TABLENAME` varchar(175) COLLATE utf8_unicode_ci NOT NULL,
  `FIELDNAME` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `MAX_KEY` int(11) DEFAULT NULL,
  `GRAB_SIZE` int(11) DEFAULT NULL,
  `VERSION` int(11) DEFAULT NULL,
  PRIMARY KEY (`TABLENAME`,`FIELDNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_hl_seq`
--

LOCK TABLES `ojb_hl_seq` WRITE;
/*!40000 ALTER TABLE `ojb_hl_seq` DISABLE KEYS */;
INSERT INTO `ojb_hl_seq` VALUES ('SEQ_CAPABILITY','deprecatedColumn',60,20,3),('SEQ_CLIENT','deprecatedColumn',20,20,1),('SEQ_FOLDER','deprecatedColumn',60,20,3),('SEQ_FOLDER_CONSTRAINT','deprecatedColumn',20,20,1),('SEQ_FOLDER_CONSTRAINTS_REF','deprecatedColumn',20,20,1),('SEQ_FOLDER_MENU','deprecatedColumn',140,20,6),('SEQ_FOLDER_METADATA','deprecatedColumn',20,20,1),('SEQ_FRAGMENT','deprecatedColumn',480,20,24),('SEQ_FRAGMENT_CONSTRAINT','deprecatedColumn',20,20,1),('SEQ_FRAGMENT_CONSTRAINTS_REF','deprecatedColumn',20,20,1),('SEQ_FRAGMENT_PREF','deprecatedColumn',220,20,11),('SEQ_FRAGMENT_PREF_VALUE','deprecatedColumn',220,20,11),('SEQ_JETSPEED_SERVICE','deprecatedColumn',120,20,6),('SEQ_LANGUAGE','deprecatedColumn',320,20,16),('SEQ_LINK','deprecatedColumn',60,20,2),('SEQ_LOCALIZED_DESCRIPTION','deprecatedColumn',440,20,22),('SEQ_LOCALIZED_DISPLAY_NAME','deprecatedColumn',400,20,20),('SEQ_MEDIA_TYPE','deprecatedColumn',20,20,1),('SEQ_MIMETYPE','deprecatedColumn',20,20,1),('SEQ_PA_METADATA_FIELDS','deprecatedColumn',80,20,4),('SEQ_PAGE','deprecatedColumn',120,20,6),('SEQ_PAGE_CONSTRAINTS_REF','deprecatedColumn',160,20,8),('SEQ_PAGE_METADATA','deprecatedColumn',180,20,9),('SEQ_PAGE_SEC_CONSTRAINT_DEF','deprecatedColumn',20,20,1),('SEQ_PAGE_SEC_CONSTRAINTS_DEF','deprecatedColumn',20,20,1),('SEQ_PAGE_SEC_CONSTRAINTS_REF','deprecatedColumn',20,20,1),('SEQ_PAGE_SECURITY','deprecatedColumn',20,20,1),('SEQ_PARAMETER','deprecatedColumn',520,20,26),('SEQ_PD_METADATA_FIELDS','deprecatedColumn',60,20,3),('SEQ_PORTLET_APPLICATION','deprecatedColumn',80,20,4),('SEQ_PORTLET_DEFINITION','deprecatedColumn',280,20,14),('SEQ_PORTLET_PREFERENCE','deprecatedColumn',300,20,15),('SEQ_PORTLET_PREFERENCE_VALUE','deprecatedColumn',300,20,15),('SEQ_PORTLET_SUPPORTS','deprecatedColumn',280,20,14),('SEQ_RULE_CRITERION','deprecatedColumn',40,20,2),('SEQ_SECURITY_ATTRIBUTE','deprecatedColumn',220,20,11),('SEQ_SECURITY_CREDENTIAL','deprecatedColumn',40,20,2),('SEQ_SECURITY_DOMAIN','deprecatedColumn',20,20,1),('SEQ_SECURITY_PERMISSION','deprecatedColumn',80,20,4),('SEQ_SECURITY_PRINCIPAL','deprecatedColumn',40,20,2);
/*!40000 ALTER TABLE `ojb_hl_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_lockentry`
--

DROP TABLE IF EXISTS `ojb_lockentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_lockentry` (
  `OID_` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `TX_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_` datetime DEFAULT NULL,
  `ISOLATIONLEVEL` int(11) DEFAULT NULL,
  `LOCKTYPE` int(11) DEFAULT NULL,
  PRIMARY KEY (`OID_`,`TX_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_lockentry`
--

LOCK TABLES `ojb_lockentry` WRITE;
/*!40000 ALTER TABLE `ojb_lockentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_lockentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ojb_nrm`
--

DROP TABLE IF EXISTS `ojb_nrm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ojb_nrm` (
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `OID_` mediumblob,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ojb_nrm`
--

LOCK TABLES `ojb_nrm` WRITE;
/*!40000 ALTER TABLE `ojb_nrm` DISABLE KEYS */;
/*!40000 ALTER TABLE `ojb_nrm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pa_metadata_fields`
--

DROP TABLE IF EXISTS `pa_metadata_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pa_metadata_fields` (
  `ID` int(11) NOT NULL,
  `OBJECT_ID` int(11) NOT NULL,
  `COLUMN_VALUE` longtext COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pa_metadata_fields`
--

LOCK TABLES `pa_metadata_fields` WRITE;
/*!40000 ALTER TABLE `pa_metadata_fields` DISABLE KEYS */;
INSERT INTO `pa_metadata_fields` VALUES (26,22,'ingrid portal mdek','title','en,,'),(27,22,'ingrid portal mdek','title','en,,'),(41,41,'ingrid portal applications','title','en,,'),(42,41,'ingrid portal applications','title','en,,'),(61,61,'Jetspeed Layout Portlets','title','en,,'),(62,61,'Layout Portlets','title','en,,'),(63,61,'J2 Team','creator','en,,'),(64,61,'true','layout-app','en,,'),(65,61,'2.3.1','pa-version','en,,');
/*!40000 ALTER TABLE `pa_metadata_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pa_security_constraint`
--

DROP TABLE IF EXISTS `pa_security_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pa_security_constraint` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `TRANSPORT` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pa_security_constraint`
--

LOCK TABLES `pa_security_constraint` WRITE;
/*!40000 ALTER TABLE `pa_security_constraint` DISABLE KEYS */;
/*!40000 ALTER TABLE `pa_security_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `PAGE_ID` int(11) NOT NULL,
  `CLASS_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARENT_ID` int(11) NOT NULL,
  `PATH` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `CONTENT_TYPE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_INHERITABLE` smallint(6) DEFAULT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `VERSION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_HIDDEN` smallint(6) DEFAULT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_LAYOUT_DECORATOR` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_PORTLET_DECORATOR` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSITE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MEDIATYPE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_NAME` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_VALUE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OWNER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`PAGE_ID`),
  UNIQUE KEY `UN_PAGE_1` (`PATH`),
  KEY `IX_PAGE_1` (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (1,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/default-page.psml',NULL,NULL,'default-page.psml',NULL,'ingrid.page.home.tooltip','ingrid.page.home',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/detect-js.psml',NULL,NULL,'detect-js.psml',NULL,'Detect JavaScript','Detect JavaScript',1,'orange','ingrid-clear','clear',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/disclaimer.psml',NULL,NULL,'disclaimer.psml',NULL,'ingrid.page.disclaimer.tooltip','ingrid.page.disclaimer',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/help.psml',NULL,NULL,'help.psml',NULL,'ingrid.page.help.link.tooltip','ingrid.page.help',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-about-data-source.psml',NULL,NULL,'main-about-data-source.psml',NULL,'ingrid.page.data.source.tooltip','ingrid.page.data.source',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-about-partner.psml',NULL,NULL,'main-about-partner.psml',NULL,'ingrid.page.partner.tooltip','ingrid.page.partner',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-about.psml',NULL,NULL,'main-about.psml',NULL,'ingrid.page.about.tooltip','ingrid.page.about',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-chronicle.psml',NULL,NULL,'main-chronicle.psml',NULL,'ingrid.page.chronicle.tooltip','ingrid.page.chronicle',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-maps.psml',NULL,NULL,'main-maps.psml',NULL,'ingrid.page.maps.tooltip','ingrid.page.maps',0,'orange','ingrid','ingrid-clear',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-measures.psml',NULL,NULL,'main-measures.psml',NULL,'ingrid.page.measures.tooltip','ingrid.page.measures',0,'orange','ingrid','ingrid-clear',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/main-search.psml',NULL,NULL,'main-search.psml',NULL,'ingrid.page.search.tooltip','ingrid.page.search.free',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/myportal-create-account.psml',NULL,NULL,'myportal-create-account.psml',NULL,'Login','Login',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/myportal-password-forgotten.psml',NULL,NULL,'myportal-password-forgotten.psml',NULL,'Login','Login',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/rss-news.psml',NULL,NULL,'rss-news.psml',NULL,'Home','Home',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/search-detail.psml',NULL,NULL,'search-detail.psml',NULL,'ingrid.page.search.detail.tooltip','ingrid.page.search.detail',0,'orange','ingrid-untitled','clear',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/service-contact.psml',NULL,NULL,'service-contact.psml',NULL,'ingrid.page.contact.tooltip','ingrid.page.contact',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/service-myportal.psml',NULL,NULL,'service-myportal.psml',NULL,'ingrid.page.myportal.tooltip','ingrid.page.myportal',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/service-sitemap.psml',NULL,NULL,'service-sitemap.psml',NULL,'ingrid.page.sitemap.tooltip','ingrid.page.sitemap',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'org.apache.jetspeed.om.page.impl.PageImpl',3,'/_role/user/default-page.psml',NULL,NULL,'default-page.psml',NULL,'ingrid.page.home.tooltip','ingrid.page.home',0,'orange','ingrid','ingrid-teaser',NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(29,'org.apache.jetspeed.om.page.impl.PageImpl',3,'/_role/user/myportal-edit-account.psml',NULL,NULL,'myportal-edit-account.psml',NULL,'Login','Login',0,'orange','ingrid','ingrid-teaser',NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(31,'org.apache.jetspeed.om.page.impl.PageImpl',3,'/_role/user/service-myportal.psml',NULL,NULL,'service-myportal.psml',NULL,'ingrid.page.myportal','ingrid.page.myportal',0,'orange','ingrid','ingrid-teaser',NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(35,'org.apache.jetspeed.om.page.impl.PageImpl',8,'/_user/template/default-page.psml',NULL,NULL,'default-page.psml',NULL,'ingrid.page.home.tooltip','ingrid.page.home',0,'orange','ingrid','ingrid-teaser',NULL,'template',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-cms.psml',NULL,NULL,'admin-cms.psml',NULL,'ingrid.page.admin.cms','ingrid.page.admin.cms',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-component-monitor.psml',NULL,NULL,'admin-component-monitor.psml',NULL,'ingrid.page.admin.monitor','ingrid.page.admin.monitor',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-content-partner.psml',NULL,NULL,'admin-content-partner.psml',NULL,'ingrid.page.admin.partner','ingrid.page.admin.partner',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-content-provider.psml',NULL,NULL,'admin-content-provider.psml',NULL,'ingrid.page.admin.provider','ingrid.page.admin.provider',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-content-rss.psml',NULL,NULL,'admin-content-rss.psml',NULL,'ingrid.page.admin.rss','ingrid.page.admin.rss',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-homepage.psml',NULL,NULL,'admin-homepage.psml',NULL,'ingrid.page.admin.homepage','ingrid.page.admin.homepage',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-iplugs.psml',NULL,NULL,'admin-iplugs.psml',NULL,'ingrid.page.admin.iplugs','ingrid.page.admin.iplugs',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-portal-profile.psml',NULL,NULL,'admin-portal-profile.psml',NULL,'ingrid.page.admin.profile','ingrid.page.admin.profile',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-statistics.psml',NULL,NULL,'admin-statistics.psml',NULL,'ingrid.page.admin.statistics','ingrid.page.admin.statistics',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,'org.apache.jetspeed.om.page.impl.PageImpl',11,'/administration/admin-usermanagement.psml',NULL,NULL,'admin-usermanagement.psml',NULL,'ingrid.page.admin.usermanagement','ingrid.page.admin.usermanagement',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,'org.apache.jetspeed.om.page.impl.PageImpl',12,'/application/main-application.psml',NULL,NULL,'main-application.psml',NULL,'ingrid.page.application.tooltip','ingrid.page.application',1,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,'org.apache.jetspeed.om.page.impl.PageImpl',13,'/cms/cms-1.psml',NULL,NULL,'cms-1.psml',NULL,'ingrid.page.cms.1.tooltip','ingrid.page.cms.1',1,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,'org.apache.jetspeed.om.page.impl.PageImpl',13,'/cms/cms-2.psml',NULL,NULL,'cms-2.psml',NULL,'ingrid.page.cms.2.tooltip','ingrid.page.cms.2',1,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,'org.apache.jetspeed.om.page.impl.PageImpl',14,'/mdek/mdek_portal_admin.psml',NULL,NULL,'mdek_portal_admin.psml',NULL,'ingrid.page.mdek.catadmin','ingrid.page.mdek.catadmin',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,'org.apache.jetspeed.om.page.impl.PageImpl',15,'/search-catalog/search-catalog-hierarchy.psml',NULL,NULL,'search-catalog-hierarchy.psml',NULL,'ingrid.page.search.catalog.tooltip','ingrid.page.search.catalog',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(100,'org.apache.jetspeed.om.page.impl.PageImpl',1,'/privacy.psml',NULL,NULL,'privacy.psml',NULL,'ingrid.page.privacy.tooltip','ingrid.page.privacy',0,'orange','ingrid','ingrid-teaser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_constraint`
--

DROP TABLE IF EXISTS `page_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_constraint` (
  `CONSTRAINT_ID` int(11) NOT NULL,
  `PAGE_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `USER_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CONSTRAINT_ID`),
  KEY `IX_PAGE_CONSTRAINT_1` (`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_constraint`
--

LOCK TABLES `page_constraint` WRITE;
/*!40000 ALTER TABLE `page_constraint` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_constraints_ref`
--

DROP TABLE IF EXISTS `page_constraints_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_constraints_ref` (
  `CONSTRAINTS_REF_ID` int(11) NOT NULL,
  `PAGE_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_REF_ID`),
  UNIQUE KEY `UN_PAGE_CONSTRAINTS_REF_1` (`PAGE_ID`,`NAME`),
  KEY `IX_PAGE_CONSTRAINTS_REF_1` (`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_constraints_ref`
--

LOCK TABLES `page_constraints_ref` WRITE;
/*!40000 ALTER TABLE `page_constraints_ref` DISABLE KEYS */;
INSERT INTO `page_constraints_ref` VALUES (1,1,0,'public-view'),(2,1,1,'admin-portal'),(3,2,0,'public-view'),(4,3,0,'public-view'),(5,4,0,'public-view'),(6,5,0,'public-view'),(7,6,0,'public-view'),(8,7,0,'public-view'),(9,8,0,'public-view'),(10,9,0,'public-view'),(11,11,0,'public-view'),(12,12,0,'public-view'),(13,13,0,'public-view'),(14,14,0,'public-view'),(15,15,0,'public-view'),(16,16,0,'public-view'),(17,17,0,'public-view'),(18,18,0,'public-view'),(19,19,0,'public-view'),(20,20,0,'public-view'),(21,21,0,'public-view'),(22,22,0,'public-view'),(23,23,0,'public-view'),(24,24,0,'public-view'),(25,25,0,'public-view'),(26,26,0,'public-view'),(27,27,0,'public-view'),(28,28,0,'public-view'),(29,29,0,'public-view'),(30,30,0,'public-view'),(31,31,0,'public-view'),(32,32,0,'public-edit'),(33,33,0,'public-edit'),(34,34,0,'public-edit'),(35,35,0,'public-edit'),(36,36,0,'public-edit'),(37,37,0,'public-edit'),(38,38,0,'admin'),(39,38,1,'admin-portal'),(40,39,0,'admin'),(41,39,1,'admin-portal'),(42,40,0,'admin'),(43,40,1,'admin-portal'),(44,41,0,'admin'),(45,41,1,'admin-portal'),(46,42,0,'admin'),(47,42,1,'admin-portal'),(48,43,0,'admin'),(49,43,1,'admin-portal'),(50,44,0,'admin'),(51,44,1,'admin-portal'),(52,44,2,'admin-partner'),(53,44,3,'admin-provider'),(54,45,0,'admin'),(55,46,0,'admin'),(56,46,1,'admin-portal'),(57,46,2,'admin-partner'),(58,46,3,'admin-provider'),(59,47,0,'admin'),(60,47,1,'admin-partner'),(61,47,2,'admin-portal'),(62,48,0,'admin'),(63,48,1,'admin-portal'),(64,49,0,'public-view'),(65,49,1,'admin'),(66,50,0,'public-view'),(67,50,1,'admin'),(68,51,0,'public-view'),(69,51,1,'admin'),(70,52,0,'public-view'),(71,53,0,'public-view'),(72,54,0,'public-view'),(73,55,0,'public-view'),(74,57,0,'public-view'),(75,58,0,'public-view'),(76,59,0,'public-view'),(77,60,0,'public-view'),(78,61,0,'public-view'),(79,62,0,'public-view'),(80,63,0,'public-view'),(81,64,0,'public-view'),(82,65,0,'public-view'),(83,66,0,'public-view'),(84,67,0,'public-view'),(85,68,0,'public-view'),(86,69,0,'public-view'),(87,70,0,'public-view'),(88,71,0,'public-view'),(89,72,0,'public-view'),(90,73,0,'public-view'),(91,74,0,'public-view'),(92,75,0,'public-view'),(100,52,2,'admin-portal'),(101,49,2,'admin-portal'),(102,50,2,'admin-portal'),(103,51,2,'admin-portal'),(140,100,0,'public-view');
/*!40000 ALTER TABLE `page_constraints_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_menu`
--

DROP TABLE IF EXISTS `page_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_menu` (
  `MENU_ID` int(11) NOT NULL,
  `CLASS_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `PAGE_ID` int(11) DEFAULT NULL,
  `ELEMENT_ORDER` int(11) DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHORT_TITLE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEXT` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OPTIONS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEPTH` int(11) DEFAULT NULL,
  `IS_PATHS` smallint(6) DEFAULT NULL,
  `IS_REGEXP` smallint(6) DEFAULT NULL,
  `PROFILE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OPTIONS_ORDER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SKIN` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_NEST` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`),
  KEY `IX_PAGE_MENU_1` (`PARENT_ID`),
  KEY `IX_PAGE_MENU_2` (`PAGE_ID`),
  KEY `UN_PAGE_MENU_1` (`PAGE_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_menu`
--

LOCK TABLES `page_menu` WRITE;
/*!40000 ALTER TABLE `page_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_menu_metadata`
--

DROP TABLE IF EXISTS `page_menu_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_menu_metadata` (
  `METADATA_ID` int(11) NOT NULL,
  `MENU_ID` int(11) NOT NULL,
  `NAME` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`METADATA_ID`),
  UNIQUE KEY `UN_PAGE_MENU_METADATA_1` (`MENU_ID`,`NAME`,`LOCALE`,`VALUE`),
  KEY `IX_PAGE_MENU_METADATA_1` (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_menu_metadata`
--

LOCK TABLES `page_menu_metadata` WRITE;
/*!40000 ALTER TABLE `page_menu_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_menu_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_metadata`
--

DROP TABLE IF EXISTS `page_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_metadata` (
  `METADATA_ID` int(11) NOT NULL,
  `PAGE_ID` int(11) NOT NULL,
  `NAME` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`METADATA_ID`),
  UNIQUE KEY `UN_PAGE_METADATA_1` (`PAGE_ID`,`NAME`,`LOCALE`,`VALUE`),
  KEY `IX_PAGE_METADATA_1` (`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_metadata`
--

LOCK TABLES `page_metadata` WRITE;
/*!40000 ALTER TABLE `page_metadata` DISABLE KEYS */;
INSERT INTO `page_metadata` VALUES (2,1,'meta_descr','de,,','ingrid.page.home.meta.description'),(3,1,'meta_keywords','de,,','ingrid.page.home.meta.keywords'),(1,1,'meta_title','de,,','ingrid.page.home.meta.title'),(5,3,'meta_descr','de,,','ingrid.page.disclaimer.meta.description'),(6,3,'meta_keywords','de,,','ingrid.page.disclaimer.meta.keywords'),(4,3,'meta_title','de,,','ingrid.page.disclaimer.meta.title'),(8,4,'meta_descr','de,,','ingrid.page.help.meta.description'),(9,4,'meta_keywords','de,,','ingrid.page.help.meta.keywords'),(7,4,'meta_title','de,,','ingrid.page.help.meta.title'),(11,5,'meta_descr','de,,','ingrid.page.data.source.meta.description'),(12,5,'meta_keywords','de,,','ingrid.page.data.source.meta.keywords'),(10,5,'meta_title','de,,','ingrid.page.data.source.meta.title'),(14,6,'meta_descr','de,,','ingrid.page.about.partner.meta.description'),(15,6,'meta_keywords','de,,','ingrid.page.about.partner.meta.keywords'),(13,6,'meta_title','de,,','ingrid.page.about.partner.meta.title'),(17,7,'meta_descr','de,,','ingrid.page.about.meta.description'),(18,7,'meta_keywords','de,,','ingrid.page.about.meta.keywords'),(16,7,'meta_title','de,,','ingrid.page.about.meta.title'),(20,8,'meta_descr','de,,','ingrid.page.chronicle.meta.description'),(21,8,'meta_keywords','de,,','ingrid.page.chronicle.meta.keywords'),(19,8,'meta_title','de,,','ingrid.page.chronicle.meta.title'),(23,9,'meta_descr','de,,','ingrid.page.environment.meta.description'),(24,9,'meta_keywords','de,,','ingrid.page.environment.meta.keywords'),(22,9,'meta_title','de,,','ingrid.page.environment.meta.title'),(26,10,'meta_descr','de,,','ingrid.page.features.meta.description'),(27,10,'meta_keywords','de,,','ingrid.page.features.meta.keywords'),(25,10,'meta_title','de,,','ingrid.page.features.meta.title'),(29,11,'meta_descr','de,,','ingrid.page.maps.meta.description'),(30,11,'meta_keywords','de,,','ingrid.page.maps.meta.keywords'),(28,11,'meta_title','de,,','ingrid.page.maps.meta.title'),(32,12,'meta_descr','de,,','ingrid.page.measures.meta.description'),(33,12,'meta_keywords','de,,','ingrid.page.measures.meta.keywords'),(31,12,'meta_title','de,,','ingrid.page.measures.meta.title'),(35,13,'meta_descr','de,,','ingrid.page.search.meta.description'),(36,13,'meta_keywords','de,,','ingrid.page.search.meta.keywords'),(34,13,'meta_title','de,,','ingrid.page.search.meta.title'),(38,14,'meta_descr','de,,','ingrid.page.service.meta.description'),(39,14,'meta_keywords','de,,','ingrid.page.service.meta.keywords'),(37,14,'meta_title','de,,','ingrid.page.service.meta.title'),(41,17,'meta_descr','de,,','ingrid.page.privacy.meta.description'),(42,17,'meta_keywords','de,,','ingrid.page.privacy.meta.keywords'),(40,17,'meta_title','de,,','ingrid.page.privacy.meta.title'),(44,18,'meta_descr','de,,','ingrid.page.rss.meta.description'),(45,18,'meta_keywords','de,,','ingrid.page.rss.meta.keywords'),(43,18,'meta_title','de,,','ingrid.page.rss.meta.title'),(47,19,'meta_descr','de,,','ingrid.page.detail.meta.description'),(48,19,'meta_keywords','de,,','ingrid.page.detail.meta.keywords'),(46,19,'meta_title','de,,','ingrid.page.detail.meta.title'),(50,20,'meta_descr','de,,','ingrid.page.search.history.meta.description'),(51,20,'meta_keywords','de,,','ingrid.page.search.history.meta.keywords'),(49,20,'meta_title','de,,','ingrid.page.search.history.meta.title'),(53,23,'meta_descr','de,,','ingrid.page.search.settings.meta.description'),(54,23,'meta_keywords','de,,','ingrid.page.search.settings.meta.keywords'),(52,23,'meta_title','de,,','ingrid.page.search.settings.meta.title'),(56,24,'meta_descr','de,,','ingrid.page.newsletter.meta.description'),(57,24,'meta_keywords','de,,','ingrid.page.newsletter.meta.keywords'),(55,24,'meta_title','de,,','ingrid.page.newsletter.meta.title'),(59,25,'meta_descr','de,,','ingrid.page.contact.meta.description'),(60,25,'meta_keywords','de,,','ingrid.page.contact.meta.keywords'),(58,25,'meta_title','de,,','ingrid.page.contact.meta.title'),(62,26,'meta_descr','de,,','ingrid.page.myportal.meta.description'),(63,26,'meta_keywords','de,,','ingrid.page.myportal.meta.keywords'),(61,26,'meta_title','de,,','ingrid.page.myportal.meta.title'),(65,27,'meta_descr','de,,','ingrid.page.sitemap.meta.description'),(66,27,'meta_keywords','de,,','ingrid.page.sitemap.meta.keywords'),(64,27,'meta_title','de,,','ingrid.page.sitemap.meta.title'),(67,28,'meta_descr','de,,','ingrid.page.home.meta.description'),(68,28,'meta_keywords','de,,','ingrid.page.home.meta.keywords'),(69,28,'meta_title','de,,','ingrid.page.home.meta.title'),(70,33,'meta_descr','de,,','ingrid.page.home.meta.description'),(71,33,'meta_keywords','de,,','ingrid.page.home.meta.keywords'),(72,33,'meta_title','de,,','ingrid.page.home.meta.title'),(73,34,'meta_descr','de,,','ingrid.page.home.meta.description'),(74,34,'meta_keywords','de,,','ingrid.page.home.meta.keywords'),(75,34,'meta_title','de,,','ingrid.page.home.meta.title'),(76,35,'meta_descr','de,,','ingrid.page.home.meta.description'),(77,35,'meta_keywords','de,,','ingrid.page.home.meta.keywords'),(78,35,'meta_title','de,,','ingrid.page.home.meta.title'),(79,49,'meta_descr','de,,','ingrid.page.application.0.meta.description'),(80,49,'meta_keywords','de,,','ingrid.page.application.0.meta.keywords'),(81,49,'meta_title','de,,','ingrid.page.application.0.meta.title'),(82,50,'meta_keywords','de,,','ingrid.page.application.1.meta.keywords'),(83,50,'meta_title','de,,','ingrid.page.application.1.meta.title'),(84,51,'meta_descr','de,,','ingrid.page.application.2.meta.description'),(85,51,'meta_keywords','de,,','ingrid.page.application.2.meta.keywords'),(86,51,'meta_title','de,,','ingrid.page.application.2.meta.title'),(87,52,'meta_descr','de,,','ingrid.page.application.meta.description'),(88,52,'meta_keywords','de,,','ingrid.page.application.meta.keywords'),(89,52,'meta_title','de,,','ingrid.page.application.meta.title'),(91,53,'meta_descr','de,,','ingrid.page.cms.0.meta.description'),(92,53,'meta_keywords','de,,','ingrid.page.cms.0.meta.keywords'),(90,53,'meta_title','de,,','ingrid.page.cms.0.meta.title'),(94,54,'meta_descr','de,,','ingrid.page.cms.1.meta.description'),(95,54,'meta_keywords','de,,','ingrid.page.cms.1.meta.keywords'),(93,54,'meta_title','de,,','ingrid.page.cms.1.meta.title'),(97,55,'meta_descr','de,,','ingrid.page.cms.2.meta.description'),(98,55,'meta_keywords','de,,','ingrid.page.cms.2.meta.keywords'),(96,55,'meta_title','de,,','ingrid.page.cms.2.meta.title'),(99,57,'meta_descr','de,,','ingrid.page.hierarchy.meta.description'),(100,57,'meta_keywords','de,,','ingrid.page.hierarchy.meta.keywords'),(101,57,'meta_title','de,,','ingrid.page.hierarchy.meta.title'),(102,58,'meta_descr','de,,','ingrid.page.thesaurus.meta.description'),(103,58,'meta_keywords','de,,','ingrid.page.thesaurus.meta.keywords'),(104,58,'meta_title','de,,','ingrid.page.thesaurus.meta.title'),(106,69,'meta_descr','de,,','ingrid.page.ext.search.meta.description'),(107,69,'meta_keywords','de,,','ingrid.page.ext.search.meta.keywords'),(105,69,'meta_title','de,,','ingrid.page.ext.search.meta.title'),(161,100,'meta_descr','de','ingrid.page.privacy.meta.description'),(162,100,'meta_keywords','de','ingrid.page.privacy.meta.keywords'),(160,100,'meta_title','de','ingrid.page.privacy.meta.title');
/*!40000 ALTER TABLE `page_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_sec_constraint_def`
--

DROP TABLE IF EXISTS `page_sec_constraint_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_sec_constraint_def` (
  `CONSTRAINT_DEF_ID` int(11) NOT NULL,
  `CONSTRAINTS_DEF_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `USER_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPALS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS_ACL` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CONSTRAINT_DEF_ID`),
  KEY `IX_PAGE_SEC_CONSTRAINT_DEF_1` (`CONSTRAINTS_DEF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_sec_constraint_def`
--

LOCK TABLES `page_sec_constraint_def` WRITE;
/*!40000 ALTER TABLE `page_sec_constraint_def` DISABLE KEYS */;
INSERT INTO `page_sec_constraint_def` VALUES (1,1,0,NULL,'admin',NULL,'view,edit'),(2,2,0,NULL,'admin-partner',NULL,'view,edit'),(3,3,0,NULL,'admin-portal',NULL,'view,edit'),(4,4,0,NULL,'admin-provider',NULL,'view,edit'),(5,5,0,NULL,'manager',NULL,'view'),(6,6,0,'*',NULL,NULL,'view,edit'),(7,7,0,'*',NULL,NULL,'view'),(8,8,0,NULL,'user,manager',NULL,'view');
/*!40000 ALTER TABLE `page_sec_constraint_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_sec_constraints_def`
--

DROP TABLE IF EXISTS `page_sec_constraints_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_sec_constraints_def` (
  `CONSTRAINTS_DEF_ID` int(11) NOT NULL,
  `PAGE_SECURITY_ID` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_DEF_ID`),
  UNIQUE KEY `UN_PAGE_SEC_CONSTRAINTS_DEF_1` (`PAGE_SECURITY_ID`,`NAME`),
  KEY `IX_PAGE_SEC_CONSTRAINTS_DEF_1` (`PAGE_SECURITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_sec_constraints_def`
--

LOCK TABLES `page_sec_constraints_def` WRITE;
/*!40000 ALTER TABLE `page_sec_constraints_def` DISABLE KEYS */;
INSERT INTO `page_sec_constraints_def` VALUES (1,1,'admin'),(2,1,'admin-partner'),(3,1,'admin-portal'),(4,1,'admin-provider'),(5,1,'manager'),(6,1,'public-edit'),(7,1,'public-view'),(8,1,'users');
/*!40000 ALTER TABLE `page_sec_constraints_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_sec_constraints_ref`
--

DROP TABLE IF EXISTS `page_sec_constraints_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_sec_constraints_ref` (
  `CONSTRAINTS_REF_ID` int(11) NOT NULL,
  `PAGE_SECURITY_ID` int(11) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONSTRAINTS_REF_ID`),
  UNIQUE KEY `UN_PAGE_SEC_CONSTRAINTS_REF_1` (`PAGE_SECURITY_ID`,`NAME`),
  KEY `IX_PAGE_SEC_CONSTRAINTS_REF_1` (`PAGE_SECURITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_sec_constraints_ref`
--

LOCK TABLES `page_sec_constraints_ref` WRITE;
/*!40000 ALTER TABLE `page_sec_constraints_ref` DISABLE KEYS */;
INSERT INTO `page_sec_constraints_ref` VALUES (1,1,0,'admin');
/*!40000 ALTER TABLE `page_sec_constraints_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_security`
--

DROP TABLE IF EXISTS `page_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_security` (
  `PAGE_SECURITY_ID` int(11) NOT NULL,
  `PARENT_ID` int(11) NOT NULL,
  `PATH` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `VERSION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSITE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROLE_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_PRINCIPAL` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MEDIATYPE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCALE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_NAME` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXT_ATTR_VALUE` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`PAGE_SECURITY_ID`),
  UNIQUE KEY `UN_PAGE_SECURITY_1` (`PARENT_ID`),
  UNIQUE KEY `UN_PAGE_SECURITY_2` (`PATH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_security`
--

LOCK TABLES `page_security` WRITE;
/*!40000 ALTER TABLE `page_security` DISABLE KEYS */;
INSERT INTO `page_security` VALUES (1,1,'/page.security','page.security',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `page_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_statistics`
--

DROP TABLE IF EXISTS `page_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_statistics` (
  `IPADDRESS` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_STAMP` datetime DEFAULT NULL,
  `PAGE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `ELAPSED_TIME` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_statistics`
--

LOCK TABLES `page_statistics` WRITE;
/*!40000 ALTER TABLE `page_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parameter`
--

DROP TABLE IF EXISTS `parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parameter` (
  `PARAMETER_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `OWNER_CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMETER_VALUE` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`PARAMETER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameter`
--

LOCK TABLES `parameter` WRITE;
/*!40000 ALTER TABLE `parameter` DISABLE KEYS */;
INSERT INTO `parameter` VALUES (288,139,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/mdek/mdek_entry.vm'),(289,140,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/mdek/mdek_portal_admin.vm'),(290,141,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/mdek/mdek_admin_login.vm'),(361,201,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_info.vm'),(362,203,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/help.vm'),(363,204,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/component_monitor.vm'),(364,205,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/content_rss.vm'),(365,206,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/content_partner.vm'),(366,207,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/content_provider.vm'),(367,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_user_browser.vm'),(368,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','emailTemplate','/WEB-INF/templates/administration/userCreatedConfirmationEmail.vm'),(369,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','roles','user'),(370,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','groups',''),(371,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','rulesNames','user-role-fallback'),(372,208,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','rulesValues','page'),(373,209,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_iplug.vm'),(374,210,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_cms_browser.vm'),(375,211,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_wms.vm'),(376,212,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_statistics.vm'),(377,213,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_homepage.vm'),(378,214,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_portal_profile.vm'),(379,215,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/administration/admin_user_migration.vm'),(380,216,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/search_simple.vm'),(381,217,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/search_simple_result.vm'),(382,218,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/category_teaser.vm'),(383,219,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/environment_teaser.vm'),(384,220,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/rss_news_teaser.vm'),(385,221,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/rss_news.vm'),(386,222,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(387,223,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(388,224,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(389,225,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(390,226,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(391,227,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_info.vm'),(392,228,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/default_cms.vm'),(393,229,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/contact.vm'),(394,230,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/myportal/login.vm'),(395,231,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/myportal/myportal_overview.vm'),(396,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/myportal/myportal_create_account.vm'),(397,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','returnURL','/myportal-create-account.psml'),(398,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','emailTemplate','/WEB-INF/templates/myportal/userRegistrationEmail.vm'),(399,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','rulesNames','user-role-fallback'),(400,232,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','rulesValues','page'),(401,233,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/myportal/myportal_edit_account.vm'),(402,234,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/myportal/myportal_password_forgotten.vm'),(403,234,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','emailTemplate','/WEB-INF/templates/myportal/forgottenPasswdEmail.vm'),(404,235,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/show_partner.vm'),(405,236,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/show_data_source.vm'),(406,237,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/measures_search.vm'),(407,238,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/show_maps.vm'),(408,239,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/chronicle_search.vm'),(409,240,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/empty.vm'),(410,241,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/search_similar.vm'),(411,242,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/search_result.vm'),(412,243,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/detail/search_detail_idf_2_0.vm'),(413,244,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/search_catalog/search_cat_hierarchy.vm'),(414,245,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/language.vm'),(415,246,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','/WEB-INF/templates/language_mobile.vm'),(421,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','ingrid-clear-layout'),(422,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(423,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','1'),(424,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','100%'),(425,261,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','OneColumn'),(426,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','ingrid-one-column'),(427,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(428,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','1'),(429,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','100%'),(430,262,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','OneColumn'),(431,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','ingrid-two-columns'),(432,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(433,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(434,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','50%,50%'),(435,263,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(436,264,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(437,264,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(438,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(439,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(440,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','1'),(441,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','100%'),(442,265,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','OneColumn'),(443,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','tcolumns'),(444,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(445,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','1'),(446,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','100%'),(447,266,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','OneColumn'),(448,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(449,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(450,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(451,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','50%,50%'),(452,267,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(453,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(454,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(455,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(456,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','15%,85%'),(457,268,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(458,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(459,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(460,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','3'),(461,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','33%,33%,33%'),(462,269,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','ThreeColumns'),(463,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','tcolumns'),(464,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(465,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','3'),(466,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','33%,33%,33%'),(467,270,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','ThreeColumns'),(468,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(469,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(470,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','1'),(471,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','100%'),(472,271,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','OneColumn'),(473,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(474,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(475,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(476,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','50%,50%'),(477,272,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(478,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(479,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(480,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','3'),(481,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','33%,33%,33%'),(482,273,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','ThreeColumns'),(483,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(484,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(485,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(486,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','25%,75%'),(487,274,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(488,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(489,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(490,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(491,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','25%,75%'),(492,275,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(493,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(494,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(495,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(496,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','15%,85%'),(497,276,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(498,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','tcolumns'),(499,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(500,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','2'),(501,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','50%,50%'),(502,277,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','TwoColumns'),(503,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','ViewPage','columns'),(504,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','MaxPage','maximized'),(505,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','columns','4'),(506,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','sizes','20%,30%,30%,20%'),(507,278,'org.apache.jetspeed.om.portlet.impl.PortletDefinitionImpl','layoutType','FourColumns');
/*!40000 ALTER TABLE `parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parameter_alias`
--

DROP TABLE IF EXISTS `parameter_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parameter_alias` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameter_alias`
--

LOCK TABLES `parameter_alias` WRITE;
/*!40000 ALTER TABLE `parameter_alias` DISABLE KEYS */;
/*!40000 ALTER TABLE `parameter_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pd_metadata_fields`
--

DROP TABLE IF EXISTS `pd_metadata_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pd_metadata_fields` (
  `ID` int(11) NOT NULL,
  `OBJECT_ID` int(11) NOT NULL,
  `COLUMN_VALUE` longtext COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LOCALE_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pd_metadata_fields`
--

LOCK TABLES `pd_metadata_fields` WRITE;
/*!40000 ALTER TABLE `pd_metadata_fields` DISABLE KEYS */;
INSERT INTO `pd_metadata_fields` VALUES (41,264,'*','selector.conditional.role','en,,'),(42,265,'*','selector.conditional.role','en,,'),(43,266,'*','selector.conditional.role','en,,'),(44,267,'*','selector.conditional.role','en,,'),(45,268,'*','selector.conditional.role','en,,'),(46,269,'*','selector.conditional.role','en,,'),(47,270,'*','selector.conditional.role','en,,'),(48,271,'*','selector.conditional.role','en,,'),(49,272,'*','selector.conditional.role','en,,'),(50,273,'*','selector.conditional.role','en,,'),(51,274,'*','selector.conditional.role','en,,'),(52,275,'*','selector.conditional.role','en,,'),(53,276,'*','selector.conditional.role','en,,'),(54,277,'*','selector.conditional.role','en,,'),(55,278,'*','selector.conditional.role','en,,');
/*!40000 ALTER TABLE `pd_metadata_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_application`
--

DROP TABLE IF EXISTS `portlet_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_application` (
  `APPLICATION_ID` int(11) NOT NULL,
  `APP_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CONTEXT_PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REVISION` int(11) NOT NULL,
  `VERSION` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APP_TYPE` int(11) DEFAULT NULL,
  `CHECKSUM` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_REF` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_NAMESPACE` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESOURCE_BUNDLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`APPLICATION_ID`),
  UNIQUE KEY `UK_APPLICATION` (`APP_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_application`
--

LOCK TABLES `portlet_application` WRITE;
/*!40000 ALTER TABLE `portlet_application` DISABLE KEYS */;
INSERT INTO `portlet_application` VALUES (22,'ingrid-portal-mdek','/ingrid-portal-mdek',2,'1.0',0,'1906125074',NULL,'',NULL),(41,'ingrid-portal-apps','/ingrid-portal-apps',3,'2.0',0,'2482709288',NULL,'',NULL),(61,'jetspeed-layouts','<portal>',3,'1.0',1,'2696274916',NULL,'',NULL);
/*!40000 ALTER TABLE `portlet_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_content_type`
--

DROP TABLE IF EXISTS `portlet_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_content_type` (
  `CONTENT_TYPE_ID` mediumint(9) NOT NULL,
  `PORTLET_ID` mediumint(9) NOT NULL,
  `CONTENT_TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `MODES` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`CONTENT_TYPE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_content_type`
--

LOCK TABLES `portlet_content_type` WRITE;
/*!40000 ALTER TABLE `portlet_content_type` DISABLE KEYS */;
INSERT INTO `portlet_content_type` VALUES (1435,1435,'text/html','\"view\"'),(1432,1432,'text/html','\"view\"'),(1433,1433,'text/html','\"view\"'),(1434,1434,'text/html','\"help\",\"edit\",\"view\"'),(1497,1497,'text/html','\"view\"'),(1482,1482,'text/html','\"view\"'),(1483,1483,'text/html','\"view\"'),(1484,1484,'text/html','\"view\"'),(1485,1485,'text/html','\"view\"'),(1486,1486,'text/html','\"view\"'),(1487,1487,'text/html','\"view\"'),(1488,1488,'text/html','\"view\"'),(1489,1489,'text/html','\"view\"'),(1490,1490,'text/html','\"view\"'),(1491,1491,'text/html','\"view\"'),(1492,1492,'text/html','\"view\"'),(1493,1493,'text/html','\"view\"'),(1494,1494,'text/html','\"view\"'),(1495,1495,'text/html','\"view\"'),(1496,1496,'text/html','\"view\"'),(1421,1421,'text/html','\"view\"'),(1422,1422,'text/html','\"view\"'),(1423,1423,'text/html','\"view\"'),(1424,1424,'text/html','\"help\",\"edit\",\"view\"'),(1425,1425,'text/html','\"help\",\"edit\",\"view\"'),(1426,1426,'text/html','\"help\",\"edit\",\"view\"'),(1427,1427,'text/html','\"help\",\"edit\",\"view\"'),(1428,1428,'text/html','\"help\",\"edit\",\"view\"'),(1429,1429,'text/html','\"help\",\"edit\",\"view\"'),(1430,1430,'text/html','\"view\"'),(1431,1431,'text/html','\"view\"'),(1479,1479,'text/html','\"view\"'),(1478,1478,'text/html','\"view\"'),(1477,1477,'text/html','\"view\"'),(1481,1481,'text/html','\"view\"'),(1480,1480,'text/html','\"view\"'),(1469,1469,'text/html','\"view\"'),(1470,1470,'text/html','\"view\"'),(1471,1471,'text/html','\"view\"'),(1472,1472,'text/html','\"view\"'),(1473,1473,'text/html','\"view\"'),(1474,1474,'text/html','\"view\"'),(1475,1475,'text/html','\"view\"'),(1476,1476,'text/html','\"view\"'),(1468,1468,'text/html','\"view\"'),(1467,1467,'text/html','\"view\"'),(1466,1466,'text/html','\"view\"'),(1465,1465,'text/html','\"view\"'),(1463,1463,'text/html','\"view\"'),(1459,1459,'text/html','\"view\"'),(1460,1460,'text/html','\"view\"'),(1461,1461,'text/html','\"view\"'),(1462,1462,'text/html','\"view\"'),(1458,1458,'text/html','\"view\"'),(1464,1464,'text/html','\"view\"'),(1457,1457,'text/html','\"view\"'),(1453,1453,'text/html','\"view\"'),(1455,1455,'text/html','\"view\"'),(1456,1456,'text/html','\"view\"'),(1454,1454,'text/html','\"view\"'),(1452,1452,'text/html','\"view\"'),(1451,1451,'text/html','\"view\"'),(1450,1450,'text/html','\"view\"'),(1443,1443,'text/html','\"view\"'),(1442,1442,'text/html','\"view\"'),(1441,1441,'text/html','\"view\"'),(1444,1444,'text/html','\"view\"'),(1445,1445,'text/html','\"view\"'),(1446,1446,'text/html','\"view\"'),(1447,1447,'text/html','\"view\"'),(1448,1448,'text/html','\"view\"'),(1449,1449,'text/html','\"view\"'),(1318,1318,'text/html','\"view\"'),(1319,1319,'text/html','\"view\"'),(1320,1320,'text/html','\"view\"'),(1437,1437,'text/html','\"help\",\"edit\",\"view\"'),(1436,1436,'text/html','\"view\"'),(1500,1500,'text/html','\"view\"'),(1498,1498,'text/html','\"view\"'),(1499,1499,'text/html','\"view\"'),(1501,1501,'text/html','\"view\"'),(1502,1502,'text/html','\"view\"'),(1503,1503,'text/html','\"view\"'),(1504,1504,'text/html','\"view\"'),(1505,1505,'text/html','\"view\"'),(1506,1506,'text/html','\"view\"'),(1507,1507,'text/html','\"view\"'),(1508,1508,'text/html','\"view\"'),(1509,1509,'text/html','\"view\"'),(1510,1510,'text/html','\"view\"'),(1511,1511,'text/html','\"view\"'),(1512,1512,'text/html','\"view\"'),(1513,1513,'text/html','\"view\"'),(1514,1514,'text/html','\"view\"'),(1515,1515,'text/html','\"view\"'),(1516,1516,'text/html','\"view\"'),(1517,1517,'text/html','\"view\"'),(1518,1518,'text/html','\"view\"'),(1519,1519,'text/html','\"view\"'),(1520,1520,'text/html','\"view\"'),(1521,1521,'text/html','\"view\"'),(1522,1522,'text/html','\"view\"');
/*!40000 ALTER TABLE `portlet_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_definition`
--

DROP TABLE IF EXISTS `portlet_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_definition` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `EXPIRATION_CACHE` int(11) DEFAULT NULL,
  `RESOURCE_BUNDLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFERENCE_VALIDATOR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_REF` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SCOPE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLONE_PARENT` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_definition`
--

LOCK TABLES `portlet_definition` WRITE;
/*!40000 ALTER TABLE `portlet_definition` DISABLE KEYS */;
INSERT INTO `portlet_definition` VALUES (139,'MdekEntryPortlet','de.ingrid.portal.portlets.mdek.MdekEntryPortlet',22,0,'de.ingrid.portal.resources.MdekResources',NULL,NULL,'private',NULL),(140,'MdekPortalAdminPortlet','de.ingrid.portal.portlets.mdek.MdekPortalAdminPortlet',22,0,'de.ingrid.portal.resources.MdekResources',NULL,NULL,'private',NULL),(141,'MdekAdminLoginPortlet','de.ingrid.portal.portlets.mdek.MdekAdminLoginPortlet',22,0,'de.ingrid.portal.resources.MdekResources',NULL,NULL,'private',NULL),(201,'InfoPortlet','de.ingrid.portal.portlets.InfoPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(202,'DetectJavaScriptPortlet','de.ingrid.portal.portlets.DetectJavaScriptPortlet',41,0,NULL,NULL,NULL,'private',NULL),(203,'HelpPortlet','de.ingrid.portal.portlets.HelpPortlet',41,0,'de.ingrid.portal.resources.HelpPortletResources',NULL,NULL,'private',NULL),(204,'AdminComponentMonitorPortlet','de.ingrid.portal.portlets.admin.AdminComponentMonitorPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(205,'ContentRSSPortlet','de.ingrid.portal.portlets.admin.ContentRSSPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(206,'ContentPartnerPortlet','de.ingrid.portal.portlets.admin.ContentPartnerPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(207,'ContentProviderPortlet','de.ingrid.portal.portlets.admin.ContentProviderPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(208,'AdminUserPortlet','de.ingrid.portal.portlets.admin.AdminUserPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(209,'AdminIPlugPortlet','de.ingrid.portal.portlets.admin.AdminIPlugPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(210,'AdminCMSPortlet','de.ingrid.portal.portlets.admin.AdminCMSPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(211,'AdminWMSPortlet','de.ingrid.portal.portlets.admin.AdminWMSPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(212,'AdminStatisticsPortlet','de.ingrid.portal.portlets.admin.AdminStatisticsPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(213,'AdminHomepagePortlet','de.ingrid.portal.portlets.admin.AdminHomepagePortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(214,'AdminPortalProfilePortlet','de.ingrid.portal.portlets.admin.AdminPortalProfilePortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(215,'AdminUserMigrationPortlet','de.ingrid.portal.portlets.admin.AdminUserMigrationPortlet',41,0,'de.ingrid.portal.resources.AdminPortalResources',NULL,NULL,'private',NULL),(216,'SearchSimple','de.ingrid.portal.portlets.SearchSimplePortlet',41,0,'de.ingrid.portal.resources.SearchSimpleResources',NULL,NULL,'private',NULL),(217,'SearchSimpleResult','de.ingrid.portal.portlets.SearchSimplePortlet',41,0,'de.ingrid.portal.resources.SearchSimpleResources',NULL,NULL,'private',NULL),(218,'CategoryTeaser','de.ingrid.portal.portlets.CategoryTeaserPortlet',41,0,'de.ingrid.portal.resources.SearchResultResources',NULL,NULL,'private',NULL),(219,'EnvironmentTeaser','de.ingrid.portal.portlets.EnvironmentTeaserPortlet',41,0,'de.ingrid.portal.resources.EnvironmentSearchResources',NULL,NULL,'private',NULL),(220,'RssNewsTeaser','de.ingrid.portal.portlets.RssNewsTeaserPortlet',41,0,'de.ingrid.portal.resources.RssNewsResources',NULL,NULL,'private',NULL),(221,'RssNews','de.ingrid.portal.portlets.RssNewsPortlet',41,0,'de.ingrid.portal.resources.RssNewsResources',NULL,NULL,'private',NULL),(222,'CMSPortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(223,'AboutPortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(224,'DisclaimerPortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(225,'PrivacyPortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(226,'IngridInformPortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(227,'InfoDefaultPageTeaser','de.ingrid.portal.portlets.InfoPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(228,'IngridWelcomePortlet','de.ingrid.portal.portlets.CMSPortlet',41,0,'de.ingrid.portal.resources.InfoPortletResources',NULL,NULL,'private',NULL),(229,'Contact','de.ingrid.portal.portlets.ContactPortlet',41,0,'de.ingrid.portal.resources.ContactResources',NULL,NULL,'private',NULL),(230,'MyPortalLoginPortlet','de.ingrid.portal.portlets.myportal.MyPortalLoginPortlet',41,0,'de.ingrid.portal.resources.MyPortalResources',NULL,NULL,'private',NULL),(231,'MyPortalOverviewPortlet','de.ingrid.portal.portlets.myportal.MyPortalOverviewPortlet',41,0,'de.ingrid.portal.resources.MyPortalResources',NULL,NULL,'private',NULL),(232,'MyPortalCreateAccountPortlet','de.ingrid.portal.portlets.myportal.MyPortalCreateAccountPortlet',41,0,'de.ingrid.portal.resources.MyPortalResources',NULL,NULL,'private',NULL),(233,'MyPortalEditAccountPortlet','de.ingrid.portal.portlets.myportal.MyPortalEditAccountPortlet',41,0,'de.ingrid.portal.resources.MyPortalResources',NULL,NULL,'private',NULL),(234,'MyPortalPasswordForgottenPortlet','de.ingrid.portal.portlets.myportal.MyPortalPasswordForgottenPortlet',41,0,'de.ingrid.portal.resources.MyPortalResources',NULL,NULL,'private',NULL),(235,'ShowPartnerPortlet','de.ingrid.portal.portlets.ShowPartnerPortlet',41,0,'de.ingrid.portal.resources.ShowPartnerPortletResources',NULL,NULL,'private',NULL),(236,'ShowDataSourcePortlet','de.ingrid.portal.portlets.ShowDataSourcePortlet',41,0,'de.ingrid.portal.resources.ShowDataSourcePortletResources',NULL,NULL,'private',NULL),(237,'MeasuresSearch','de.ingrid.portal.portlets.MeasuresSearchPortlet',41,0,'de.ingrid.portal.resources.MeasuresSearchResources',NULL,NULL,'private',NULL),(238,'ShowMapsPortlet','de.ingrid.portal.portlets.ShowMapsPortlet',41,0,'de.ingrid.portal.resources.CommonResources',NULL,NULL,'private',NULL),(239,'ChronicleSearch','de.ingrid.portal.portlets.ChronicleSearchPortlet',41,0,'de.ingrid.portal.resources.ChronicleSearchResources',NULL,NULL,'private',NULL),(240,'ChronicleResult','de.ingrid.portal.portlets.ChronicleResultPortlet',41,0,'de.ingrid.portal.resources.ChronicleSearchResources',NULL,NULL,'private',NULL),(241,'SearchSimilar','de.ingrid.portal.portlets.SearchSimilarPortlet',41,0,'de.ingrid.portal.resources.SearchResultResources',NULL,NULL,'private',NULL),(242,'SearchResult','de.ingrid.portal.portlets.SearchResultPortlet',41,0,'de.ingrid.portal.resources.SearchResultResources',NULL,NULL,'private',NULL),(243,'SearchDetail','de.ingrid.portal.portlets.SearchDetailPortlet',41,0,'de.ingrid.portal.resources.SearchDetailResources',NULL,NULL,'private',NULL),(244,'SearchCatalogHierarchy','de.ingrid.portal.portlets.searchcatalog.SearchCatalogHierarchyPortlet',41,0,'de.ingrid.portal.resources.SearchCatalogResources',NULL,NULL,'private',NULL),(245,'LanguageSwitch','de.ingrid.portal.portlets.LanguageSwitchPortlet',41,0,'de.ingrid.portal.resources.CommonResources',NULL,NULL,'private',NULL),(246,'LanguageSwitchMobile','de.ingrid.portal.portlets.LanguageSwitchPortlet',41,0,'de.ingrid.portal.resources.CommonResources',NULL,NULL,'private',NULL),(261,'IngridClearLayout','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'de.ingrid.portal.resources.PortalLayoutResources',NULL,NULL,'private',NULL),(262,'IngridOneColumn','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'de.ingrid.portal.resources.PortalLayoutResources',NULL,NULL,'private',NULL),(263,'IngridTwoColumns','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'de.ingrid.portal.resources.PortalLayoutResources',NULL,NULL,'private',NULL),(264,'SimpleLayout','org.apache.jetspeed.portlets.layout.LayoutPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(265,'VelocityOneColumn','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(266,'VelocityOneColumnTable','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(267,'VelocityTwoColumns','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(268,'VelocityTwoColumnsSmallLeft','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(269,'VelocityThreeColumns','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(270,'VelocityThreeColumnsTable','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(271,'VelocityOneColumnNoActions','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(272,'VelocityTwoColumnsNoActions','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(273,'VelocityThreeColumnsNoActions','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(274,'VelocityTwoColumns2575NoActions','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(275,'VelocityTwoColumns2575','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(276,'VelocityTwoColumnsSmallLeftNoActions','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(277,'VelocityTwoColumnsTable','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL),(278,'VelocityFourColumns','org.apache.jetspeed.portlets.layout.MultiColumnPortlet',61,0,'org.apache.jetspeed.portlets.layout.resources.LayoutResource',NULL,NULL,'private',NULL);
/*!40000 ALTER TABLE `portlet_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_entity`
--

DROP TABLE IF EXISTS `portlet_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_entity` (
  `PEID` mediumint(9) NOT NULL,
  `ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `APP_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PORTLET_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PEID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_entity`
--

LOCK TABLES `portlet_entity` WRITE;
/*!40000 ALTER TABLE `portlet_entity` DISABLE KEYS */;
INSERT INTO `portlet_entity` VALUES (1,'2','ingrid-portal-apps','SearchSimple'),(2,'3','ingrid-portal-apps','EnvironmentTeaser'),(3,'4','ingrid-portal-apps','RssNewsTeaser'),(4,'5','ingrid-portal-apps','IngridInformPortlet'),(5,'6','ingrid-portal-apps','ServiceTeaser'),(6,'7','ingrid-portal-apps','MeasuresTeaser'),(7,'8','ingrid-portal-apps','ChronicleTeaser'),(8,'1','jetspeed-layouts','IngridTwoColumns'),(9,'LanguageSwitch','ingrid-portal-apps','LanguageSwitch'),(21,'10','ingrid-portal-apps','DetectJavaScriptPortlet'),(22,'9','jetspeed-layouts','IngridClearLayout'),(23,'80','ingrid-portal-apps','MyPortalLoginPortlet'),(24,'81','ingrid-portal-apps','InfoPortlet'),(25,'79','jetspeed-layouts','IngridTwoColumns'),(26,'106','ingrid-portal-apps','MyPortalOverviewPortlet'),(27,'107','ingrid-portal-apps','InfoPortlet'),(28,'105','jetspeed-layouts','IngridTwoColumns'),(29,'281','ingrid-portal-mdek','MdekPortalAdminPortlet'),(30,'300','ingrid-portal-mdek','MdekAdminLoginPortlet'),(31,'280','jetspeed-layouts','IngridOneColumn'),(32,'117','ingrid-portal-apps','AdminCMSPortlet'),(33,'116','jetspeed-layouts','IngridOneColumn'),(34,'135','ingrid-portal-apps','AdminUserPortlet'),(35,'136','ingrid-portal-apps','AdminUserMigrationPortlet'),(36,'134','jetspeed-layouts','IngridOneColumn'),(41,'283','ingrid-portal-mdek','MdekEntryPortlet'),(221,'203','ingrid-portal-apps','SearchCatalogThesaurus'),(61,'31','ingrid-portal-apps','ShowMapsPortlet'),(62,'30','jetspeed-layouts','IngridClearLayout'),(63,'38','ingrid-portal-apps','SearchSimple'),(64,'39','ingrid-portal-apps','InfoPortlet'),(65,'40','ingrid-portal-apps','SearchSimilar'),(66,'37','jetspeed-layouts','IngridTwoColumns'),(67,'42','ingrid-portal-apps','SearchResult'),(68,'41','jetspeed-layouts','IngridOneColumn'),(69,'36','jetspeed-layouts','IngridOneColumn'),(70,'44','ingrid-portal-apps','ServiceSearch'),(71,'45','ingrid-portal-apps','ServiceResult'),(72,'46','ingrid-portal-apps','InfoPortlet'),(73,'43','jetspeed-layouts','IngridTwoColumns'),(74,'33','ingrid-portal-apps','MeasuresSearch'),(75,'34','ingrid-portal-apps','MeasuresResult'),(76,'35','ingrid-portal-apps','InfoPortlet'),(77,'32','jetspeed-layouts','IngridTwoColumns'),(78,'23','ingrid-portal-apps','ChronicleSearch'),(79,'24','ingrid-portal-apps','ChronicleResult'),(80,'25','ingrid-portal-apps','InfoPortlet'),(81,'22','jetspeed-layouts','IngridTwoColumns'),(82,'64','ingrid-portal-apps','SearchResult'),(83,'63','jetspeed-layouts','IngridClearLayout'),(101,'27','ingrid-portal-apps','EnvironmentSearch'),(102,'28','ingrid-portal-apps','EnvironmentResult'),(103,'29','ingrid-portal-apps','InfoPortlet'),(104,'26','jetspeed-layouts','IngridTwoColumns'),(105,'85','ingrid-portal-apps','SearchSimple'),(106,'86','ingrid-portal-apps','EnvironmentTeaser'),(107,'87','ingrid-portal-apps','RssNewsTeaser'),(108,'88','ingrid-portal-apps','IngridInformPortlet'),(109,'89','ingrid-portal-apps','ServiceTeaser'),(110,'90','ingrid-portal-apps','MeasuresTeaser'),(111,'91','ingrid-portal-apps','ChronicleTeaser'),(112,'84','jetspeed-layouts','IngridTwoColumns'),(113,'19','ingrid-portal-apps','CMSPortlet'),(114,'20','ingrid-portal-apps','InfoPortlet'),(115,'21','ingrid-portal-apps','InfoPortlet'),(116,'18','jetspeed-layouts','IngridTwoColumns'),(121,'342','ingrid-portal-apps','SearchSimple'),(122,'343','ingrid-portal-apps','EnvironmentTeaser'),(123,'344','ingrid-portal-apps','RssNewsTeaser'),(124,'345','ingrid-portal-apps','IngridInformPortlet'),(125,'346','ingrid-portal-apps','ServiceTeaser'),(126,'347','ingrid-portal-apps','MeasuresTeaser'),(127,'348','ingrid-portal-apps','ChronicleTeaser'),(128,'341','jetspeed-layouts','IngridTwoColumns'),(129,'129','ingrid-portal-apps','AdminIPlugPortlet'),(130,'128','jetspeed-layouts','IngridOneColumn'),(141,'320','ingrid-portal-apps','SaveMapsPortlet'),(142,'58','ingrid-portal-apps','SearchDetail'),(143,'57','jetspeed-layouts','IngridClearLayout'),(161,'201','ingrid-portal-apps','SearchCatalogHierarchy'),(162,'200','jetspeed-layouts','IngridOneColumn'),(181,'402','ingrid-portal-apps','SearchSimple'),(182,'403','ingrid-portal-apps','EnvironmentTeaser'),(183,'404','ingrid-portal-apps','RssNewsTeaser'),(184,'405','ingrid-portal-apps','IngridInformPortlet'),(185,'406','ingrid-portal-apps','ServiceTeaser'),(186,'407','ingrid-portal-apps','MeasuresTeaser'),(187,'408','ingrid-portal-apps','ChronicleTeaser'),(188,'401','jetspeed-layouts','IngridTwoColumns'),(201,'15','ingrid-portal-apps','HelpPortlet'),(202,'14','jetspeed-layouts','IngridClearLayout'),(203,'93','ingrid-portal-apps','MyPortalEditAccountPortlet'),(204,'94','ingrid-portal-apps','InfoPortlet'),(205,'95','ingrid-portal-apps','InfoPortlet'),(206,'96','ingrid-portal-apps','InfoPortlet'),(207,'92','jetspeed-layouts','IngridTwoColumns'),(222,'220','ingrid-portal-apps','SearchCatalogThesaurusResult'),(223,'240','ingrid-portal-apps','InfoPortlet'),(224,'202','jetspeed-layouts','IngridTwoColumns'),(241,'home','jetspeed-layouts','IngridTwoColumns'),(242,'detect-js','jetspeed-layouts','IngridClearLayout'),(261,'search-simple-portlet','ingrid-portal-apps','SearchSimple'),(262,'home-2','ingrid-portal-apps','EnvironmentTeaser'),(263,'home-3','ingrid-portal-apps','RssNewsTeaser'),(264,'home-4','ingrid-portal-apps','IngridInformPortlet'),(265,'home-5','ingrid-portal-apps','ServiceTeaser'),(266,'home-6','ingrid-portal-apps','MeasuresTeaser'),(267,'home-7','ingrid-portal-apps','ChronicleTeaser'),(268,'detect-js-1','ingrid-portal-apps','DetectJavaScriptPortlet'),(269,'service-myportal-1','ingrid-portal-apps','MyPortalLoginPortlet'),(270,'service-myportal-2','ingrid-portal-apps','InfoPortlet'),(271,'service-myportal','jetspeed-layouts','IngridTwoColumns'),(272,'myportal-overview','ingrid-portal-apps','MyPortalOverviewPortlet'),(273,'myportal-navigation','ingrid-portal-apps','InfoPortlet'),(274,'mdek-entry-0','ingrid-portal-mdek','MdekEntryPortlet'),(275,'mdek-portal','jetspeed-layouts','IngridOneColumn'),(276,'main-search-info','ingrid-portal-apps','InfoPortlet'),(277,'main-search-similar','ingrid-portal-apps','SearchSimilar'),(278,'main-search-two-columns','jetspeed-layouts','IngridTwoColumns'),(279,'main-search-results','ingrid-portal-apps','SearchResult'),(280,'main-search-one-column','jetspeed-layouts','IngridOneColumn'),(281,'main-search','jetspeed-layouts','IngridOneColumn'),(282,'search-result-js-1','ingrid-portal-apps','SearchResult'),(283,'search-result-js','jetspeed-layouts','IngridClearLayout'),(285,'search-detail-1','ingrid-portal-apps','SearchDetail'),(286,'search-detail','jetspeed-layouts','IngridClearLayout'),(301,'183','ingrid-portal-apps','SearchSimple'),(302,'184','ingrid-portal-apps','SearchExtEnvTopicTerms'),(303,'185','ingrid-portal-apps','InfoPortlet'),(304,'182','jetspeed-layouts','IngridTwoColumns'),(305,'158','ingrid-portal-apps','SearchSimple'),(306,'159','ingrid-portal-apps','SearchExtEnvAreaContents'),(307,'160','ingrid-portal-apps','InfoPortlet'),(308,'157','jetspeed-layouts','IngridTwoColumns'),(309,'166','ingrid-portal-apps','SearchSimple'),(310,'167','ingrid-portal-apps','SearchExtEnvAreaSources'),(311,'168','ingrid-portal-apps','InfoPortlet'),(312,'165','jetspeed-layouts','IngridTwoColumns'),(321,'170','ingrid-portal-apps','SearchSimple'),(322,'171','ingrid-portal-apps','SearchExtEnvPlaceGeothesaurus'),(323,'172','ingrid-portal-apps','InfoPortlet'),(324,'169','jetspeed-layouts','IngridTwoColumns'),(325,'175','ingrid-portal-apps','SearchSimple'),(326,'174','jetspeed-layouts','IngridTwoColumns'),(327,'176','ingrid-portal-apps','SearchExtEnvPlaceMap'),(328,'173','jetspeed-layouts','IngridOneColumn'),(341,'119','ingrid-portal-apps','AdminComponentMonitorPortlet'),(342,'118','jetspeed-layouts','IngridOneColumn'),(361,'83','ingrid-portal-apps','InfoPortlet'),(362,'82','jetspeed-layouts','IngridOneColumn'),(381,'187','ingrid-portal-apps','SearchSimple'),(382,'188','ingrid-portal-apps','SearchExtEnvTopicThesaurus'),(383,'189','ingrid-portal-apps','InfoPortlet'),(384,'186','jetspeed-layouts','IngridTwoColumns'),(385,'77','ingrid-portal-apps','Contact'),(386,'78','ingrid-portal-apps','InfoPortlet'),(387,'76','jetspeed-layouts','IngridTwoColumns'),(401,'12','ingrid-portal-apps','CMSPortlet'),(402,'13','ingrid-portal-apps','InfoPortlet'),(403,'11','jetspeed-layouts','IngridTwoColumns'),(404,'131','ingrid-portal-apps','AdminPortalProfilePortlet'),(405,'130','jetspeed-layouts','IngridOneColumn'),(421,'461','ingrid-portal-apps','SearchSimple'),(422,'462','ingrid-portal-apps','EnvironmentTeaser'),(423,'463','ingrid-portal-apps','RssNewsTeaser'),(424,'464','ingrid-portal-apps','IngridInformPortlet'),(425,'465','ingrid-portal-apps','ServiceTeaser'),(426,'466','ingrid-portal-apps','MeasuresTeaser'),(427,'467','ingrid-portal-apps','ChronicleTeaser'),(428,'482','ingrid-portal-apps','Contact'),(429,'483','ingrid-portal-apps','InfoPortlet'),(441,'501','ingrid-portal-apps','SearchSimple'),(442,'502','ingrid-portal-apps','EnvironmentTeaser'),(443,'503','ingrid-portal-apps','RssNewsTeaser'),(444,'504','ingrid-portal-apps','IngridInformPortlet'),(445,'505','ingrid-portal-apps','ServiceTeaser'),(446,'506','ingrid-portal-apps','MeasuresTeaser'),(447,'507','ingrid-portal-apps','ChronicleTeaser'),(448,'522','ingrid-portal-apps','Contact'),(449,'523','ingrid-portal-apps','InfoPortlet'),(461,'541','ingrid-portal-apps','SearchSimple'),(462,'542','ingrid-portal-apps','EnvironmentTeaser'),(463,'543','ingrid-portal-apps','RssNewsTeaser'),(464,'544','ingrid-portal-apps','IngridInformPortlet'),(465,'545','ingrid-portal-apps','ServiceTeaser'),(466,'546','ingrid-portal-apps','MeasuresTeaser'),(467,'547','ingrid-portal-apps','ChronicleTeaser'),(481,'162','ingrid-portal-apps','SearchSimple'),(482,'163','ingrid-portal-apps','SearchExtEnvAreaPartner'),(483,'164','ingrid-portal-apps','InfoPortlet'),(484,'161','jetspeed-layouts','IngridTwoColumns'),(485,'191','ingrid-portal-apps','SearchSimple'),(486,'192','ingrid-portal-apps','SearchExtResTopicAttributes'),(487,'193','ingrid-portal-apps','InfoPortlet'),(488,'190','jetspeed-layouts','IngridTwoColumns'),(501,'562','ingrid-portal-apps','Contact'),(502,'563','ingrid-portal-apps','InfoPortlet'),(521,'581','ingrid-portal-apps','SearchSimple'),(522,'582','ingrid-portal-apps','EnvironmentTeaser'),(523,'583','ingrid-portal-apps','RssNewsTeaser'),(524,'584','ingrid-portal-apps','IngridInformPortlet'),(525,'585','ingrid-portal-apps','ServiceTeaser'),(526,'586','ingrid-portal-apps','MeasuresTeaser'),(527,'587','ingrid-portal-apps','ChronicleTeaser'),(528,'588','ingrid-portal-apps','WeatherTeaser'),(541,'621','ingrid-portal-apps','SearchSimple'),(542,'622','ingrid-portal-apps','EnvironmentTeaser'),(543,'623','ingrid-portal-apps','RssNewsTeaser'),(544,'624','ingrid-portal-apps','IngridInformPortlet'),(545,'625','ingrid-portal-apps','ServiceTeaser'),(546,'626','ingrid-portal-apps','MeasuresTeaser'),(547,'627','ingrid-portal-apps','ChronicleTeaser'),(548,'628','ingrid-portal-apps','WeatherTeaser'),(561,'661','ingrid-portal-apps','SearchSimple'),(562,'662','ingrid-portal-apps','EnvironmentTeaser'),(563,'663','ingrid-portal-apps','RssNewsTeaser'),(564,'664','ingrid-portal-apps','IngridInformPortlet'),(565,'665','ingrid-portal-apps','ServiceTeaser'),(566,'666','ingrid-portal-apps','MeasuresTeaser'),(567,'667','ingrid-portal-apps','ChronicleTeaser'),(568,'668','ingrid-portal-apps','WeatherTeaser'),(581,'701','ingrid-portal-apps','SearchSimple'),(582,'702','ingrid-portal-apps','EnvironmentTeaser'),(583,'703','ingrid-portal-apps','RssNewsTeaser'),(584,'704','ingrid-portal-apps','IngridInformPortlet'),(585,'705','ingrid-portal-apps','ServiceTeaser'),(586,'706','ingrid-portal-apps','MeasuresTeaser'),(587,'707','ingrid-portal-apps','ChronicleTeaser'),(588,'708','ingrid-portal-apps','WeatherTeaser'),(601,'741','ingrid-portal-apps','SearchSimple'),(602,'742','ingrid-portal-apps','EnvironmentTeaser'),(603,'743','ingrid-portal-apps','RssNewsTeaser'),(604,'744','ingrid-portal-apps','IngridInformPortlet'),(605,'745','ingrid-portal-apps','ServiceTeaser'),(606,'746','ingrid-portal-apps','MeasuresTeaser'),(607,'747','ingrid-portal-apps','ChronicleTeaser'),(608,'748','ingrid-portal-apps','WeatherTeaser'),(621,'54','ingrid-portal-apps','CMSPortlet'),(622,'53','jetspeed-layouts','IngridTwoColumns'),(641,'123','ingrid-portal-apps','ContentProviderPortlet'),(642,'122','jetspeed-layouts','IngridOneColumn'),(661,'801','ingrid-portal-apps','ShowFeaturesPortlet'),(662,'800','jetspeed-layouts','IngridOneColumn'),(663,'73','ingrid-portal-apps','ContactNewsletterPortlet'),(664,'74','ingrid-portal-apps','InfoPortlet'),(665,'75','ingrid-portal-apps','InfoPortlet'),(666,'72','jetspeed-layouts','IngridTwoColumns'),(667,'763','ingrid-portal-apps','Contact'),(668,'764','ingrid-portal-apps','InfoPortlet'),(669,'195','ingrid-portal-apps','SearchSimple'),(670,'196','ingrid-portal-apps','SearchExtResTopicTerms'),(671,'197','ingrid-portal-apps','InfoPortlet'),(672,'194','jetspeed-layouts','IngridTwoColumns'),(673,'178','ingrid-portal-apps','SearchSimple'),(674,'179','ingrid-portal-apps','SearchExtEnvTimeConstraint'),(675,'180','ingrid-portal-apps','SearchExtEnvTimeChronicle'),(676,'181','ingrid-portal-apps','InfoPortlet'),(677,'177','jetspeed-layouts','IngridTwoColumns'),(678,'261','ingrid-portal-apps','SearchSimple'),(679,'262','ingrid-portal-apps','SearchExtLawTopicTerms'),(680,'263','ingrid-portal-apps','InfoPortlet'),(681,'260','jetspeed-layouts','IngridTwoColumns'),(682,'269','ingrid-portal-apps','SearchSimple'),(683,'270','ingrid-portal-apps','SearchExtLawAreaPartner'),(684,'271','ingrid-portal-apps','InfoPortlet'),(685,'268','jetspeed-layouts','IngridTwoColumns'),(686,'154','ingrid-portal-apps','SearchSimple'),(687,'155','ingrid-portal-apps','SearchExtAdrTopicTerms'),(688,'156','ingrid-portal-apps','InfoPortlet'),(689,'153','jetspeed-layouts','IngridTwoColumns'),(690,'146','ingrid-portal-apps','SearchSimple'),(691,'147','ingrid-portal-apps','SearchExtAdrPlaceReference'),(692,'148','ingrid-portal-apps','InfoPortlet'),(693,'145','jetspeed-layouts','IngridTwoColumns'),(694,'142','ingrid-portal-apps','SearchSimple'),(695,'143','ingrid-portal-apps','SearchExtAdrAreaPartner'),(696,'144','ingrid-portal-apps','InfoPortlet'),(697,'141','jetspeed-layouts','IngridTwoColumns'),(698,'60','ingrid-portal-apps','SearchSimple'),(699,'61','ingrid-portal-apps','SearchHistory'),(700,'62','ingrid-portal-apps','InfoPortlet'),(701,'59','jetspeed-layouts','IngridTwoColumns'),(702,'69','ingrid-portal-apps','SearchSimple'),(703,'70','ingrid-portal-apps','SearchSettings'),(704,'71','ingrid-portal-apps','InfoPortlet'),(705,'68','jetspeed-layouts','IngridTwoColumns'),(706,'17','ingrid-portal-apps','ShowPartnerPortlet'),(707,'16','jetspeed-layouts','IngridTwoColumns'),(721,'150','ingrid-portal-apps','SearchSimple'),(722,'151','ingrid-portal-apps','SearchExtAdrTopicMode'),(723,'152','ingrid-portal-apps','InfoPortlet'),(724,'149','jetspeed-layouts','IngridTwoColumns'),(725,'51','ingrid-portal-apps','MyPortalPasswordForgottenPortlet'),(726,'52','ingrid-portal-apps','InfoPortlet'),(727,'50','jetspeed-layouts','IngridTwoColumns'),(741,'56','ingrid-portal-apps','RssNews'),(742,'55','jetspeed-layouts','IngridTwoColumns'),(761,'48','ingrid-portal-apps','MyPortalCreateAccountPortlet'),(762,'49','ingrid-portal-apps','InfoPortlet'),(763,'47','jetspeed-layouts','IngridTwoColumns'),(764,'749','ingrid-portal-apps','SearchSimple'),(765,'750','ingrid-portal-apps','EnvironmentTeaser'),(766,'751','ingrid-portal-apps','RssNewsTeaser'),(767,'752','ingrid-portal-apps','IngridInformPortlet'),(768,'753','ingrid-portal-apps','ServiceTeaser'),(769,'754','ingrid-portal-apps','MeasuresTeaser'),(770,'755','ingrid-portal-apps','ChronicleTeaser'),(771,'765','ingrid-portal-apps','MyPortalEditAccountPortlet'),(772,'766','ingrid-portal-apps','MyPortalEditAboutInfoPortlet'),(773,'767','ingrid-portal-apps','MyPortalEditNewsletterInfoPortlet'),(774,'768','ingrid-portal-apps','MyPortalEditAdvancedInfoPortlet'),(775,'127','ingrid-portal-apps','AdminHomepagePortlet'),(776,'126','jetspeed-layouts','IngridOneColumn'),(777,'125','ingrid-portal-apps','ContentRSSPortlet'),(778,'124','jetspeed-layouts','IngridOneColumn'),(779,'121','ingrid-portal-apps','ContentPartnerPortlet'),(780,'120','jetspeed-layouts','IngridOneColumn'),(781,'138','ingrid-portal-apps','AdminWMSPortlet'),(782,'137','jetspeed-layouts','IngridOneColumn'),(783,'133','ingrid-portal-apps','AdminStatisticsPortlet'),(784,'132','jetspeed-layouts','IngridOneColumn'),(785,'98','ingrid-portal-apps','MyPortalPersonalizeOverviewPortlet'),(786,'99','ingrid-portal-apps','MyPortalPersonalizeHomePortlet'),(787,'100','ingrid-portal-apps','MyPortalPersonalizePartnerPortlet'),(788,'101','ingrid-portal-apps','MyPortalPersonalizeSourcesPortlet'),(789,'102','ingrid-portal-apps','MyPortalPersonalizeSearchSettingsPortlet'),(790,'103','ingrid-portal-apps','InfoPortlet'),(791,'104','ingrid-portal-apps','InfoPortlet'),(792,'97','jetspeed-layouts','IngridTwoColumns'),(801,'820','ingrid-portal-apps','WeatherTeaser'),(821,'9931','ingrid-portal-apps','ServiceTeaser');
/*!40000 ALTER TABLE `portlet_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_filter`
--

DROP TABLE IF EXISTS `portlet_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_filter` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `FILTER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_CLASS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_filter`
--

LOCK TABLES `portlet_filter` WRITE;
/*!40000 ALTER TABLE `portlet_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `portlet_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_listener`
--

DROP TABLE IF EXISTS `portlet_listener`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_listener` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `LISTENER_CLASS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_listener`
--

LOCK TABLES `portlet_listener` WRITE;
/*!40000 ALTER TABLE `portlet_listener` DISABLE KEYS */;
/*!40000 ALTER TABLE `portlet_listener` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_preference`
--

DROP TABLE IF EXISTS `portlet_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_preference` (
  `ID` int(11) NOT NULL,
  `DTYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `APPLICATION_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `PORTLET_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `READONLY` smallint(6) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UIX_PORTLET_PREFERENCE` (`DTYPE`,`APPLICATION_NAME`,`PORTLET_NAME`,`ENTITY_ID`,`USER_NAME`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_preference`
--

LOCK TABLES `portlet_preference` WRITE;
/*!40000 ALTER TABLE `portlet_preference` DISABLE KEYS */;
INSERT INTO `portlet_preference` VALUES (61,'portlet','ingrid-portal-mdek','MdekEntryPortlet',NULL,NULL,'sectionStyle',0),(62,'portlet','ingrid-portal-mdek','MdekEntryPortlet',NULL,NULL,'titleKey',0),(63,'portlet','ingrid-portal-mdek','MdekPortalAdminPortlet',NULL,NULL,'sectionStyle',0),(64,'portlet','ingrid-portal-mdek','MdekPortalAdminPortlet',NULL,NULL,'titleKey',0),(65,'portlet','ingrid-portal-mdek','MdekAdminLoginPortlet',NULL,NULL,'sectionStyle',0),(66,'portlet','ingrid-portal-mdek','MdekAdminLoginPortlet',NULL,NULL,'titleKey',0),(181,'portlet','ingrid-portal-apps','HelpPortlet',NULL,NULL,'sectionStyle',0),(182,'portlet','ingrid-portal-apps','HelpPortlet',NULL,NULL,'disableTitle',0),(183,'portlet','ingrid-portal-apps','HelpPortlet',NULL,NULL,'articleStyle',0),(184,'portlet','ingrid-portal-apps','AdminComponentMonitorPortlet',NULL,NULL,'sectionStyle',0),(185,'portlet','ingrid-portal-apps','AdminComponentMonitorPortlet',NULL,NULL,'titleTag',0),(186,'portlet','ingrid-portal-apps','ContentRSSPortlet',NULL,NULL,'sectionStyle',0),(187,'portlet','ingrid-portal-apps','ContentRSSPortlet',NULL,NULL,'titleTag',0),(188,'portlet','ingrid-portal-apps','ContentPartnerPortlet',NULL,NULL,'sectionStyle',0),(189,'portlet','ingrid-portal-apps','ContentPartnerPortlet',NULL,NULL,'titleTag',0),(190,'portlet','ingrid-portal-apps','ContentProviderPortlet',NULL,NULL,'sectionStyle',0),(191,'portlet','ingrid-portal-apps','ContentProviderPortlet',NULL,NULL,'titleTag',0),(192,'portlet','ingrid-portal-apps','AdminUserPortlet',NULL,NULL,'sectionStyle',0),(193,'portlet','ingrid-portal-apps','AdminUserPortlet',NULL,NULL,'divStyle',0),(194,'portlet','ingrid-portal-apps','AdminUserPortlet',NULL,NULL,'titleTag',0),(195,'portlet','ingrid-portal-apps','AdminIPlugPortlet',NULL,NULL,'sectionStyle',0),(196,'portlet','ingrid-portal-apps','AdminIPlugPortlet',NULL,NULL,'titleTag',0),(197,'portlet','ingrid-portal-apps','AdminIPlugPortlet',NULL,NULL,'articleStyle',0),(198,'portlet','ingrid-portal-apps','AdminCMSPortlet',NULL,NULL,'sectionStyle',0),(199,'portlet','ingrid-portal-apps','AdminCMSPortlet',NULL,NULL,'titleTag',0),(200,'portlet','ingrid-portal-apps','AdminWMSPortlet',NULL,NULL,'sectionStyle',0),(201,'portlet','ingrid-portal-apps','AdminWMSPortlet',NULL,NULL,'titleTag',0),(202,'portlet','ingrid-portal-apps','AdminWMSPortlet',NULL,NULL,'articleStyle',0),(203,'portlet','ingrid-portal-apps','AdminStatisticsPortlet',NULL,NULL,'sectionStyle',0),(204,'portlet','ingrid-portal-apps','AdminStatisticsPortlet',NULL,NULL,'titleTag',0),(205,'portlet','ingrid-portal-apps','AdminStatisticsPortlet',NULL,NULL,'articleStyle',0),(206,'portlet','ingrid-portal-apps','AdminHomepagePortlet',NULL,NULL,'sectionStyle',0),(207,'portlet','ingrid-portal-apps','AdminHomepagePortlet',NULL,NULL,'titleTag',0),(208,'portlet','ingrid-portal-apps','AdminHomepagePortlet',NULL,NULL,'articleStyle',0),(209,'portlet','ingrid-portal-apps','AdminPortalProfilePortlet',NULL,NULL,'sectionStyle',0),(210,'portlet','ingrid-portal-apps','AdminPortalProfilePortlet',NULL,NULL,'titleTag',0),(211,'portlet','ingrid-portal-apps','AdminPortalProfilePortlet',NULL,NULL,'articleStyle',0),(212,'portlet','ingrid-portal-apps','SearchSimple',NULL,NULL,'portlet-type',0),(213,'portlet','ingrid-portal-apps','SearchSimple',NULL,NULL,'default-vertical-position',0),(214,'portlet','ingrid-portal-apps','SearchSimple',NULL,NULL,'helpKey',0),(215,'portlet','ingrid-portal-apps','SearchSimple',NULL,NULL,'disableTitle',0),(216,'portlet','ingrid-portal-apps','SearchSimple',NULL,NULL,'titleKey',0),(217,'portlet','ingrid-portal-apps','CategoryTeaser',NULL,NULL,'sectionStyle',0),(218,'portlet','ingrid-portal-apps','CategoryTeaser',NULL,NULL,'portlet-type',0),(219,'portlet','ingrid-portal-apps','CategoryTeaser',NULL,NULL,'default-vertical-position',0),(220,'portlet','ingrid-portal-apps','CategoryTeaser',NULL,NULL,'titleKey',0),(221,'portlet','ingrid-portal-apps','EnvironmentTeaser',NULL,NULL,'sectionStyle',0),(222,'portlet','ingrid-portal-apps','EnvironmentTeaser',NULL,NULL,'portlet-type',0),(223,'portlet','ingrid-portal-apps','EnvironmentTeaser',NULL,NULL,'default-vertical-position',0),(224,'portlet','ingrid-portal-apps','EnvironmentTeaser',NULL,NULL,'helpKey',0),(225,'portlet','ingrid-portal-apps','EnvironmentTeaser',NULL,NULL,'titleKey',0),(226,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'sectionStyle',0),(227,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'portlet-type',0),(228,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'default-vertical-position',0),(229,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'helpKey',0),(230,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'titleKey',0),(231,'portlet','ingrid-portal-apps','RssNewsTeaser',NULL,NULL,'noOfEntriesDisplayed',0),(232,'portlet','ingrid-portal-apps','RssNews',NULL,NULL,'sectionStyle',0),(233,'portlet','ingrid-portal-apps','RssNews',NULL,NULL,'startWithEntry',0),(234,'portlet','ingrid-portal-apps','CMSPortlet',NULL,NULL,'cmsKey',0),(235,'portlet','ingrid-portal-apps','AboutPortlet',NULL,NULL,'cmsKey',0),(236,'portlet','ingrid-portal-apps','AboutPortlet',NULL,NULL,'helpKey',0),(237,'portlet','ingrid-portal-apps','DisclaimerPortlet',NULL,NULL,'cmsKey',0),(238,'portlet','ingrid-portal-apps','PrivacyPortlet',NULL,NULL,'sectionStyle',0),(239,'portlet','ingrid-portal-apps','PrivacyPortlet',NULL,NULL,'cmsKey',0),(240,'portlet','ingrid-portal-apps','PrivacyPortlet',NULL,NULL,'titleTag',0),(241,'portlet','ingrid-portal-apps','PrivacyPortlet',NULL,NULL,'articleStyle',0),(242,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'sectionStyle',0),(243,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'portlet-type',0),(244,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'cmsKey',0),(245,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'helpKey',0),(246,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'default-vertical-position',0),(247,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'infoTemplate',0),(248,'portlet','ingrid-portal-apps','IngridInformPortlet',NULL,NULL,'titleKey',0),(249,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'sectionStyle',0),(250,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'portlet-type',0),(251,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'default-vertical-position',0),(252,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'disableTitle',0),(253,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'infoTemplate',0),(254,'portlet','ingrid-portal-apps','InfoDefaultPageTeaser',NULL,NULL,'titleKey',0),(255,'portlet','ingrid-portal-apps','IngridWelcomePortlet',NULL,NULL,'cmsKey',0),(256,'portlet','ingrid-portal-apps','IngridWelcomePortlet',NULL,NULL,'infoTemplate',0),(257,'portlet','ingrid-portal-apps','IngridWelcomePortlet',NULL,NULL,'titleKey',0),(258,'portlet','ingrid-portal-apps','Contact',NULL,NULL,'sectionStyle',0),(259,'portlet','ingrid-portal-apps','Contact',NULL,NULL,'titleTag',0),(260,'portlet','ingrid-portal-apps','Contact',NULL,NULL,'articleStyle',0),(261,'portlet','ingrid-portal-apps','MyPortalLoginPortlet',NULL,NULL,'sectionStyle',0),(262,'portlet','ingrid-portal-apps','MyPortalOverviewPortlet',NULL,NULL,'sectionStyle',0),(263,'portlet','ingrid-portal-apps','MyPortalOverviewPortlet',NULL,NULL,'titleTag',0),(264,'portlet','ingrid-portal-apps','MyPortalCreateAccountPortlet',NULL,NULL,'sectionStyle',0),(265,'portlet','ingrid-portal-apps','MyPortalCreateAccountPortlet',NULL,NULL,'titleTag',0),(266,'portlet','ingrid-portal-apps','MyPortalCreateAccountPortlet',NULL,NULL,'articleStyle',0),(267,'portlet','ingrid-portal-apps','MyPortalEditAccountPortlet',NULL,NULL,'sectionStyle',0),(268,'portlet','ingrid-portal-apps','MyPortalEditAccountPortlet',NULL,NULL,'titleTag',0),(269,'portlet','ingrid-portal-apps','MyPortalEditAccountPortlet',NULL,NULL,'articleStyle',0),(270,'portlet','ingrid-portal-apps','MyPortalPasswordForgottenPortlet',NULL,NULL,'sectionStyle',0),(271,'portlet','ingrid-portal-apps','MyPortalPasswordForgottenPortlet',NULL,NULL,'titleTag',0),(272,'portlet','ingrid-portal-apps','MyPortalPasswordForgottenPortlet',NULL,NULL,'articleStyle',0),(273,'portlet','ingrid-portal-apps','ShowPartnerPortlet',NULL,NULL,'sectionStyle',0),(274,'portlet','ingrid-portal-apps','ShowPartnerPortlet',NULL,NULL,'titleTag',0),(275,'portlet','ingrid-portal-apps','ShowPartnerPortlet',NULL,NULL,'articleStyle',0),(276,'portlet','ingrid-portal-apps','ShowDataSourcePortlet',NULL,NULL,'sectionStyle',0),(277,'portlet','ingrid-portal-apps','ShowDataSourcePortlet',NULL,NULL,'titleTag',0),(278,'portlet','ingrid-portal-apps','ShowDataSourcePortlet',NULL,NULL,'articleStyle',0),(279,'portlet','ingrid-portal-apps','ChronicleSearch',NULL,NULL,'helpKey',0),(280,'portlet','ingrid-portal-apps','ChronicleSearch',NULL,NULL,'disableTitle',0),(281,'portlet','ingrid-portal-apps','ChronicleResult',NULL,NULL,'sectionStyle',0),(282,'portlet','ingrid-portal-apps','ChronicleResult',NULL,NULL,'disableTitle',0),(283,'portlet','ingrid-portal-apps','SearchResult',NULL,NULL,'divStyle',0),(284,'portlet','ingrid-portal-apps','SearchResult',NULL,NULL,'disableTitle',0),(285,'portlet','ingrid-portal-apps','SearchCatalogHierarchy',NULL,NULL,'sectionStyle',0),(286,'portlet','ingrid-portal-apps','SearchCatalogHierarchy',NULL,NULL,'helpKey',0),(287,'portlet','ingrid-portal-apps','SearchCatalogHierarchy',NULL,NULL,'disableTitle',0),(288,'portlet','ingrid-portal-apps','SearchCatalogHierarchy',NULL,NULL,'articleStyle',0);
/*!40000 ALTER TABLE `portlet_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_preference_value`
--

DROP TABLE IF EXISTS `portlet_preference_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_preference_value` (
  `ID` int(11) NOT NULL,
  `PREF_ID` int(11) NOT NULL,
  `IDX` smallint(6) NOT NULL,
  `PREF_VALUE` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`,`PREF_ID`,`IDX`),
  KEY `IX_PORTLET_PREFERENCE` (`PREF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_preference_value`
--

LOCK TABLES `portlet_preference_value` WRITE;
/*!40000 ALTER TABLE `portlet_preference_value` DISABLE KEYS */;
INSERT INTO `portlet_preference_value` VALUES (1,1,0,'/WEB-INF/templates/myportal/myportal_navigation.vm'),(2,2,0,'myPortal.info.navigation.title'),(3,3,0,'/WEB-INF/templates/newsletter_teaser.vm'),(4,4,0,'teaser.newsletter.title'),(5,5,0,'/WEB-INF/templates/myportal/login_teaser.vm'),(6,6,0,'teaser.login.title'),(7,7,0,'ingrid-home'),(8,8,0,'search-1'),(9,9,0,'0'),(10,10,0,'searchSimple.title.search'),(11,11,0,'ingrid-home'),(12,12,0,'search-topics-1'),(13,13,0,'1'),(14,14,0,'teaser.environment.title'),(15,15,0,'ingrid-home'),(16,16,0,'rss-news-1'),(17,17,0,'4'),(18,18,0,'2'),(19,19,0,'news.teaser.title'),(20,20,0,'ingrid.cms.default'),(21,21,0,'ingrid.teaser.inform'),(22,22,0,'ingrid-home-marginal'),(23,23,0,'ingrid-inform-1'),(24,24,0,'0'),(25,25,0,'/WEB-INF/templates/default_cms.vm'),(26,26,0,'teaser.ingridInform.title'),(27,27,0,'ingrid.home.welcome'),(28,28,0,'ingrid-home'),(29,29,0,'3'),(30,30,0,'/WEB-INF/templates/default_cms.vm'),(31,31,0,'ingrid.home.welcome.title'),(32,32,0,'ingrid-home-marginal'),(33,33,0,'search-service-1'),(34,34,0,'1'),(35,35,0,'teaser.service.title'),(36,36,0,'ingrid-home-marginal'),(37,37,0,'search-measure-1'),(38,38,0,'2'),(39,39,0,'teaser.measures.title'),(40,40,0,'ingrid-home-marginal'),(41,41,0,'search-chronicle-1'),(42,42,0,'3'),(43,43,0,'chronicle.teaser.title'),(44,44,0,'ingrid-home-marginal'),(45,45,0,'4'),(46,46,0,'teaser.weather.title'),(47,47,0,'search-catalog-1'),(48,48,0,'search-catalog-2'),(49,49,0,'mdek.title.entry'),(50,50,0,'mdek.title.portaladmin'),(51,51,0,'mdek.title.adminlogin'),(61,61,0,'block--padded'),(62,62,0,'mdek.title.entry'),(63,63,0,'block--padded'),(64,64,0,'mdek.title.portaladmin'),(65,65,0,'block--padded'),(66,66,0,'mdek.title.adminlogin'),(67,67,0,'content ob-container ob-box-narrow ob-box-center'),(68,68,0,'block--padded'),(69,69,0,'1'),(70,70,0,'h1'),(71,71,0,'block--padded'),(72,72,0,'h1'),(73,73,0,'block--padded'),(74,74,0,'h1'),(75,75,0,'block--padded'),(76,76,0,'h1'),(77,77,0,'block--padded'),(78,78,0,'h1'),(79,79,0,'block--padded'),(80,80,0,'ob-box-padded-more ob-box-center'),(81,81,0,'h1'),(82,82,0,'content ob-container ob-box-narrow ob-box-center'),(83,83,0,'block--padded'),(84,84,0,'h1'),(85,85,0,'block--padded'),(86,86,0,'h1'),(87,87,0,'content ob-container ob-box-narrow ob-box-center'),(88,88,0,'block--padded'),(89,89,0,'h1'),(90,90,0,'content ob-container ob-box-narrow ob-box-center'),(91,91,0,'block--padded'),(92,92,0,'h1'),(93,93,0,'content ob-container ob-box-narrow ob-box-center'),(94,94,0,'block--padded'),(95,95,0,'h1'),(96,96,0,'content ob-container ob-box-narrow ob-box-center'),(97,97,0,'block--padded'),(98,98,0,'ingrid-home'),(99,99,0,'search-1'),(100,100,0,'1'),(101,101,0,'0'),(102,102,0,'searchSimple.title.search'),(103,103,0,'ingrid-home'),(104,104,0,'block--pad-top'),(105,105,0,'2'),(106,106,0,'search.teaser.portlet.title'),(107,107,0,'ingrid-home'),(108,108,0,'search-topics-1'),(109,109,0,'block--pad-top'),(110,110,0,'4'),(111,111,0,'teaser.environment.title'),(112,112,0,'ingrid-home'),(113,113,0,'rss-news-1'),(114,114,0,'block--pad-top block--light'),(115,115,0,'4'),(116,116,0,'3'),(117,117,0,'news.teaser.title'),(118,118,0,'block--padded'),(119,119,0,'0'),(120,120,0,'ingrid.cms.default'),(121,121,0,'ingrid.about'),(122,122,0,'about-1'),(123,123,0,'ingrid.disclaimer'),(124,124,0,'h1'),(125,125,0,'content ob-container ob-box-narrow ob-box-center'),(126,126,0,'ingrid.privacy'),(127,127,0,'block--padded'),(128,128,0,'ingrid-home'),(129,129,0,'ingrid.teaser.inform'),(130,130,0,'ingrid-inform-1'),(131,131,0,'block--pad-top block--light'),(132,132,0,'1'),(133,133,0,'/WEB-INF/templates/default_cms.vm'),(134,134,0,'teaser.ingridInform.title'),(135,135,0,'ingrid-home'),(136,136,0,'block--pad-bottom'),(137,137,0,'1'),(138,138,0,'5'),(139,139,0,'/WEB-INF/templates/info_teaser.vm'),(140,140,0,'Info Portlet'),(141,141,0,'ingrid.home.welcome'),(142,142,0,'/WEB-INF/templates/default_cms.vm'),(143,143,0,'ingrid.home.welcome.title'),(144,144,0,'h1'),(145,145,0,'content ob-container ob-box-narrow ob-box-center'),(146,146,0,'block--padded'),(147,147,0,'block--padded'),(148,148,0,'h1'),(149,149,0,'block--padded'),(150,150,0,'h1'),(151,151,0,'content ob-container ob-box-narrow ob-box-center'),(152,152,0,'block--padded'),(153,153,0,'h1'),(154,154,0,'content ob-container ob-box-narrow ob-box-center'),(155,155,0,'block--padded'),(156,156,0,'h1'),(157,157,0,'content ob-container ob-box-narrow ob-box-center'),(158,158,0,'block--padded'),(159,159,0,'h1'),(160,160,0,'content ob-container ob-box-narrow ob-box-center'),(161,161,0,'block--padded'),(162,162,0,'h1'),(163,163,0,'content ob-container ob-box-narrow ob-box-center'),(164,164,0,'block--padded'),(165,165,0,'h1'),(166,166,0,'content ob-container ob-box-narrow ob-box-center'),(167,167,0,'block--padded'),(168,168,0,'search-chronicle-1'),(169,169,0,'1'),(170,170,0,'1'),(171,171,0,'block--padded'),(172,172,0,'1'),(173,173,0,'ob-box-wide ob-box-padded ob-box-center ob-rel'),(174,174,0,'content ob-container ob-box-narrow ob-box-center'),(175,175,0,'search-catalog-1'),(176,176,0,'block--padded'),(177,177,0,'1'),(181,181,0,'block--padded'),(182,182,0,'1'),(183,183,0,'content ob-container ob-box-narrow ob-box-center'),(184,184,0,'block--padded'),(185,185,0,'h1'),(186,186,0,'block--padded'),(187,187,0,'h1'),(188,188,0,'block--padded'),(189,189,0,'h1'),(190,190,0,'block--padded'),(191,191,0,'h1'),(192,192,0,'block--padded'),(193,193,0,'ob-box-padded-more ob-box-center'),(194,194,0,'h1'),(195,195,0,'block--padded'),(196,196,0,'h1'),(197,197,0,'content ob-container ob-box-narrow ob-box-center'),(198,198,0,'block--padded'),(199,199,0,'h1'),(200,200,0,'block--padded'),(201,201,0,'h1'),(202,202,0,'content ob-container ob-box-narrow ob-box-center'),(203,203,0,'block--padded'),(204,204,0,'h1'),(205,205,0,'content ob-container ob-box-narrow ob-box-center'),(206,206,0,'block--padded'),(207,207,0,'h1'),(208,208,0,'content ob-container ob-box-narrow ob-box-center'),(209,209,0,'block--padded'),(210,210,0,'h1'),(211,211,0,'content ob-container ob-box-narrow ob-box-center'),(212,212,0,'ingrid-home'),(213,213,0,'0'),(214,214,0,'search-1'),(215,215,0,'1'),(216,216,0,'searchSimple.title.search'),(217,217,0,'block--pad-top'),(218,218,0,'ingrid-home'),(219,219,0,'2'),(220,220,0,'search.teaser.portlet.title'),(221,221,0,'block--pad-top'),(222,222,0,'ingrid-home'),(223,223,0,'4'),(224,224,0,'search-topics-1'),(225,225,0,'teaser.environment.title'),(226,226,0,'block--pad-top block--light'),(227,227,0,'ingrid-home'),(228,228,0,'3'),(229,229,0,'rss-news-1'),(230,230,0,'news.teaser.title'),(231,231,0,'4'),(232,232,0,'block--padded'),(233,233,0,'0'),(234,234,0,'ingrid.cms.default'),(235,235,0,'ingrid.about'),(236,236,0,'about-1'),(237,237,0,'ingrid.disclaimer'),(238,238,0,'block--padded'),(239,239,0,'ingrid.privacy'),(240,240,0,'h1'),(241,241,0,'content ob-container ob-box-narrow ob-box-center'),(242,242,0,'block--pad-top block--light'),(243,243,0,'ingrid-home'),(244,244,0,'ingrid.teaser.inform'),(245,245,0,'ingrid-inform-1'),(246,246,0,'1'),(247,247,0,'/WEB-INF/templates/default_cms.vm'),(248,248,0,'teaser.ingridInform.title'),(249,249,0,'block--pad-bottom'),(250,250,0,'ingrid-home'),(251,251,0,'5'),(252,252,0,'1'),(253,253,0,'/WEB-INF/templates/info_teaser.vm'),(254,254,0,'Info Portlet'),(255,255,0,'ingrid.home.welcome'),(256,256,0,'/WEB-INF/templates/default_cms.vm'),(257,257,0,'ingrid.home.welcome.title'),(258,258,0,'block--padded'),(259,259,0,'h1'),(260,260,0,'content ob-container ob-box-narrow ob-box-center'),(261,261,0,'block--padded'),(262,262,0,'block--padded'),(263,263,0,'h1'),(264,264,0,'block--padded'),(265,265,0,'h1'),(266,266,0,'content ob-container ob-box-narrow ob-box-center'),(267,267,0,'block--padded'),(268,268,0,'h1'),(269,269,0,'content ob-container ob-box-narrow ob-box-center'),(270,270,0,'block--padded'),(271,271,0,'h1'),(272,272,0,'content ob-container ob-box-narrow ob-box-center'),(273,273,0,'block--padded'),(274,274,0,'h1'),(275,275,0,'content ob-container ob-box-narrow ob-box-center'),(276,276,0,'block--padded'),(277,277,0,'h1'),(278,278,0,'content ob-container ob-box-narrow ob-box-center'),(279,279,0,'search-chronicle-1'),(280,280,0,'1'),(281,281,0,'block--padded'),(282,282,0,'1'),(283,283,0,'ob-box-wide ob-box-padded ob-box-center ob-rel'),(284,284,0,'1'),(285,285,0,'block--padded'),(286,286,0,'search-catalog-1'),(287,287,0,'1'),(288,288,0,'content ob-container ob-box-narrow ob-box-center');
/*!40000 ALTER TABLE `portlet_preference_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_statistics`
--

DROP TABLE IF EXISTS `portlet_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_statistics` (
  `IPADDRESS` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_STAMP` datetime DEFAULT NULL,
  `PAGE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PORTLET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `ELAPSED_TIME` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_statistics`
--

LOCK TABLES `portlet_statistics` WRITE;
/*!40000 ALTER TABLE `portlet_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `portlet_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portlet_supports`
--

DROP TABLE IF EXISTS `portlet_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portlet_supports` (
  `SUPPORTS_ID` int(11) NOT NULL,
  `PORTLET_ID` int(11) NOT NULL,
  `MIME_TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `MODES` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATES` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`SUPPORTS_ID`),
  UNIQUE KEY `UK_SUPPORTS` (`PORTLET_ID`,`MIME_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portlet_supports`
--

LOCK TABLES `portlet_supports` WRITE;
/*!40000 ALTER TABLE `portlet_supports` DISABLE KEYS */;
INSERT INTO `portlet_supports` VALUES (141,139,'text/html','\"view\"',''),(142,140,'text/html','\"view\"',''),(143,141,'text/html','\"view\"',''),(201,201,'text/html','\"view\"',''),(202,202,'text/html','\"view\"',''),(203,203,'text/html','\"view\"',''),(204,204,'text/html','\"view\"',''),(205,205,'text/html','\"view\"',''),(206,206,'text/html','\"view\"',''),(207,207,'text/html','\"view\"',''),(208,208,'text/html','\"view\"',''),(209,209,'text/html','\"view\"',''),(210,210,'text/html','\"view\"',''),(211,211,'text/html','\"view\"',''),(212,212,'text/html','\"view\"',''),(213,213,'text/html','\"view\"',''),(214,214,'text/html','\"view\"',''),(215,215,'text/html','\"view\"',''),(216,216,'text/html','\"view\"',''),(217,217,'text/html','\"view\"',''),(218,218,'text/html','\"view\"',''),(219,219,'text/html','\"view\"',''),(220,220,'text/html','\"view\"',''),(221,221,'text/html','\"view\"',''),(222,222,'text/html','\"view\"',''),(223,223,'text/html','\"view\"',''),(224,224,'text/html','\"view\"',''),(225,225,'text/html','\"view\"',''),(226,226,'text/html','\"view\"',''),(227,227,'text/html','\"view\"',''),(228,228,'text/html','\"view\"',''),(229,229,'text/html','\"view\"',''),(230,230,'text/html','\"view\"',''),(231,231,'text/html','\"view\"',''),(232,232,'text/html','\"view\"',''),(233,233,'text/html','\"view\"',''),(234,234,'text/html','\"view\"',''),(235,235,'text/html','\"view\"',''),(236,236,'text/html','\"view\"',''),(237,237,'text/html','\"view\"',''),(238,238,'text/html','\"view\"',''),(239,239,'text/html','\"view\"',''),(240,240,'text/html','\"view\"',''),(241,241,'text/html','\"view\"',''),(242,242,'text/html','\"view\"',''),(243,243,'text/html','\"view\"',''),(244,244,'text/html','\"view\"',''),(245,245,'text/html','\"view\"',''),(246,246,'text/html','\"view\"',''),(261,261,'text/html','\"view\"',''),(262,262,'text/html','\"view\"',''),(263,263,'text/html','\"view\"',''),(264,264,'text/html','\"view\"',''),(265,265,'text/html','\"view\",\"edit\",\"help\"',''),(266,265,'text/vnd.wap.wml','\"view\"',''),(267,266,'text/html','\"view\",\"edit\",\"help\"',''),(268,267,'text/html','\"view\",\"edit\",\"help\"',''),(269,268,'text/html','\"view\",\"edit\",\"help\"',''),(270,269,'text/html','\"view\",\"edit\",\"help\"',''),(271,270,'text/html','\"view\",\"edit\",\"help\"',''),(272,271,'text/html','\"view\"',''),(273,271,'text/vnd.wap.wml','\"view\"',''),(274,272,'text/html','\"view\"',''),(275,273,'text/html','\"view\"',''),(276,274,'text/html','\"view\"',''),(277,275,'text/html','\"view\",\"edit\",\"help\"',''),(278,276,'text/html','\"view\"',''),(279,277,'text/html','\"view\",\"edit\",\"help\"',''),(280,278,'text/html','\"view\",\"edit\",\"help\"','');
/*!40000 ALTER TABLE `portlet_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefs_node`
--

DROP TABLE IF EXISTS `prefs_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prefs_node` (
  `NODE_ID` mediumint(9) NOT NULL,
  `PARENT_NODE_ID` mediumint(9) DEFAULT NULL,
  `NODE_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NODE_TYPE` smallint(6) DEFAULT NULL,
  `FULL_PATH` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CREATION_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODIFIED_DATE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`NODE_ID`),
  KEY `PARENT_NODE_ID` (`PARENT_NODE_ID`),
  KEY `FULL_PATH` (`FULL_PATH`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefs_node`
--

LOCK TABLES `prefs_node` WRITE;
/*!40000 ALTER TABLE `prefs_node` DISABLE KEYS */;
INSERT INTO `prefs_node` VALUES (1,NULL,'',1,'/','2007-06-08 13:57:04','2007-06-08 13:57:04'),(2,NULL,'',0,'/','2007-06-08 13:57:04','2007-06-08 13:57:04'),(3,2,'role',0,'/role','2007-06-08 13:57:07','2007-06-08 13:57:07'),(4,3,'admin',0,'/role/admin','2007-06-08 13:57:07','2007-06-08 13:57:07'),(5,3,'guest',0,'/role/guest','2007-06-08 13:57:07','2007-06-08 13:57:07'),(6,3,'user',0,'/role/user','2007-06-08 13:57:07','2007-06-08 13:57:07'),(7,3,'dev',0,'/role/dev','2007-06-08 13:57:07','2007-06-08 13:57:07'),(8,3,'devmgr',0,'/role/devmgr','2007-06-08 13:57:07','2007-06-08 13:57:07'),(9,2,'user',0,'/user','2007-06-08 13:57:07','2007-06-08 13:57:07'),(10,9,'admin',0,'/user/admin','2007-06-08 13:57:07','2007-06-08 13:57:07'),(11,10,'userinfo',0,'/user/admin/userinfo','2007-06-08 13:57:08','2007-06-08 13:57:08'),(12,9,'guest',0,'/user/guest','2007-06-08 13:57:08','2007-06-08 13:57:08'),(13,12,'userinfo',0,'/user/guest/userinfo','2007-06-08 13:57:08','2007-06-08 13:57:08'),(14,9,'devmgr',0,'/user/devmgr','2007-06-08 13:57:08','2007-06-08 13:57:08'),(15,14,'userinfo',0,'/user/devmgr/userinfo','2007-06-08 13:57:08','2007-06-08 13:57:08'),(16,3,'admin-portal',0,'/role/admin-portal','2007-06-08 13:57:08','2007-06-08 13:57:08'),(17,3,'admin-partner',0,'/role/admin-partner','2007-06-08 13:57:08','2007-06-08 13:57:08'),(18,3,'admin-provider',0,'/role/admin-provider','2007-06-08 13:57:08','2007-06-08 13:57:08'),(21,1,'portlet_application',1,'/portlet_application','2010-12-17 13:35:54','2010-12-17 13:35:54'),(681,489,'mdek',0,'/portlet_entity/57/mdek','2011-03-30 10:00:18','2011-03-30 10:00:18'),(682,681,'preferences',0,'/portlet_entity/57/mdek/preferences','2011-03-30 10:00:18','2011-03-30 10:00:18'),(701,541,'mdek',0,'/portlet_entity/200/mdek','2011-03-31 17:41:53','2011-03-31 17:41:53'),(702,701,'preferences',0,'/portlet_entity/200/mdek/preferences','2011-03-31 17:41:53','2011-03-31 17:41:53'),(721,185,'240',0,'/portlet_entity/240','2011-04-01 12:45:07','2011-04-01 12:45:07'),(4787,4785,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/infoTemplate/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4788,4778,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4789,4788,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4786,4785,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/infoTemplate/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4681,21,'ingrid-portal-apps',1,'/portlet_application/ingrid-portal-apps','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4682,4681,'portlets',1,'/portlet_application/ingrid-portal-apps/portlets','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4683,4682,'MyPortalEditAboutInfoPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4684,4683,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4685,4684,'infoTemplate',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/infoTemplate','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4686,4685,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/infoTemplate/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4687,4685,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/infoTemplate/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4688,4684,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4689,4688,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4690,4688,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAboutInfoPortlet/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4691,4682,'MyPortalEditNewsletterInfoPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4692,4691,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4693,4692,'infoTemplate',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/infoTemplate','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4694,4693,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/infoTemplate/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4695,4693,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/infoTemplate/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4696,4692,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4697,4696,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4698,4696,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditNewsletterInfoPortlet/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4699,4682,'MyPortalEditAdvancedInfoPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4700,4699,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4701,4700,'infoTemplate',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/infoTemplate','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4702,4701,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/infoTemplate/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4703,4701,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/infoTemplate/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4704,4700,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4705,4704,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4706,4704,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalEditAdvancedInfoPortlet/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4707,4682,'SearchSimple',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4708,4707,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4709,4708,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/portlet-type','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4710,4709,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/portlet-type/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4711,4709,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/portlet-type/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4712,4708,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/default-vertical-position','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4713,4712,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/default-vertical-position/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4714,4712,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/default-vertical-position/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4715,4708,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4716,4715,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4717,4715,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4718,4708,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/helpKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4719,4718,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/helpKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4720,4718,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchSimple/preferences/helpKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4721,4682,'EnvironmentTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4722,4721,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4723,4722,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/portlet-type','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4724,4723,'values',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/portlet-type/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4725,4723,'size',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/portlet-type/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4726,4722,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/default-vertical-position','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4727,4726,'values',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4728,4726,'size',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4729,4722,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4730,4729,'values',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4731,4729,'size',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4732,4722,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/helpKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4733,4732,'values',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/helpKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4734,4732,'size',1,'/portlet_application/ingrid-portal-apps/portlets/EnvironmentTeaser/preferences/helpKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4735,4682,'RssNewsTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4736,4735,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4737,4736,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/portlet-type','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4738,4737,'values',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/portlet-type/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4739,4737,'size',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/portlet-type/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4740,4736,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/default-vertical-position','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4741,4740,'values',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4742,4740,'size',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4743,4736,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/titleKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4744,4743,'values',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/titleKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4745,4743,'size',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/titleKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4746,4736,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/helpKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4747,4746,'values',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/helpKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4748,4746,'size',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/helpKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4749,4736,'noOfEntriesDisplayed',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/noOfEntriesDisplayed','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4750,4749,'values',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/noOfEntriesDisplayed/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4751,4749,'size',1,'/portlet_application/ingrid-portal-apps/portlets/RssNewsTeaser/preferences/noOfEntriesDisplayed/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4752,4682,'CMSPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/CMSPortlet','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4753,4752,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/CMSPortlet/preferences','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4754,4753,'cmsKey',1,'/portlet_application/ingrid-portal-apps/portlets/CMSPortlet/preferences/cmsKey','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4755,4754,'values',1,'/portlet_application/ingrid-portal-apps/portlets/CMSPortlet/preferences/cmsKey/values','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4756,4754,'size',1,'/portlet_application/ingrid-portal-apps/portlets/CMSPortlet/preferences/cmsKey/size','2012-09-20 15:20:06','2012-09-20 15:20:06'),(4757,4682,'IngridInformPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4758,4757,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(185,2,'portlet_entity',0,'/portlet_entity','2010-12-17 13:37:00','2010-12-17 13:37:00'),(186,185,'2',0,'/portlet_entity/2','2010-12-17 13:37:00','2010-12-17 13:37:00'),(187,186,'guest',0,'/portlet_entity/2/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(188,187,'preferences',0,'/portlet_entity/2/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(189,185,'3',0,'/portlet_entity/3','2010-12-17 13:37:00','2010-12-17 13:37:00'),(190,189,'guest',0,'/portlet_entity/3/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(191,190,'preferences',0,'/portlet_entity/3/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(192,185,'4',0,'/portlet_entity/4','2010-12-17 13:37:00','2010-12-17 13:37:00'),(193,192,'guest',0,'/portlet_entity/4/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(194,193,'preferences',0,'/portlet_entity/4/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(195,185,'5',0,'/portlet_entity/5','2010-12-17 13:37:00','2010-12-17 13:37:00'),(196,195,'guest',0,'/portlet_entity/5/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(197,196,'preferences',0,'/portlet_entity/5/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(198,185,'6',0,'/portlet_entity/6','2010-12-17 13:37:00','2010-12-17 13:37:00'),(199,198,'guest',0,'/portlet_entity/6/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(200,199,'preferences',0,'/portlet_entity/6/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(201,185,'7',0,'/portlet_entity/7','2010-12-17 13:37:00','2010-12-17 13:37:00'),(202,201,'guest',0,'/portlet_entity/7/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(203,202,'preferences',0,'/portlet_entity/7/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(204,185,'8',0,'/portlet_entity/8','2010-12-17 13:37:00','2010-12-17 13:37:00'),(205,204,'guest',0,'/portlet_entity/8/guest','2010-12-17 13:37:00','2010-12-17 13:37:00'),(206,205,'preferences',0,'/portlet_entity/8/guest/preferences','2010-12-17 13:37:00','2010-12-17 13:37:00'),(207,185,'1',0,'/portlet_entity/1','2010-12-17 13:37:01','2010-12-17 13:37:01'),(208,207,'guest',0,'/portlet_entity/1/guest','2010-12-17 13:37:01','2010-12-17 13:37:01'),(209,208,'preferences',0,'/portlet_entity/1/guest/preferences','2010-12-17 13:37:01','2010-12-17 13:37:01'),(4524,4523,'preferences',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekAdminLoginPortlet/preferences','2011-09-26 12:12:53','2011-09-26 12:12:53'),(4767,4765,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/infoTemplate/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4768,4758,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(221,185,'9',0,'/portlet_entity/9','2010-12-17 15:02:04','2010-12-17 15:02:04'),(222,221,'guest',0,'/portlet_entity/9/guest','2010-12-17 15:02:04','2010-12-17 15:02:04'),(223,222,'preferences',0,'/portlet_entity/9/guest/preferences','2010-12-17 15:02:04','2010-12-17 15:02:04'),(4769,4768,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(226,185,'81',0,'/portlet_entity/81','2010-12-17 15:02:16','2010-12-17 15:02:16'),(227,226,'guest',0,'/portlet_entity/81/guest','2010-12-17 15:02:16','2010-12-17 15:02:16'),(228,227,'preferences',0,'/portlet_entity/81/guest/preferences','2010-12-17 15:02:16','2010-12-17 15:02:16'),(2254,2253,'preferences',0,'/portlet_entity/53/guest/preferences','2011-07-13 17:11:04','2011-07-13 17:11:04'),(231,185,'79',0,'/portlet_entity/79','2010-12-17 15:02:16','2010-12-17 15:02:16'),(232,231,'guest',0,'/portlet_entity/79/guest','2010-12-17 15:02:16','2010-12-17 15:02:16'),(233,232,'preferences',0,'/portlet_entity/79/guest/preferences','2010-12-17 15:02:16','2010-12-17 15:02:16'),(4858,4857,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/InfoPortlet/preferences','2012-09-20 15:20:18','2012-09-20 15:20:18'),(236,185,'107',0,'/portlet_entity/107','2010-12-17 15:02:31','2010-12-17 15:02:31'),(237,236,'admin',0,'/portlet_entity/107/admin','2010-12-17 15:02:31','2010-12-17 15:02:31'),(238,237,'preferences',0,'/portlet_entity/107/admin/preferences','2010-12-17 15:02:31','2010-12-17 15:02:31'),(239,185,'105',0,'/portlet_entity/105','2010-12-17 15:02:31','2010-12-17 15:02:31'),(240,239,'admin',0,'/portlet_entity/105/admin','2010-12-17 15:02:31','2010-12-17 15:02:31'),(241,240,'preferences',0,'/portlet_entity/105/admin/preferences','2010-12-17 15:02:31','2010-12-17 15:02:31'),(1658,1657,'preferences',0,'/portlet_entity/586/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1656,185,'586',0,'/portlet_entity/586','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1657,1656,'guest',0,'/portlet_entity/586/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(244,221,'admin',0,'/portlet_entity/9/admin','2010-12-17 15:02:32','2010-12-17 15:02:32'),(245,244,'preferences',0,'/portlet_entity/9/admin/preferences','2010-12-17 15:02:32','2010-12-17 15:02:32'),(246,3,'mdek',0,'/role/mdek','2010-12-17 15:02:34','2010-12-17 15:02:34'),(247,185,'281',0,'/portlet_entity/281','2010-12-17 15:02:35','2010-12-17 15:02:35'),(248,247,'admin',0,'/portlet_entity/281/admin','2010-12-17 15:02:35','2010-12-17 15:02:35'),(249,248,'preferences',0,'/portlet_entity/281/admin/preferences','2010-12-17 15:02:35','2010-12-17 15:02:35'),(250,185,'300',0,'/portlet_entity/300','2010-12-17 15:02:35','2010-12-17 15:02:35'),(251,250,'admin',0,'/portlet_entity/300/admin','2010-12-17 15:02:35','2010-12-17 15:02:35'),(252,251,'preferences',0,'/portlet_entity/300/admin/preferences','2010-12-17 15:02:35','2010-12-17 15:02:35'),(253,185,'280',0,'/portlet_entity/280','2010-12-17 15:02:35','2010-12-17 15:02:35'),(254,253,'admin',0,'/portlet_entity/280/admin','2010-12-17 15:02:35','2010-12-17 15:02:35'),(255,254,'preferences',0,'/portlet_entity/280/admin/preferences','2010-12-17 15:02:35','2010-12-17 15:02:35'),(258,185,'116',0,'/portlet_entity/116','2010-12-17 15:02:47','2010-12-17 15:02:47'),(259,258,'admin',0,'/portlet_entity/116/admin','2010-12-17 15:02:47','2010-12-17 15:02:47'),(260,259,'preferences',0,'/portlet_entity/116/admin/preferences','2010-12-17 15:02:47','2010-12-17 15:02:47'),(263,185,'134',0,'/portlet_entity/134','2010-12-17 15:02:50','2010-12-17 15:02:50'),(264,263,'admin',0,'/portlet_entity/134/admin','2010-12-17 15:02:50','2010-12-17 15:02:50'),(265,264,'preferences',0,'/portlet_entity/134/admin/preferences','2010-12-17 15:02:50','2010-12-17 15:02:50'),(1642,1641,'guest',0,'/portlet_entity/581/guest','2011-07-13 15:49:17','2011-07-13 15:49:17'),(1643,1642,'preferences',0,'/portlet_entity/581/guest/preferences','2011-07-13 15:49:17','2011-07-13 15:49:17'),(1644,185,'582',0,'/portlet_entity/582','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1645,1644,'guest',0,'/portlet_entity/582/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1646,1645,'preferences',0,'/portlet_entity/582/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(2251,2250,'preferences',0,'/portlet_entity/54/guest/preferences','2011-07-13 17:11:04','2011-07-13 17:11:04'),(561,9,'mdek',0,'/user/mdek','2011-03-01 17:29:32','2011-03-01 17:29:32'),(562,561,'userinfo',0,'/user/mdek/userinfo','2011-03-01 17:29:32','2011-03-01 17:29:32'),(281,236,'mdek',0,'/portlet_entity/107/mdek','2010-12-20 09:11:37','2010-12-20 09:11:37'),(282,281,'preferences',0,'/portlet_entity/107/mdek/preferences','2010-12-20 09:11:37','2010-12-20 09:11:37'),(283,239,'mdek',0,'/portlet_entity/105/mdek','2010-12-20 09:11:37','2010-12-20 09:11:37'),(284,283,'preferences',0,'/portlet_entity/105/mdek/preferences','2010-12-20 09:11:37','2010-12-20 09:11:37'),(285,221,'mdek',0,'/portlet_entity/9/mdek','2010-12-20 09:11:38','2010-12-20 09:11:38'),(286,285,'preferences',0,'/portlet_entity/9/mdek/preferences','2010-12-20 09:11:38','2010-12-20 09:11:38'),(287,185,'283',0,'/portlet_entity/283','2010-12-20 09:11:40','2010-12-20 09:11:40'),(288,287,'mdek',0,'/portlet_entity/283/mdek','2010-12-20 09:11:40','2010-12-20 09:11:40'),(289,288,'preferences',0,'/portlet_entity/283/mdek/preferences','2010-12-20 09:11:40','2010-12-20 09:11:40'),(290,185,'284',0,'/portlet_entity/284','2010-12-20 09:11:41','2010-12-20 09:11:41'),(291,290,'mdek',0,'/portlet_entity/284/mdek','2010-12-20 09:11:41','2010-12-20 09:11:41'),(292,291,'preferences',0,'/portlet_entity/284/mdek/preferences','2010-12-20 09:11:41','2010-12-20 09:11:41'),(293,253,'mdek',0,'/portlet_entity/280/mdek','2010-12-20 09:11:41','2010-12-20 09:11:41'),(294,293,'preferences',0,'/portlet_entity/280/mdek/preferences','2010-12-20 09:11:41','2010-12-20 09:11:41'),(301,185,'31',0,'/portlet_entity/31','2011-02-25 15:25:02','2011-02-25 15:25:02'),(302,301,'guest',0,'/portlet_entity/31/guest','2011-02-25 15:25:02','2011-02-25 15:25:02'),(303,302,'preferences',0,'/portlet_entity/31/guest/preferences','2011-02-25 15:25:02','2011-02-25 15:25:02'),(306,185,'30',0,'/portlet_entity/30','2011-02-25 15:25:02','2011-02-25 15:25:02'),(307,306,'guest',0,'/portlet_entity/30/guest','2011-02-25 15:25:02','2011-02-25 15:25:02'),(308,307,'preferences',0,'/portlet_entity/30/guest/preferences','2011-02-25 15:25:02','2011-02-25 15:25:02'),(309,185,'38',0,'/portlet_entity/38','2011-02-25 15:25:15','2011-02-25 15:25:15'),(310,309,'guest',0,'/portlet_entity/38/guest','2011-02-25 15:25:15','2011-02-25 15:25:15'),(311,310,'preferences',0,'/portlet_entity/38/guest/preferences','2011-02-25 15:25:15','2011-02-25 15:25:15'),(312,185,'39',0,'/portlet_entity/39','2011-02-25 15:25:15','2011-02-25 15:25:15'),(313,312,'guest',0,'/portlet_entity/39/guest','2011-02-25 15:25:15','2011-02-25 15:25:15'),(314,313,'preferences',0,'/portlet_entity/39/guest/preferences','2011-02-25 15:25:15','2011-02-25 15:25:15'),(315,185,'37',0,'/portlet_entity/37','2011-02-25 15:25:15','2011-02-25 15:25:15'),(316,315,'guest',0,'/portlet_entity/37/guest','2011-02-25 15:25:15','2011-02-25 15:25:15'),(317,316,'preferences',0,'/portlet_entity/37/guest/preferences','2011-02-25 15:25:15','2011-02-25 15:25:15'),(318,185,'41',0,'/portlet_entity/41','2011-02-25 15:25:15','2011-02-25 15:25:15'),(319,318,'guest',0,'/portlet_entity/41/guest','2011-02-25 15:25:15','2011-02-25 15:25:15'),(320,319,'preferences',0,'/portlet_entity/41/guest/preferences','2011-02-25 15:25:15','2011-02-25 15:25:15'),(321,185,'36',0,'/portlet_entity/36','2011-02-25 15:25:15','2011-02-25 15:25:15'),(322,321,'guest',0,'/portlet_entity/36/guest','2011-02-25 15:25:15','2011-02-25 15:25:15'),(323,322,'preferences',0,'/portlet_entity/36/guest/preferences','2011-02-25 15:25:15','2011-02-25 15:25:15'),(324,185,'46',0,'/portlet_entity/46','2011-02-25 15:25:17','2011-02-25 15:25:17'),(325,324,'guest',0,'/portlet_entity/46/guest','2011-02-25 15:25:17','2011-02-25 15:25:17'),(326,325,'preferences',0,'/portlet_entity/46/guest/preferences','2011-02-25 15:25:17','2011-02-25 15:25:17'),(327,185,'43',0,'/portlet_entity/43','2011-02-25 15:25:17','2011-02-25 15:25:17'),(328,327,'guest',0,'/portlet_entity/43/guest','2011-02-25 15:25:17','2011-02-25 15:25:17'),(329,328,'preferences',0,'/portlet_entity/43/guest/preferences','2011-02-25 15:25:17','2011-02-25 15:25:17'),(332,185,'35',0,'/portlet_entity/35','2011-02-25 15:25:19','2011-02-25 15:25:19'),(333,332,'guest',0,'/portlet_entity/35/guest','2011-02-25 15:25:19','2011-02-25 15:25:19'),(334,333,'preferences',0,'/portlet_entity/35/guest/preferences','2011-02-25 15:25:19','2011-02-25 15:25:19'),(335,185,'32',0,'/portlet_entity/32','2011-02-25 15:25:19','2011-02-25 15:25:19'),(336,335,'guest',0,'/portlet_entity/32/guest','2011-02-25 15:25:19','2011-02-25 15:25:19'),(337,336,'preferences',0,'/portlet_entity/32/guest/preferences','2011-02-25 15:25:19','2011-02-25 15:25:19'),(340,185,'25',0,'/portlet_entity/25','2011-02-25 15:25:22','2011-02-25 15:25:22'),(341,340,'guest',0,'/portlet_entity/25/guest','2011-02-25 15:25:22','2011-02-25 15:25:22'),(342,341,'preferences',0,'/portlet_entity/25/guest/preferences','2011-02-25 15:25:22','2011-02-25 15:25:22'),(343,185,'22',0,'/portlet_entity/22','2011-02-25 15:25:22','2011-02-25 15:25:22'),(344,343,'guest',0,'/portlet_entity/22/guest','2011-02-25 15:25:22','2011-02-25 15:25:22'),(345,344,'preferences',0,'/portlet_entity/22/guest/preferences','2011-02-25 15:25:22','2011-02-25 15:25:22'),(348,185,'63',0,'/portlet_entity/63','2011-02-25 15:27:37','2011-02-25 15:27:37'),(349,348,'guest',0,'/portlet_entity/63/guest','2011-02-25 15:27:37','2011-02-25 15:27:37'),(350,349,'preferences',0,'/portlet_entity/63/guest/preferences','2011-02-25 15:27:37','2011-02-25 15:27:37'),(361,185,'29',0,'/portlet_entity/29','2011-02-25 15:32:36','2011-02-25 15:32:36'),(362,361,'guest',0,'/portlet_entity/29/guest','2011-02-25 15:32:36','2011-02-25 15:32:36'),(363,362,'preferences',0,'/portlet_entity/29/guest/preferences','2011-02-25 15:32:36','2011-02-25 15:32:36'),(364,185,'26',0,'/portlet_entity/26','2011-02-25 15:32:36','2011-02-25 15:32:36'),(365,364,'guest',0,'/portlet_entity/26/guest','2011-02-25 15:32:36','2011-02-25 15:32:36'),(366,365,'preferences',0,'/portlet_entity/26/guest/preferences','2011-02-25 15:32:36','2011-02-25 15:32:36'),(1935,185,'667',0,'/portlet_entity/667','2011-07-13 16:08:36','2011-07-13 16:08:36'),(369,185,'85',0,'/portlet_entity/85','2011-02-25 15:32:51','2011-02-25 15:32:51'),(370,369,'admin',0,'/portlet_entity/85/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(371,370,'preferences',0,'/portlet_entity/85/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(372,185,'86',0,'/portlet_entity/86','2011-02-25 15:32:51','2011-02-25 15:32:51'),(373,372,'admin',0,'/portlet_entity/86/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(374,373,'preferences',0,'/portlet_entity/86/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(375,185,'87',0,'/portlet_entity/87','2011-02-25 15:32:51','2011-02-25 15:32:51'),(376,375,'admin',0,'/portlet_entity/87/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(377,376,'preferences',0,'/portlet_entity/87/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(378,185,'88',0,'/portlet_entity/88','2011-02-25 15:32:51','2011-02-25 15:32:51'),(379,378,'admin',0,'/portlet_entity/88/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(380,379,'preferences',0,'/portlet_entity/88/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(381,185,'89',0,'/portlet_entity/89','2011-02-25 15:32:51','2011-02-25 15:32:51'),(382,381,'admin',0,'/portlet_entity/89/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(383,382,'preferences',0,'/portlet_entity/89/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(384,185,'90',0,'/portlet_entity/90','2011-02-25 15:32:51','2011-02-25 15:32:51'),(385,384,'admin',0,'/portlet_entity/90/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(386,385,'preferences',0,'/portlet_entity/90/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(387,185,'91',0,'/portlet_entity/91','2011-02-25 15:32:51','2011-02-25 15:32:51'),(388,387,'admin',0,'/portlet_entity/91/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(389,388,'preferences',0,'/portlet_entity/91/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(390,185,'84',0,'/portlet_entity/84','2011-02-25 15:32:51','2011-02-25 15:32:51'),(391,390,'admin',0,'/portlet_entity/84/admin','2011-02-25 15:32:51','2011-02-25 15:32:51'),(392,391,'preferences',0,'/portlet_entity/84/admin/preferences','2011-02-25 15:32:51','2011-02-25 15:32:51'),(393,185,'19',0,'/portlet_entity/19','2011-02-25 15:33:21','2011-02-25 15:33:21'),(394,393,'mdek',0,'/portlet_entity/19/mdek','2011-02-25 15:33:21','2011-02-25 15:33:21'),(395,394,'preferences',0,'/portlet_entity/19/mdek/preferences','2011-02-25 15:33:21','2011-02-25 15:33:21'),(396,185,'20',0,'/portlet_entity/20','2011-02-25 15:33:21','2011-02-25 15:33:21'),(397,396,'mdek',0,'/portlet_entity/20/mdek','2011-02-25 15:33:21','2011-02-25 15:33:21'),(398,397,'preferences',0,'/portlet_entity/20/mdek/preferences','2011-02-25 15:33:21','2011-02-25 15:33:21'),(399,185,'21',0,'/portlet_entity/21','2011-02-25 15:33:21','2011-02-25 15:33:21'),(400,399,'mdek',0,'/portlet_entity/21/mdek','2011-02-25 15:33:21','2011-02-25 15:33:21'),(401,400,'preferences',0,'/portlet_entity/21/mdek/preferences','2011-02-25 15:33:21','2011-02-25 15:33:21'),(402,185,'18',0,'/portlet_entity/18','2011-02-25 15:33:21','2011-02-25 15:33:21'),(403,402,'mdek',0,'/portlet_entity/18/mdek','2011-02-25 15:33:21','2011-02-25 15:33:21'),(404,403,'preferences',0,'/portlet_entity/18/mdek/preferences','2011-02-25 15:33:21','2011-02-25 15:33:21'),(421,185,'342',0,'/portlet_entity/342','2011-02-25 16:37:56','2011-02-25 16:37:56'),(422,421,'mdek',0,'/portlet_entity/342/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(423,422,'preferences',0,'/portlet_entity/342/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(424,185,'343',0,'/portlet_entity/343','2011-02-25 16:37:56','2011-02-25 16:37:56'),(425,424,'mdek',0,'/portlet_entity/343/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(426,425,'preferences',0,'/portlet_entity/343/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(427,185,'344',0,'/portlet_entity/344','2011-02-25 16:37:56','2011-02-25 16:37:56'),(428,427,'mdek',0,'/portlet_entity/344/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(429,428,'preferences',0,'/portlet_entity/344/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(430,185,'345',0,'/portlet_entity/345','2011-02-25 16:37:56','2011-02-25 16:37:56'),(431,430,'mdek',0,'/portlet_entity/345/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(432,431,'preferences',0,'/portlet_entity/345/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(433,185,'346',0,'/portlet_entity/346','2011-02-25 16:37:56','2011-02-25 16:37:56'),(434,433,'mdek',0,'/portlet_entity/346/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(435,434,'preferences',0,'/portlet_entity/346/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(436,185,'347',0,'/portlet_entity/347','2011-02-25 16:37:56','2011-02-25 16:37:56'),(437,436,'mdek',0,'/portlet_entity/347/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(438,437,'preferences',0,'/portlet_entity/347/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(439,185,'348',0,'/portlet_entity/348','2011-02-25 16:37:56','2011-02-25 16:37:56'),(440,439,'mdek',0,'/portlet_entity/348/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(441,440,'preferences',0,'/portlet_entity/348/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(442,185,'341',0,'/portlet_entity/341','2011-02-25 16:37:56','2011-02-25 16:37:56'),(443,442,'mdek',0,'/portlet_entity/341/mdek','2011-02-25 16:37:56','2011-02-25 16:37:56'),(444,443,'preferences',0,'/portlet_entity/341/mdek/preferences','2011-02-25 16:37:56','2011-02-25 16:37:56'),(445,309,'mdek',0,'/portlet_entity/38/mdek','2011-02-25 16:43:12','2011-02-25 16:43:12'),(446,445,'preferences',0,'/portlet_entity/38/mdek/preferences','2011-02-25 16:43:12','2011-02-25 16:43:12'),(447,312,'mdek',0,'/portlet_entity/39/mdek','2011-02-25 16:43:12','2011-02-25 16:43:12'),(448,447,'preferences',0,'/portlet_entity/39/mdek/preferences','2011-02-25 16:43:12','2011-02-25 16:43:12'),(449,315,'mdek',0,'/portlet_entity/37/mdek','2011-02-25 16:43:12','2011-02-25 16:43:12'),(450,449,'preferences',0,'/portlet_entity/37/mdek/preferences','2011-02-25 16:43:12','2011-02-25 16:43:12'),(451,318,'mdek',0,'/portlet_entity/41/mdek','2011-02-25 16:43:12','2011-02-25 16:43:12'),(452,451,'preferences',0,'/portlet_entity/41/mdek/preferences','2011-02-25 16:43:12','2011-02-25 16:43:12'),(453,321,'mdek',0,'/portlet_entity/36/mdek','2011-02-25 16:43:12','2011-02-25 16:43:12'),(454,453,'preferences',0,'/portlet_entity/36/mdek/preferences','2011-02-25 16:43:12','2011-02-25 16:43:12'),(455,348,'mdek',0,'/portlet_entity/63/mdek','2011-02-25 16:43:16','2011-02-25 16:43:16'),(456,455,'preferences',0,'/portlet_entity/63/mdek/preferences','2011-02-25 16:43:16','2011-02-25 16:43:16'),(457,185,'128',0,'/portlet_entity/128','2011-02-25 16:43:34','2011-02-25 16:43:34'),(458,457,'admin',0,'/portlet_entity/128/admin','2011-02-25 16:43:34','2011-02-25 16:43:34'),(459,458,'preferences',0,'/portlet_entity/128/admin/preferences','2011-02-25 16:43:34','2011-02-25 16:43:34'),(481,301,'admin',0,'/portlet_entity/31/admin','2011-02-25 16:55:27','2011-02-25 16:55:27'),(482,481,'preferences',0,'/portlet_entity/31/admin/preferences','2011-02-25 16:55:27','2011-02-25 16:55:27'),(483,306,'admin',0,'/portlet_entity/30/admin','2011-02-25 16:55:27','2011-02-25 16:55:27'),(484,483,'preferences',0,'/portlet_entity/30/admin/preferences','2011-02-25 16:55:27','2011-02-25 16:55:27'),(2252,185,'53',0,'/portlet_entity/53','2011-07-13 17:11:04','2011-07-13 17:11:04'),(1641,185,'581',0,'/portlet_entity/581','2011-07-13 15:49:17','2011-07-13 15:49:17'),(489,185,'57',0,'/portlet_entity/57','2011-02-25 16:58:39','2011-02-25 16:58:39'),(490,489,'guest',0,'/portlet_entity/57/guest','2011-02-25 16:58:39','2011-02-25 16:58:39'),(491,490,'preferences',0,'/portlet_entity/57/guest/preferences','2011-02-25 16:58:39','2011-02-25 16:58:39'),(501,309,'admin',0,'/portlet_entity/38/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(502,501,'preferences',0,'/portlet_entity/38/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(503,312,'admin',0,'/portlet_entity/39/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(504,503,'preferences',0,'/portlet_entity/39/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(505,315,'admin',0,'/portlet_entity/37/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(506,505,'preferences',0,'/portlet_entity/37/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(507,318,'admin',0,'/portlet_entity/41/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(508,507,'preferences',0,'/portlet_entity/41/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(509,321,'admin',0,'/portlet_entity/36/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(510,509,'preferences',0,'/portlet_entity/36/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(511,348,'admin',0,'/portlet_entity/63/admin','2011-02-25 19:08:01','2011-02-25 19:08:01'),(512,511,'preferences',0,'/portlet_entity/63/admin/preferences','2011-02-25 19:08:01','2011-02-25 19:08:01'),(513,489,'admin',0,'/portlet_entity/57/admin','2011-02-25 19:08:06','2011-02-25 19:08:06'),(514,513,'preferences',0,'/portlet_entity/57/admin/preferences','2011-02-25 19:08:06','2011-02-25 19:08:06'),(569,9,'user2',0,'/user/user2','2011-03-01 18:04:23','2011-03-01 18:04:23'),(541,185,'200',0,'/portlet_entity/200','2011-03-01 13:41:51','2011-03-01 13:41:51'),(542,541,'guest',0,'/portlet_entity/200/guest','2011-03-01 13:41:51','2011-03-01 13:41:51'),(543,542,'preferences',0,'/portlet_entity/200/guest/preferences','2011-03-01 13:41:51','2011-03-01 13:41:51'),(570,569,'userinfo',0,'/user/user2/userinfo','2011-03-01 18:04:23','2011-03-01 18:04:23'),(567,9,'user1',0,'/user/user1','2011-03-01 18:03:56','2011-03-01 18:03:56'),(568,567,'userinfo',0,'/user/user1/userinfo','2011-03-01 18:03:56','2011-03-01 18:03:56'),(581,393,'admin',0,'/portlet_entity/19/admin','2011-03-08 07:11:04','2011-03-08 07:11:04'),(582,581,'preferences',0,'/portlet_entity/19/admin/preferences','2011-03-08 07:11:04','2011-03-08 07:11:04'),(583,396,'admin',0,'/portlet_entity/20/admin','2011-03-08 07:11:04','2011-03-08 07:11:04'),(584,583,'preferences',0,'/portlet_entity/20/admin/preferences','2011-03-08 07:11:04','2011-03-08 07:11:04'),(585,399,'admin',0,'/portlet_entity/21/admin','2011-03-08 07:11:04','2011-03-08 07:11:04'),(586,585,'preferences',0,'/portlet_entity/21/admin/preferences','2011-03-08 07:11:04','2011-03-08 07:11:04'),(587,402,'admin',0,'/portlet_entity/18/admin','2011-03-08 07:11:04','2011-03-08 07:11:04'),(588,587,'preferences',0,'/portlet_entity/18/admin/preferences','2011-03-08 07:11:04','2011-03-08 07:11:04'),(589,185,'402',0,'/portlet_entity/402','2011-03-08 07:49:23','2011-03-08 07:49:23'),(590,589,'mdek',0,'/portlet_entity/402/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(591,590,'preferences',0,'/portlet_entity/402/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(592,185,'403',0,'/portlet_entity/403','2011-03-08 07:49:23','2011-03-08 07:49:23'),(593,592,'mdek',0,'/portlet_entity/403/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(594,593,'preferences',0,'/portlet_entity/403/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(595,185,'404',0,'/portlet_entity/404','2011-03-08 07:49:23','2011-03-08 07:49:23'),(596,595,'mdek',0,'/portlet_entity/404/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(597,596,'preferences',0,'/portlet_entity/404/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(598,185,'405',0,'/portlet_entity/405','2011-03-08 07:49:23','2011-03-08 07:49:23'),(599,598,'mdek',0,'/portlet_entity/405/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(600,599,'preferences',0,'/portlet_entity/405/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(601,185,'406',0,'/portlet_entity/406','2011-03-08 07:49:23','2011-03-08 07:49:23'),(602,601,'mdek',0,'/portlet_entity/406/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(603,602,'preferences',0,'/portlet_entity/406/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(604,185,'407',0,'/portlet_entity/407','2011-03-08 07:49:23','2011-03-08 07:49:23'),(605,604,'mdek',0,'/portlet_entity/407/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(606,605,'preferences',0,'/portlet_entity/407/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(607,185,'408',0,'/portlet_entity/408','2011-03-08 07:49:23','2011-03-08 07:49:23'),(608,607,'mdek',0,'/portlet_entity/408/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(609,608,'preferences',0,'/portlet_entity/408/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(610,185,'401',0,'/portlet_entity/401','2011-03-08 07:49:23','2011-03-08 07:49:23'),(611,610,'mdek',0,'/portlet_entity/401/mdek','2011-03-08 07:49:23','2011-03-08 07:49:23'),(612,611,'preferences',0,'/portlet_entity/401/mdek/preferences','2011-03-08 07:49:23','2011-03-08 07:49:23'),(613,301,'mdek',0,'/portlet_entity/31/mdek','2011-03-08 08:10:30','2011-03-08 08:10:30'),(614,613,'preferences',0,'/portlet_entity/31/mdek/preferences','2011-03-08 08:10:30','2011-03-08 08:10:30'),(615,306,'mdek',0,'/portlet_entity/30/mdek','2011-03-08 08:10:30','2011-03-08 08:10:30'),(616,615,'preferences',0,'/portlet_entity/30/mdek/preferences','2011-03-08 08:10:30','2011-03-08 08:10:30'),(621,185,'14',0,'/portlet_entity/14','2011-03-09 11:38:26','2011-03-09 11:38:26'),(622,621,'mdek',0,'/portlet_entity/14/mdek','2011-03-09 11:38:26','2011-03-09 11:38:26'),(623,622,'preferences',0,'/portlet_entity/14/mdek/preferences','2011-03-09 11:38:26','2011-03-09 11:38:26'),(624,185,'94',0,'/portlet_entity/94','2011-03-09 11:54:04','2011-03-09 11:54:04'),(625,624,'mdek',0,'/portlet_entity/94/mdek','2011-03-09 11:54:04','2011-03-09 11:54:04'),(626,625,'preferences',0,'/portlet_entity/94/mdek/preferences','2011-03-09 11:54:04','2011-03-09 11:54:04'),(627,185,'95',0,'/portlet_entity/95','2011-03-09 11:54:04','2011-03-09 11:54:04'),(628,627,'mdek',0,'/portlet_entity/95/mdek','2011-03-09 11:54:04','2011-03-09 11:54:04'),(629,628,'preferences',0,'/portlet_entity/95/mdek/preferences','2011-03-09 11:54:04','2011-03-09 11:54:04'),(630,185,'96',0,'/portlet_entity/96','2011-03-09 11:54:04','2011-03-09 11:54:04'),(631,630,'mdek',0,'/portlet_entity/96/mdek','2011-03-09 11:54:04','2011-03-09 11:54:04'),(632,631,'preferences',0,'/portlet_entity/96/mdek/preferences','2011-03-09 11:54:04','2011-03-09 11:54:04'),(633,185,'92',0,'/portlet_entity/92','2011-03-09 11:54:04','2011-03-09 11:54:04'),(634,633,'mdek',0,'/portlet_entity/92/mdek','2011-03-09 11:54:04','2011-03-09 11:54:04'),(635,634,'preferences',0,'/portlet_entity/92/mdek/preferences','2011-03-09 11:54:04','2011-03-09 11:54:04'),(1939,1938,'guest',0,'/portlet_entity/668/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1940,1939,'preferences',0,'/portlet_entity/668/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(641,361,'mdek',0,'/portlet_entity/29/mdek','2011-03-09 14:52:38','2011-03-09 14:52:38'),(642,641,'preferences',0,'/portlet_entity/29/mdek/preferences','2011-03-09 14:52:38','2011-03-09 14:52:38'),(643,364,'mdek',0,'/portlet_entity/26/mdek','2011-03-09 14:52:38','2011-03-09 14:52:38'),(644,643,'preferences',0,'/portlet_entity/26/mdek/preferences','2011-03-09 14:52:38','2011-03-09 14:52:38'),(645,332,'mdek',0,'/portlet_entity/35/mdek','2011-03-09 14:53:05','2011-03-09 14:53:05'),(646,645,'preferences',0,'/portlet_entity/35/mdek/preferences','2011-03-09 14:53:05','2011-03-09 14:53:05'),(647,335,'mdek',0,'/portlet_entity/32/mdek','2011-03-09 14:53:05','2011-03-09 14:53:05'),(648,647,'preferences',0,'/portlet_entity/32/mdek/preferences','2011-03-09 14:53:05','2011-03-09 14:53:05'),(649,393,'guest',0,'/portlet_entity/19/guest','2011-03-10 17:54:35','2011-03-10 17:54:35'),(650,649,'preferences',0,'/portlet_entity/19/guest/preferences','2011-03-10 17:54:35','2011-03-10 17:54:35'),(651,396,'guest',0,'/portlet_entity/20/guest','2011-03-10 17:54:35','2011-03-10 17:54:35'),(652,651,'preferences',0,'/portlet_entity/20/guest/preferences','2011-03-10 17:54:35','2011-03-10 17:54:35'),(653,399,'guest',0,'/portlet_entity/21/guest','2011-03-10 17:54:35','2011-03-10 17:54:35'),(654,653,'preferences',0,'/portlet_entity/21/guest/preferences','2011-03-10 17:54:35','2011-03-10 17:54:35'),(655,402,'guest',0,'/portlet_entity/18/guest','2011-03-10 17:54:35','2011-03-10 17:54:35'),(656,655,'preferences',0,'/portlet_entity/18/guest/preferences','2011-03-10 17:54:35','2011-03-10 17:54:35'),(722,721,'guest',0,'/portlet_entity/240/guest','2011-04-01 12:45:07','2011-04-01 12:45:07'),(723,722,'preferences',0,'/portlet_entity/240/guest/preferences','2011-04-01 12:45:07','2011-04-01 12:45:07'),(724,185,'202',0,'/portlet_entity/202','2011-04-01 12:45:07','2011-04-01 12:45:07'),(725,724,'guest',0,'/portlet_entity/202/guest','2011-04-01 12:45:07','2011-04-01 12:45:07'),(726,725,'preferences',0,'/portlet_entity/202/guest/preferences','2011-04-01 12:45:07','2011-04-01 12:45:07'),(2249,185,'54',0,'/portlet_entity/54','2011-07-13 17:11:04','2011-07-13 17:11:04'),(2250,2249,'guest',0,'/portlet_entity/54/guest','2011-07-13 17:11:04','2011-07-13 17:11:04'),(741,621,'guest',0,'/portlet_entity/14/guest','2011-04-03 20:20:04','2011-04-03 20:20:04'),(742,741,'preferences',0,'/portlet_entity/14/guest/preferences','2011-04-03 20:20:04','2011-04-03 20:20:04'),(761,185,'home',0,'/portlet_entity/home','2011-04-08 09:04:10','2011-04-08 09:04:10'),(762,761,'guest',0,'/portlet_entity/home/guest','2011-04-08 09:04:10','2011-04-08 09:04:10'),(763,762,'preferences',0,'/portlet_entity/home/guest/preferences','2011-04-08 09:04:10','2011-04-08 09:04:10'),(764,185,'detect-js',0,'/portlet_entity/detect-js','2011-04-08 09:04:11','2011-04-08 09:04:11'),(765,764,'guest',0,'/portlet_entity/detect-js/guest','2011-04-08 09:04:11','2011-04-08 09:04:11'),(766,765,'preferences',0,'/portlet_entity/detect-js/guest/preferences','2011-04-08 09:04:11','2011-04-08 09:04:11'),(781,185,'search-simple-portlet',0,'/portlet_entity/search-simple-portlet','2011-04-08 09:07:20','2011-04-08 09:07:20'),(782,781,'guest',0,'/portlet_entity/search-simple-portlet/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(783,782,'preferences',0,'/portlet_entity/search-simple-portlet/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(784,185,'home-2',0,'/portlet_entity/home-2','2011-04-08 09:07:20','2011-04-08 09:07:20'),(785,784,'guest',0,'/portlet_entity/home-2/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(786,785,'preferences',0,'/portlet_entity/home-2/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(787,185,'home-3',0,'/portlet_entity/home-3','2011-04-08 09:07:20','2011-04-08 09:07:20'),(788,787,'guest',0,'/portlet_entity/home-3/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(789,788,'preferences',0,'/portlet_entity/home-3/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(790,185,'home-4',0,'/portlet_entity/home-4','2011-04-08 09:07:20','2011-04-08 09:07:20'),(791,790,'guest',0,'/portlet_entity/home-4/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(792,791,'preferences',0,'/portlet_entity/home-4/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(793,185,'home-5',0,'/portlet_entity/home-5','2011-04-08 09:07:20','2011-04-08 09:07:20'),(794,793,'guest',0,'/portlet_entity/home-5/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(795,794,'preferences',0,'/portlet_entity/home-5/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(796,185,'home-6',0,'/portlet_entity/home-6','2011-04-08 09:07:20','2011-04-08 09:07:20'),(797,796,'guest',0,'/portlet_entity/home-6/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(798,797,'preferences',0,'/portlet_entity/home-6/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(799,185,'home-7',0,'/portlet_entity/home-7','2011-04-08 09:07:20','2011-04-08 09:07:20'),(800,799,'guest',0,'/portlet_entity/home-7/guest','2011-04-08 09:07:20','2011-04-08 09:07:20'),(801,800,'preferences',0,'/portlet_entity/home-7/guest/preferences','2011-04-08 09:07:20','2011-04-08 09:07:20'),(802,185,'service-myportal-2',0,'/portlet_entity/service-myportal-2','2011-04-08 09:07:26','2011-04-08 09:07:26'),(803,802,'guest',0,'/portlet_entity/service-myportal-2/guest','2011-04-08 09:07:26','2011-04-08 09:07:26'),(804,803,'preferences',0,'/portlet_entity/service-myportal-2/guest/preferences','2011-04-08 09:07:26','2011-04-08 09:07:26'),(805,185,'service-myportal',0,'/portlet_entity/service-myportal','2011-04-08 09:07:26','2011-04-08 09:07:26'),(806,805,'guest',0,'/portlet_entity/service-myportal/guest','2011-04-08 09:07:26','2011-04-08 09:07:26'),(807,806,'preferences',0,'/portlet_entity/service-myportal/guest/preferences','2011-04-08 09:07:26','2011-04-08 09:07:26'),(808,185,'myportal-navigation',0,'/portlet_entity/myportal-navigation','2011-04-08 09:07:33','2011-04-08 09:07:33'),(809,808,'mdek',0,'/portlet_entity/myportal-navigation/mdek','2011-04-08 09:07:33','2011-04-08 09:07:33'),(810,809,'preferences',0,'/portlet_entity/myportal-navigation/mdek/preferences','2011-04-08 09:07:33','2011-04-08 09:07:33'),(811,805,'mdek',0,'/portlet_entity/service-myportal/mdek','2011-04-08 09:07:33','2011-04-08 09:07:33'),(812,811,'preferences',0,'/portlet_entity/service-myportal/mdek/preferences','2011-04-08 09:07:33','2011-04-08 09:07:33'),(813,764,'mdek',0,'/portlet_entity/detect-js/mdek','2011-04-08 09:07:34','2011-04-08 09:07:34'),(814,813,'preferences',0,'/portlet_entity/detect-js/mdek/preferences','2011-04-08 09:07:34','2011-04-08 09:07:34'),(815,185,'mdek-entry-0',0,'/portlet_entity/mdek-entry-0','2011-04-08 09:07:34','2011-04-08 09:07:34'),(816,815,'mdek',0,'/portlet_entity/mdek-entry-0/mdek','2011-04-08 09:07:34','2011-04-08 09:07:34'),(817,816,'preferences',0,'/portlet_entity/mdek-entry-0/mdek/preferences','2011-04-08 09:07:34','2011-04-08 09:07:34'),(818,185,'mdek-portal',0,'/portlet_entity/mdek-portal','2011-04-08 09:07:35','2011-04-08 09:07:35'),(819,818,'mdek',0,'/portlet_entity/mdek-portal/mdek','2011-04-08 09:07:35','2011-04-08 09:07:35'),(820,819,'preferences',0,'/portlet_entity/mdek-portal/mdek/preferences','2011-04-08 09:07:35','2011-04-08 09:07:35'),(821,781,'mdek',0,'/portlet_entity/search-simple-portlet/mdek','2011-04-08 09:07:38','2011-04-08 09:07:38'),(822,821,'preferences',0,'/portlet_entity/search-simple-portlet/mdek/preferences','2011-04-08 09:07:38','2011-04-08 09:07:38'),(823,185,'main-search-info',0,'/portlet_entity/main-search-info','2011-04-08 09:07:38','2011-04-08 09:07:38'),(824,823,'mdek',0,'/portlet_entity/main-search-info/mdek','2011-04-08 09:07:38','2011-04-08 09:07:38'),(825,824,'preferences',0,'/portlet_entity/main-search-info/mdek/preferences','2011-04-08 09:07:38','2011-04-08 09:07:38'),(826,185,'main-search-two-columns',0,'/portlet_entity/main-search-two-columns','2011-04-08 09:07:38','2011-04-08 09:07:38'),(827,826,'mdek',0,'/portlet_entity/main-search-two-columns/mdek','2011-04-08 09:07:38','2011-04-08 09:07:38'),(828,827,'preferences',0,'/portlet_entity/main-search-two-columns/mdek/preferences','2011-04-08 09:07:38','2011-04-08 09:07:38'),(829,185,'main-search-one-column',0,'/portlet_entity/main-search-one-column','2011-04-08 09:07:38','2011-04-08 09:07:38'),(830,829,'mdek',0,'/portlet_entity/main-search-one-column/mdek','2011-04-08 09:07:38','2011-04-08 09:07:38'),(831,830,'preferences',0,'/portlet_entity/main-search-one-column/mdek/preferences','2011-04-08 09:07:38','2011-04-08 09:07:38'),(832,185,'main-search',0,'/portlet_entity/main-search','2011-04-08 09:07:38','2011-04-08 09:07:38'),(833,832,'mdek',0,'/portlet_entity/main-search/mdek','2011-04-08 09:07:38','2011-04-08 09:07:38'),(834,833,'preferences',0,'/portlet_entity/main-search/mdek/preferences','2011-04-08 09:07:38','2011-04-08 09:07:38'),(835,784,'mdek',0,'/portlet_entity/home-2/mdek','2011-04-08 09:07:40','2011-04-08 09:07:40'),(836,835,'preferences',0,'/portlet_entity/home-2/mdek/preferences','2011-04-08 09:07:40','2011-04-08 09:07:40'),(837,787,'mdek',0,'/portlet_entity/home-3/mdek','2011-04-08 09:07:40','2011-04-08 09:07:40'),(838,837,'preferences',0,'/portlet_entity/home-3/mdek/preferences','2011-04-08 09:07:40','2011-04-08 09:07:40'),(839,790,'mdek',0,'/portlet_entity/home-4/mdek','2011-04-08 09:07:40','2011-04-08 09:07:40'),(840,839,'preferences',0,'/portlet_entity/home-4/mdek/preferences','2011-04-08 09:07:40','2011-04-08 09:07:40'),(841,793,'mdek',0,'/portlet_entity/home-5/mdek','2011-04-08 09:07:40','2011-04-08 09:07:40'),(842,841,'preferences',0,'/portlet_entity/home-5/mdek/preferences','2011-04-08 09:07:40','2011-04-08 09:07:40'),(843,796,'mdek',0,'/portlet_entity/home-6/mdek','2011-04-08 09:07:41','2011-04-08 09:07:41'),(844,843,'preferences',0,'/portlet_entity/home-6/mdek/preferences','2011-04-08 09:07:41','2011-04-08 09:07:41'),(845,799,'mdek',0,'/portlet_entity/home-7/mdek','2011-04-08 09:07:41','2011-04-08 09:07:41'),(846,845,'preferences',0,'/portlet_entity/home-7/mdek/preferences','2011-04-08 09:07:41','2011-04-08 09:07:41'),(847,761,'mdek',0,'/portlet_entity/home/mdek','2011-04-08 09:07:41','2011-04-08 09:07:41'),(848,847,'preferences',0,'/portlet_entity/home/mdek/preferences','2011-04-08 09:07:41','2011-04-08 09:07:41'),(849,185,'search-result-js',0,'/portlet_entity/search-result-js','2011-04-08 09:07:44','2011-04-08 09:07:44'),(850,849,'mdek',0,'/portlet_entity/search-result-js/mdek','2011-04-08 09:07:44','2011-04-08 09:07:44'),(851,850,'preferences',0,'/portlet_entity/search-result-js/mdek/preferences','2011-04-08 09:07:44','2011-04-08 09:07:44'),(852,185,'search-detail',0,'/portlet_entity/search-detail','2011-04-08 09:07:51','2011-04-08 09:07:51'),(853,852,'mdek',0,'/portlet_entity/search-detail/mdek','2011-04-08 09:07:51','2011-04-08 09:07:51'),(854,853,'preferences',0,'/portlet_entity/search-detail/mdek/preferences','2011-04-08 09:07:51','2011-04-08 09:07:51'),(861,340,'mdek',0,'/portlet_entity/25/mdek','2011-04-08 09:23:46','2011-04-08 09:23:46'),(862,861,'preferences',0,'/portlet_entity/25/mdek/preferences','2011-04-08 09:23:46','2011-04-08 09:23:46'),(863,343,'mdek',0,'/portlet_entity/22/mdek','2011-04-08 09:23:46','2011-04-08 09:23:46'),(864,863,'preferences',0,'/portlet_entity/22/mdek/preferences','2011-04-08 09:23:46','2011-04-08 09:23:46'),(865,324,'mdek',0,'/portlet_entity/46/mdek','2011-04-08 09:23:57','2011-04-08 09:23:57'),(866,865,'preferences',0,'/portlet_entity/46/mdek/preferences','2011-04-08 09:23:57','2011-04-08 09:23:57'),(867,327,'mdek',0,'/portlet_entity/43/mdek','2011-04-08 09:23:57','2011-04-08 09:23:57'),(868,867,'preferences',0,'/portlet_entity/43/mdek/preferences','2011-04-08 09:23:57','2011-04-08 09:23:57'),(869,721,'mdek',0,'/portlet_entity/240/mdek','2011-04-08 09:24:28','2011-04-08 09:24:28'),(870,869,'preferences',0,'/portlet_entity/240/mdek/preferences','2011-04-08 09:24:28','2011-04-08 09:24:28'),(871,724,'mdek',0,'/portlet_entity/202/mdek','2011-04-08 09:24:28','2011-04-08 09:24:28'),(872,871,'preferences',0,'/portlet_entity/202/mdek/preferences','2011-04-08 09:24:28','2011-04-08 09:24:28'),(881,185,'183',0,'/portlet_entity/183','2011-04-12 13:40:35','2011-04-12 13:40:35'),(882,881,'guest',0,'/portlet_entity/183/guest','2011-04-12 13:40:35','2011-04-12 13:40:35'),(883,882,'preferences',0,'/portlet_entity/183/guest/preferences','2011-04-12 13:40:35','2011-04-12 13:40:35'),(884,185,'185',0,'/portlet_entity/185','2011-04-12 13:40:35','2011-04-12 13:40:35'),(885,884,'guest',0,'/portlet_entity/185/guest','2011-04-12 13:40:35','2011-04-12 13:40:35'),(886,885,'preferences',0,'/portlet_entity/185/guest/preferences','2011-04-12 13:40:35','2011-04-12 13:40:35'),(887,185,'182',0,'/portlet_entity/182','2011-04-12 13:40:35','2011-04-12 13:40:35'),(888,887,'guest',0,'/portlet_entity/182/guest','2011-04-12 13:40:35','2011-04-12 13:40:35'),(889,888,'preferences',0,'/portlet_entity/182/guest/preferences','2011-04-12 13:40:35','2011-04-12 13:40:35'),(890,185,'158',0,'/portlet_entity/158','2011-04-12 13:40:38','2011-04-12 13:40:38'),(891,890,'guest',0,'/portlet_entity/158/guest','2011-04-12 13:40:38','2011-04-12 13:40:38'),(892,891,'preferences',0,'/portlet_entity/158/guest/preferences','2011-04-12 13:40:38','2011-04-12 13:40:38'),(893,185,'160',0,'/portlet_entity/160','2011-04-12 13:40:38','2011-04-12 13:40:38'),(894,893,'guest',0,'/portlet_entity/160/guest','2011-04-12 13:40:38','2011-04-12 13:40:38'),(895,894,'preferences',0,'/portlet_entity/160/guest/preferences','2011-04-12 13:40:38','2011-04-12 13:40:38'),(896,185,'157',0,'/portlet_entity/157','2011-04-12 13:40:38','2011-04-12 13:40:38'),(897,896,'guest',0,'/portlet_entity/157/guest','2011-04-12 13:40:38','2011-04-12 13:40:38'),(898,897,'preferences',0,'/portlet_entity/157/guest/preferences','2011-04-12 13:40:38','2011-04-12 13:40:38'),(899,185,'166',0,'/portlet_entity/166','2011-04-12 13:40:42','2011-04-12 13:40:42'),(900,899,'guest',0,'/portlet_entity/166/guest','2011-04-12 13:40:42','2011-04-12 13:40:42'),(901,900,'preferences',0,'/portlet_entity/166/guest/preferences','2011-04-12 13:40:42','2011-04-12 13:40:42'),(902,185,'168',0,'/portlet_entity/168','2011-04-12 13:40:42','2011-04-12 13:40:42'),(903,902,'guest',0,'/portlet_entity/168/guest','2011-04-12 13:40:42','2011-04-12 13:40:42'),(904,903,'preferences',0,'/portlet_entity/168/guest/preferences','2011-04-12 13:40:42','2011-04-12 13:40:42'),(905,185,'165',0,'/portlet_entity/165','2011-04-12 13:40:42','2011-04-12 13:40:42'),(906,905,'guest',0,'/portlet_entity/165/guest','2011-04-12 13:40:42','2011-04-12 13:40:42'),(907,906,'preferences',0,'/portlet_entity/165/guest/preferences','2011-04-12 13:40:42','2011-04-12 13:40:42'),(941,185,'170',0,'/portlet_entity/170','2011-04-18 09:39:28','2011-04-18 09:39:28'),(923,236,'ktt',0,'/portlet_entity/107/ktt','2011-04-15 10:45:09','2011-04-15 10:45:09'),(924,923,'preferences',0,'/portlet_entity/107/ktt/preferences','2011-04-15 10:45:09','2011-04-15 10:45:09'),(925,239,'ktt',0,'/portlet_entity/105/ktt','2011-04-15 10:45:09','2011-04-15 10:45:09'),(926,925,'preferences',0,'/portlet_entity/105/ktt/preferences','2011-04-15 10:45:09','2011-04-15 10:45:09'),(927,221,'ktt',0,'/portlet_entity/9/ktt','2011-04-15 10:45:09','2011-04-15 10:45:09'),(928,927,'preferences',0,'/portlet_entity/9/ktt/preferences','2011-04-15 10:45:09','2011-04-15 10:45:09'),(929,287,'ktt',0,'/portlet_entity/283/ktt','2011-04-15 10:45:11','2011-04-15 10:45:11'),(930,929,'preferences',0,'/portlet_entity/283/ktt/preferences','2011-04-15 10:45:11','2011-04-15 10:45:11'),(931,253,'ktt',0,'/portlet_entity/280/ktt','2011-04-15 10:45:11','2011-04-15 10:45:11'),(932,931,'preferences',0,'/portlet_entity/280/ktt/preferences','2011-04-15 10:45:11','2011-04-15 10:45:11'),(942,941,'guest',0,'/portlet_entity/170/guest','2011-04-18 09:39:28','2011-04-18 09:39:28'),(943,942,'preferences',0,'/portlet_entity/170/guest/preferences','2011-04-18 09:39:28','2011-04-18 09:39:28'),(944,185,'172',0,'/portlet_entity/172','2011-04-18 09:39:28','2011-04-18 09:39:28'),(945,944,'guest',0,'/portlet_entity/172/guest','2011-04-18 09:39:28','2011-04-18 09:39:28'),(946,945,'preferences',0,'/portlet_entity/172/guest/preferences','2011-04-18 09:39:28','2011-04-18 09:39:28'),(947,185,'169',0,'/portlet_entity/169','2011-04-18 09:39:28','2011-04-18 09:39:28'),(948,947,'guest',0,'/portlet_entity/169/guest','2011-04-18 09:39:28','2011-04-18 09:39:28'),(949,948,'preferences',0,'/portlet_entity/169/guest/preferences','2011-04-18 09:39:28','2011-04-18 09:39:28'),(950,185,'175',0,'/portlet_entity/175','2011-04-18 09:39:30','2011-04-18 09:39:30'),(951,950,'guest',0,'/portlet_entity/175/guest','2011-04-18 09:39:30','2011-04-18 09:39:30'),(952,951,'preferences',0,'/portlet_entity/175/guest/preferences','2011-04-18 09:39:30','2011-04-18 09:39:30'),(953,185,'174',0,'/portlet_entity/174','2011-04-18 09:39:30','2011-04-18 09:39:30'),(954,953,'guest',0,'/portlet_entity/174/guest','2011-04-18 09:39:30','2011-04-18 09:39:30'),(955,954,'preferences',0,'/portlet_entity/174/guest/preferences','2011-04-18 09:39:30','2011-04-18 09:39:30'),(956,185,'173',0,'/portlet_entity/173','2011-04-18 09:39:30','2011-04-18 09:39:30'),(957,956,'guest',0,'/portlet_entity/173/guest','2011-04-18 09:39:30','2011-04-18 09:39:30'),(958,957,'preferences',0,'/portlet_entity/173/guest/preferences','2011-04-18 09:39:30','2011-04-18 09:39:30'),(961,236,'user1',0,'/portlet_entity/107/user1','2011-04-19 14:07:27','2011-04-19 14:07:27'),(962,961,'preferences',0,'/portlet_entity/107/user1/preferences','2011-04-19 14:07:27','2011-04-19 14:07:27'),(963,239,'user1',0,'/portlet_entity/105/user1','2011-04-19 14:07:27','2011-04-19 14:07:27'),(964,963,'preferences',0,'/portlet_entity/105/user1/preferences','2011-04-19 14:07:27','2011-04-19 14:07:27'),(965,221,'user1',0,'/portlet_entity/9/user1','2011-04-19 14:07:27','2011-04-19 14:07:27'),(966,965,'preferences',0,'/portlet_entity/9/user1/preferences','2011-04-19 14:07:27','2011-04-19 14:07:27'),(967,287,'user1',0,'/portlet_entity/283/user1','2011-04-19 14:07:30','2011-04-19 14:07:30'),(968,967,'preferences',0,'/portlet_entity/283/user1/preferences','2011-04-19 14:07:30','2011-04-19 14:07:30'),(969,253,'user1',0,'/portlet_entity/280/user1','2011-04-19 14:07:30','2011-04-19 14:07:30'),(970,969,'preferences',0,'/portlet_entity/280/user1/preferences','2011-04-19 14:07:30','2011-04-19 14:07:30'),(971,393,'user1',0,'/portlet_entity/19/user1','2011-04-19 14:07:36','2011-04-19 14:07:36'),(972,971,'preferences',0,'/portlet_entity/19/user1/preferences','2011-04-19 14:07:36','2011-04-19 14:07:36'),(973,396,'user1',0,'/portlet_entity/20/user1','2011-04-19 14:07:36','2011-04-19 14:07:36'),(974,973,'preferences',0,'/portlet_entity/20/user1/preferences','2011-04-19 14:07:36','2011-04-19 14:07:36'),(975,399,'user1',0,'/portlet_entity/21/user1','2011-04-19 14:07:36','2011-04-19 14:07:36'),(976,975,'preferences',0,'/portlet_entity/21/user1/preferences','2011-04-19 14:07:36','2011-04-19 14:07:36'),(977,402,'user1',0,'/portlet_entity/18/user1','2011-04-19 14:07:36','2011-04-19 14:07:36'),(978,977,'preferences',0,'/portlet_entity/18/user1/preferences','2011-04-19 14:07:36','2011-04-19 14:07:36'),(981,541,'admin',0,'/portlet_entity/200/admin','2011-04-20 12:53:25','2011-04-20 12:53:25'),(982,981,'preferences',0,'/portlet_entity/200/admin/preferences','2011-04-20 12:53:25','2011-04-20 12:53:25'),(1001,185,'118',0,'/portlet_entity/118','2011-04-20 14:23:49','2011-04-20 14:23:49'),(1002,1001,'admin',0,'/portlet_entity/118/admin','2011-04-20 14:23:49','2011-04-20 14:23:49'),(1003,1002,'preferences',0,'/portlet_entity/118/admin/preferences','2011-04-20 14:23:49','2011-04-20 14:23:49'),(1933,1932,'guest',0,'/portlet_entity/666/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1934,1933,'preferences',0,'/portlet_entity/666/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1021,185,'83',0,'/portlet_entity/83','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1022,1021,'guest',0,'/portlet_entity/83/guest','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1023,1022,'preferences',0,'/portlet_entity/83/guest/preferences','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1024,185,'82',0,'/portlet_entity/82','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1025,1024,'guest',0,'/portlet_entity/82/guest','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1026,1025,'preferences',0,'/portlet_entity/82/guest/preferences','2011-04-20 14:59:11','2011-04-20 14:59:11'),(1041,185,'187',0,'/portlet_entity/187','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1042,1041,'guest',0,'/portlet_entity/187/guest','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1043,1042,'preferences',0,'/portlet_entity/187/guest/preferences','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1044,185,'189',0,'/portlet_entity/189','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1045,1044,'guest',0,'/portlet_entity/189/guest','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1046,1045,'preferences',0,'/portlet_entity/189/guest/preferences','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1047,185,'186',0,'/portlet_entity/186','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1048,1047,'guest',0,'/portlet_entity/186/guest','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1049,1048,'preferences',0,'/portlet_entity/186/guest/preferences','2011-04-27 08:34:49','2011-04-27 08:34:49'),(1050,185,'78',0,'/portlet_entity/78','2011-04-27 09:12:00','2011-04-27 09:12:00'),(1051,1050,'guest',0,'/portlet_entity/78/guest','2011-04-27 09:12:00','2011-04-27 09:12:00'),(1052,1051,'preferences',0,'/portlet_entity/78/guest/preferences','2011-04-27 09:12:00','2011-04-27 09:12:00'),(1053,185,'76',0,'/portlet_entity/76','2011-04-27 09:12:00','2011-04-27 09:12:00'),(1054,1053,'guest',0,'/portlet_entity/76/guest','2011-04-27 09:12:00','2011-04-27 09:12:00'),(1055,1054,'preferences',0,'/portlet_entity/76/guest/preferences','2011-04-27 09:12:00','2011-04-27 09:12:00'),(2253,2252,'guest',0,'/portlet_entity/53/guest','2011-07-13 17:11:04','2011-07-13 17:11:04'),(1061,185,'12',0,'/portlet_entity/12','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1062,1061,'guest',0,'/portlet_entity/12/guest','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1063,1062,'preferences',0,'/portlet_entity/12/guest/preferences','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1064,185,'13',0,'/portlet_entity/13','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1065,1064,'guest',0,'/portlet_entity/13/guest','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1066,1065,'preferences',0,'/portlet_entity/13/guest/preferences','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1067,185,'11',0,'/portlet_entity/11','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1068,1067,'guest',0,'/portlet_entity/11/guest','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1069,1068,'preferences',0,'/portlet_entity/11/guest/preferences','2011-04-27 10:24:43','2011-04-27 10:24:43'),(1070,185,'130',0,'/portlet_entity/130','2011-04-27 10:25:00','2011-04-27 10:25:00'),(1071,1070,'admin',0,'/portlet_entity/130/admin','2011-04-27 10:25:00','2011-04-27 10:25:00'),(1072,1071,'preferences',0,'/portlet_entity/130/admin/preferences','2011-04-27 10:25:00','2011-04-27 10:25:00'),(1653,185,'585',0,'/portlet_entity/585','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1654,1653,'guest',0,'/portlet_entity/585/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1655,1654,'preferences',0,'/portlet_entity/585/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1081,185,'461',0,'/portlet_entity/461','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1082,1081,'guest',0,'/portlet_entity/461/guest','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1083,1082,'preferences',0,'/portlet_entity/461/guest/preferences','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1084,185,'462',0,'/portlet_entity/462','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1085,1084,'guest',0,'/portlet_entity/462/guest','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1086,1085,'preferences',0,'/portlet_entity/462/guest/preferences','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1087,185,'463',0,'/portlet_entity/463','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1088,1087,'guest',0,'/portlet_entity/463/guest','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1089,1088,'preferences',0,'/portlet_entity/463/guest/preferences','2011-04-27 10:26:08','2011-04-27 10:26:08'),(1090,185,'464',0,'/portlet_entity/464','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1091,1090,'guest',0,'/portlet_entity/464/guest','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1092,1091,'preferences',0,'/portlet_entity/464/guest/preferences','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1093,185,'465',0,'/portlet_entity/465','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1094,1093,'guest',0,'/portlet_entity/465/guest','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1095,1094,'preferences',0,'/portlet_entity/465/guest/preferences','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1096,185,'466',0,'/portlet_entity/466','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1097,1096,'guest',0,'/portlet_entity/466/guest','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1098,1097,'preferences',0,'/portlet_entity/466/guest/preferences','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1099,185,'467',0,'/portlet_entity/467','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1100,1099,'guest',0,'/portlet_entity/467/guest','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1101,1100,'preferences',0,'/portlet_entity/467/guest/preferences','2011-04-27 10:26:09','2011-04-27 10:26:09'),(1102,185,'483',0,'/portlet_entity/483','2011-04-27 10:26:49','2011-04-27 10:26:49'),(1103,1102,'guest',0,'/portlet_entity/483/guest','2011-04-27 10:26:49','2011-04-27 10:26:49'),(1104,1103,'preferences',0,'/portlet_entity/483/guest/preferences','2011-04-27 10:26:49','2011-04-27 10:26:49'),(1121,185,'501',0,'/portlet_entity/501','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1122,1121,'guest',0,'/portlet_entity/501/guest','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1123,1122,'preferences',0,'/portlet_entity/501/guest/preferences','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1124,185,'502',0,'/portlet_entity/502','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1125,1124,'guest',0,'/portlet_entity/502/guest','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1126,1125,'preferences',0,'/portlet_entity/502/guest/preferences','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1127,185,'503',0,'/portlet_entity/503','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1128,1127,'guest',0,'/portlet_entity/503/guest','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1129,1128,'preferences',0,'/portlet_entity/503/guest/preferences','2011-04-27 10:32:28','2011-04-27 10:32:28'),(1130,185,'504',0,'/portlet_entity/504','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1131,1130,'guest',0,'/portlet_entity/504/guest','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1132,1131,'preferences',0,'/portlet_entity/504/guest/preferences','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1133,185,'505',0,'/portlet_entity/505','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1134,1133,'guest',0,'/portlet_entity/505/guest','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1135,1134,'preferences',0,'/portlet_entity/505/guest/preferences','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1136,185,'506',0,'/portlet_entity/506','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1137,1136,'guest',0,'/portlet_entity/506/guest','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1138,1137,'preferences',0,'/portlet_entity/506/guest/preferences','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1139,185,'507',0,'/portlet_entity/507','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1140,1139,'guest',0,'/portlet_entity/507/guest','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1141,1140,'preferences',0,'/portlet_entity/507/guest/preferences','2011-04-27 10:32:29','2011-04-27 10:32:29'),(1142,185,'523',0,'/portlet_entity/523','2011-04-27 10:32:47','2011-04-27 10:32:47'),(1143,1142,'guest',0,'/portlet_entity/523/guest','2011-04-27 10:32:47','2011-04-27 10:32:47'),(1144,1143,'preferences',0,'/portlet_entity/523/guest/preferences','2011-04-27 10:32:47','2011-04-27 10:32:47'),(1161,185,'541',0,'/portlet_entity/541','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1162,1161,'guest',0,'/portlet_entity/541/guest','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1163,1162,'preferences',0,'/portlet_entity/541/guest/preferences','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1164,185,'542',0,'/portlet_entity/542','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1165,1164,'guest',0,'/portlet_entity/542/guest','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1166,1165,'preferences',0,'/portlet_entity/542/guest/preferences','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1167,185,'543',0,'/portlet_entity/543','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1168,1167,'guest',0,'/portlet_entity/543/guest','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1169,1168,'preferences',0,'/portlet_entity/543/guest/preferences','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1170,185,'544',0,'/portlet_entity/544','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1171,1170,'guest',0,'/portlet_entity/544/guest','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1172,1171,'preferences',0,'/portlet_entity/544/guest/preferences','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1173,185,'545',0,'/portlet_entity/545','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1174,1173,'guest',0,'/portlet_entity/545/guest','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1175,1174,'preferences',0,'/portlet_entity/545/guest/preferences','2011-04-27 10:42:46','2011-04-27 10:42:46'),(1176,185,'546',0,'/portlet_entity/546','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1177,1176,'guest',0,'/portlet_entity/546/guest','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1178,1177,'preferences',0,'/portlet_entity/546/guest/preferences','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1179,185,'547',0,'/portlet_entity/547','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1180,1179,'guest',0,'/portlet_entity/547/guest','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1181,1180,'preferences',0,'/portlet_entity/547/guest/preferences','2011-04-27 10:42:47','2011-04-27 10:42:47'),(1201,185,'162',0,'/portlet_entity/162','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1202,1201,'guest',0,'/portlet_entity/162/guest','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1203,1202,'preferences',0,'/portlet_entity/162/guest/preferences','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1204,185,'164',0,'/portlet_entity/164','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1205,1204,'guest',0,'/portlet_entity/164/guest','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1206,1205,'preferences',0,'/portlet_entity/164/guest/preferences','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1207,185,'161',0,'/portlet_entity/161','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1208,1207,'guest',0,'/portlet_entity/161/guest','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1209,1208,'preferences',0,'/portlet_entity/161/guest/preferences','2011-04-28 09:28:34','2011-04-28 09:28:34'),(1210,185,'191',0,'/portlet_entity/191','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1211,1210,'guest',0,'/portlet_entity/191/guest','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1212,1211,'preferences',0,'/portlet_entity/191/guest/preferences','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1213,185,'193',0,'/portlet_entity/193','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1214,1213,'guest',0,'/portlet_entity/193/guest','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1215,1214,'preferences',0,'/portlet_entity/193/guest/preferences','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1216,185,'190',0,'/portlet_entity/190','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1217,1216,'guest',0,'/portlet_entity/190/guest','2011-04-28 09:28:50','2011-04-28 09:28:50'),(1218,1217,'preferences',0,'/portlet_entity/190/guest/preferences','2011-04-28 09:28:50','2011-04-28 09:28:50'),(4611,4610,'preferences',0,'/portlet_entity/186/mdek/preferences','2011-11-23 08:19:21','2011-11-23 08:19:21'),(4612,941,'mdek',0,'/portlet_entity/170/mdek','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4613,4612,'preferences',0,'/portlet_entity/170/mdek/preferences','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4614,944,'mdek',0,'/portlet_entity/172/mdek','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4615,4614,'preferences',0,'/portlet_entity/172/mdek/preferences','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4616,947,'mdek',0,'/portlet_entity/169/mdek','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4617,4616,'preferences',0,'/portlet_entity/169/mdek/preferences','2011-11-23 08:19:25','2011-11-23 08:19:25'),(4618,950,'mdek',0,'/portlet_entity/175/mdek','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4619,4618,'preferences',0,'/portlet_entity/175/mdek/preferences','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4620,953,'mdek',0,'/portlet_entity/174/mdek','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4621,4620,'preferences',0,'/portlet_entity/174/mdek/preferences','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4622,956,'mdek',0,'/portlet_entity/173/mdek','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4623,4622,'preferences',0,'/portlet_entity/173/mdek/preferences','2011-11-23 08:19:26','2011-11-23 08:19:26'),(4853,4852,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurus/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4854,4853,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurus/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4855,4854,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurus/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4856,4854,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurus/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4770,4768,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4771,4758,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(1414,185,'563',0,'/portlet_entity/563','2011-07-13 15:36:46','2011-07-13 15:36:46'),(1415,1414,'guest',0,'/portlet_entity/563/guest','2011-07-13 15:36:46','2011-07-13 15:36:46'),(1416,1415,'preferences',0,'/portlet_entity/563/guest/preferences','2011-07-13 15:36:46','2011-07-13 15:36:46'),(1659,185,'587',0,'/portlet_entity/587','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1660,1659,'guest',0,'/portlet_entity/587/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1647,185,'583',0,'/portlet_entity/583','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1648,1647,'guest',0,'/portlet_entity/583/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1649,1648,'preferences',0,'/portlet_entity/583/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1650,185,'584',0,'/portlet_entity/584','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1651,1650,'guest',0,'/portlet_entity/584/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1652,1651,'preferences',0,'/portlet_entity/584/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1937,1936,'preferences',0,'/portlet_entity/667/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1938,185,'668',0,'/portlet_entity/668','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1936,1935,'guest',0,'/portlet_entity/667/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1922,1921,'preferences',0,'/portlet_entity/662/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1923,185,'663',0,'/portlet_entity/663','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1924,1923,'guest',0,'/portlet_entity/663/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1925,1924,'preferences',0,'/portlet_entity/663/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1926,185,'664',0,'/portlet_entity/664','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1927,1926,'guest',0,'/portlet_entity/664/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1917,185,'661',0,'/portlet_entity/661','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1918,1917,'guest',0,'/portlet_entity/661/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1919,1918,'preferences',0,'/portlet_entity/661/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1920,185,'662',0,'/portlet_entity/662','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1921,1920,'guest',0,'/portlet_entity/662/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1661,1660,'preferences',0,'/portlet_entity/587/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1662,185,'588',0,'/portlet_entity/588','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1663,1662,'guest',0,'/portlet_entity/588/guest','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1664,1663,'preferences',0,'/portlet_entity/588/guest/preferences','2011-07-13 15:49:18','2011-07-13 15:49:18'),(1930,1929,'guest',0,'/portlet_entity/665/guest','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1931,1930,'preferences',0,'/portlet_entity/665/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1932,185,'666',0,'/portlet_entity/666','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1928,1927,'preferences',0,'/portlet_entity/664/guest/preferences','2011-07-13 16:08:36','2011-07-13 16:08:36'),(1929,185,'665',0,'/portlet_entity/665','2011-07-13 16:08:36','2011-07-13 16:08:36'),(4523,4512,'MdekAdminLoginPortlet',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekAdminLoginPortlet','2011-09-26 12:12:53','2011-09-26 12:12:53'),(4781,4779,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4782,4778,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4783,4782,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4784,4782,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4785,4778,'infoTemplate',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/infoTemplate','2012-09-20 15:20:07','2012-09-20 15:20:07'),(1689,185,'621',0,'/portlet_entity/621','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1690,1689,'guest',0,'/portlet_entity/621/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1691,1690,'preferences',0,'/portlet_entity/621/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1692,185,'622',0,'/portlet_entity/622','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1693,1692,'guest',0,'/portlet_entity/622/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1694,1693,'preferences',0,'/portlet_entity/622/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1695,185,'623',0,'/portlet_entity/623','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1696,1695,'guest',0,'/portlet_entity/623/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1697,1696,'preferences',0,'/portlet_entity/623/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1698,185,'624',0,'/portlet_entity/624','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1699,1698,'guest',0,'/portlet_entity/624/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1700,1699,'preferences',0,'/portlet_entity/624/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1701,185,'625',0,'/portlet_entity/625','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1702,1701,'guest',0,'/portlet_entity/625/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1703,1702,'preferences',0,'/portlet_entity/625/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1704,185,'626',0,'/portlet_entity/626','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1705,1704,'guest',0,'/portlet_entity/626/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1706,1705,'preferences',0,'/portlet_entity/626/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1707,185,'627',0,'/portlet_entity/627','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1708,1707,'guest',0,'/portlet_entity/627/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1709,1708,'preferences',0,'/portlet_entity/627/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1710,185,'628',0,'/portlet_entity/628','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1711,1710,'guest',0,'/portlet_entity/628/guest','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1712,1711,'preferences',0,'/portlet_entity/628/guest/preferences','2011-07-13 16:00:04','2011-07-13 16:00:04'),(1961,185,'701',0,'/portlet_entity/701','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1962,1961,'guest',0,'/portlet_entity/701/guest','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1963,1962,'preferences',0,'/portlet_entity/701/guest/preferences','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1964,185,'702',0,'/portlet_entity/702','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1965,1964,'guest',0,'/portlet_entity/702/guest','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1966,1965,'preferences',0,'/portlet_entity/702/guest/preferences','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1967,185,'703',0,'/portlet_entity/703','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1968,1967,'guest',0,'/portlet_entity/703/guest','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1969,1968,'preferences',0,'/portlet_entity/703/guest/preferences','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1970,185,'704',0,'/portlet_entity/704','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1971,1970,'guest',0,'/portlet_entity/704/guest','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1972,1971,'preferences',0,'/portlet_entity/704/guest/preferences','2011-07-13 16:20:04','2011-07-13 16:20:04'),(1973,185,'705',0,'/portlet_entity/705','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1974,1973,'guest',0,'/portlet_entity/705/guest','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1975,1974,'preferences',0,'/portlet_entity/705/guest/preferences','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1976,185,'706',0,'/portlet_entity/706','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1977,1976,'guest',0,'/portlet_entity/706/guest','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1978,1977,'preferences',0,'/portlet_entity/706/guest/preferences','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1979,185,'707',0,'/portlet_entity/707','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1980,1979,'guest',0,'/portlet_entity/707/guest','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1981,1980,'preferences',0,'/portlet_entity/707/guest/preferences','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1982,185,'708',0,'/portlet_entity/708','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1983,1982,'guest',0,'/portlet_entity/708/guest','2011-07-13 16:20:05','2011-07-13 16:20:05'),(1984,1983,'preferences',0,'/portlet_entity/708/guest/preferences','2011-07-13 16:20:05','2011-07-13 16:20:05'),(2001,185,'741',0,'/portlet_entity/741','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2002,2001,'guest',0,'/portlet_entity/741/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2003,2002,'preferences',0,'/portlet_entity/741/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2004,185,'742',0,'/portlet_entity/742','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2005,2004,'guest',0,'/portlet_entity/742/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2006,2005,'preferences',0,'/portlet_entity/742/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2007,185,'743',0,'/portlet_entity/743','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2008,2007,'guest',0,'/portlet_entity/743/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2009,2008,'preferences',0,'/portlet_entity/743/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2010,185,'744',0,'/portlet_entity/744','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2011,2010,'guest',0,'/portlet_entity/744/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2012,2011,'preferences',0,'/portlet_entity/744/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2013,185,'745',0,'/portlet_entity/745','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2014,2013,'guest',0,'/portlet_entity/745/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2015,2014,'preferences',0,'/portlet_entity/745/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2016,185,'746',0,'/portlet_entity/746','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2017,2016,'guest',0,'/portlet_entity/746/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2018,2017,'preferences',0,'/portlet_entity/746/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2019,185,'747',0,'/portlet_entity/747','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2020,2019,'guest',0,'/portlet_entity/747/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2021,2020,'preferences',0,'/portlet_entity/747/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2022,185,'748',0,'/portlet_entity/748','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2023,2022,'guest',0,'/portlet_entity/748/guest','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2024,2023,'preferences',0,'/portlet_entity/748/guest/preferences','2011-07-13 16:27:22','2011-07-13 16:27:22'),(2265,185,'122',0,'/portlet_entity/122','2011-07-13 17:23:50','2011-07-13 17:23:50'),(2266,2265,'admin',0,'/portlet_entity/122/admin','2011-07-13 17:23:50','2011-07-13 17:23:50'),(2267,2266,'preferences',0,'/portlet_entity/122/admin/preferences','2011-07-13 17:23:50','2011-07-13 17:23:50'),(4794,4682,'ServiceTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2270,340,'admin',0,'/portlet_entity/25/admin','2011-07-13 17:24:05','2011-07-13 17:24:05'),(2271,2270,'preferences',0,'/portlet_entity/25/admin/preferences','2011-07-13 17:24:05','2011-07-13 17:24:05'),(2272,343,'admin',0,'/portlet_entity/22/admin','2011-07-13 17:24:05','2011-07-13 17:24:05'),(2273,2272,'preferences',0,'/portlet_entity/22/admin/preferences','2011-07-13 17:24:05','2011-07-13 17:24:05'),(2281,185,'801',0,'/portlet_entity/801','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2282,2281,'guest',0,'/portlet_entity/801/guest','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2283,2282,'preferences',0,'/portlet_entity/801/guest/preferences','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2286,185,'800',0,'/portlet_entity/800','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2287,2286,'guest',0,'/portlet_entity/800/guest','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2288,2287,'preferences',0,'/portlet_entity/800/guest/preferences','2011-08-02 16:59:35','2011-08-02 16:59:35'),(2291,185,'74',0,'/portlet_entity/74','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2292,2291,'guest',0,'/portlet_entity/74/guest','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2293,2292,'preferences',0,'/portlet_entity/74/guest/preferences','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2294,185,'75',0,'/portlet_entity/75','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2295,2294,'guest',0,'/portlet_entity/75/guest','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2296,2295,'preferences',0,'/portlet_entity/75/guest/preferences','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2297,185,'72',0,'/portlet_entity/72','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2298,2297,'guest',0,'/portlet_entity/72/guest','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2299,2298,'preferences',0,'/portlet_entity/72/guest/preferences','2011-08-03 06:39:46','2011-08-03 06:39:46'),(2302,185,'764',0,'/portlet_entity/764','2011-08-03 06:45:28','2011-08-03 06:45:28'),(2303,2302,'guest',0,'/portlet_entity/764/guest','2011-08-03 06:45:28','2011-08-03 06:45:28'),(2304,2303,'preferences',0,'/portlet_entity/764/guest/preferences','2011-08-03 06:45:28','2011-08-03 06:45:28'),(2307,185,'195',0,'/portlet_entity/195','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2308,2307,'guest',0,'/portlet_entity/195/guest','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2309,2308,'preferences',0,'/portlet_entity/195/guest/preferences','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2310,185,'197',0,'/portlet_entity/197','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2311,2310,'guest',0,'/portlet_entity/197/guest','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2312,2311,'preferences',0,'/portlet_entity/197/guest/preferences','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2313,185,'194',0,'/portlet_entity/194','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2314,2313,'guest',0,'/portlet_entity/194/guest','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2315,2314,'preferences',0,'/portlet_entity/194/guest/preferences','2011-08-03 07:26:14','2011-08-03 07:26:14'),(2316,185,'178',0,'/portlet_entity/178','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2317,2316,'guest',0,'/portlet_entity/178/guest','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2318,2317,'preferences',0,'/portlet_entity/178/guest/preferences','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2319,185,'181',0,'/portlet_entity/181','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2320,2319,'guest',0,'/portlet_entity/181/guest','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2321,2320,'preferences',0,'/portlet_entity/181/guest/preferences','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2322,185,'177',0,'/portlet_entity/177','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2323,2322,'guest',0,'/portlet_entity/177/guest','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2324,2323,'preferences',0,'/portlet_entity/177/guest/preferences','2011-08-03 07:26:49','2011-08-03 07:26:49'),(2325,185,'261',0,'/portlet_entity/261','2011-08-03 07:27:30','2011-08-03 07:27:30'),(2326,2325,'guest',0,'/portlet_entity/261/guest','2011-08-03 07:27:30','2011-08-03 07:27:30'),(2327,2326,'preferences',0,'/portlet_entity/261/guest/preferences','2011-08-03 07:27:30','2011-08-03 07:27:30'),(2328,185,'263',0,'/portlet_entity/263','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2329,2328,'guest',0,'/portlet_entity/263/guest','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2330,2329,'preferences',0,'/portlet_entity/263/guest/preferences','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2331,185,'260',0,'/portlet_entity/260','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2332,2331,'guest',0,'/portlet_entity/260/guest','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2333,2332,'preferences',0,'/portlet_entity/260/guest/preferences','2011-08-03 07:27:31','2011-08-03 07:27:31'),(2334,185,'269',0,'/portlet_entity/269','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2335,2334,'guest',0,'/portlet_entity/269/guest','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2336,2335,'preferences',0,'/portlet_entity/269/guest/preferences','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2337,185,'271',0,'/portlet_entity/271','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2338,2337,'guest',0,'/portlet_entity/271/guest','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2339,2338,'preferences',0,'/portlet_entity/271/guest/preferences','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2340,185,'268',0,'/portlet_entity/268','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2341,2340,'guest',0,'/portlet_entity/268/guest','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2342,2341,'preferences',0,'/portlet_entity/268/guest/preferences','2011-08-03 07:27:35','2011-08-03 07:27:35'),(2343,185,'154',0,'/portlet_entity/154','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2344,2343,'guest',0,'/portlet_entity/154/guest','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2345,2344,'preferences',0,'/portlet_entity/154/guest/preferences','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2346,185,'156',0,'/portlet_entity/156','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2347,2346,'guest',0,'/portlet_entity/156/guest','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2348,2347,'preferences',0,'/portlet_entity/156/guest/preferences','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2349,185,'153',0,'/portlet_entity/153','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2350,2349,'guest',0,'/portlet_entity/153/guest','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2351,2350,'preferences',0,'/portlet_entity/153/guest/preferences','2011-08-03 07:27:45','2011-08-03 07:27:45'),(2352,185,'146',0,'/portlet_entity/146','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2353,2352,'guest',0,'/portlet_entity/146/guest','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2354,2353,'preferences',0,'/portlet_entity/146/guest/preferences','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2355,185,'148',0,'/portlet_entity/148','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2356,2355,'guest',0,'/portlet_entity/148/guest','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2357,2356,'preferences',0,'/portlet_entity/148/guest/preferences','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2358,185,'145',0,'/portlet_entity/145','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2359,2358,'guest',0,'/portlet_entity/145/guest','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2360,2359,'preferences',0,'/portlet_entity/145/guest/preferences','2011-08-03 07:27:47','2011-08-03 07:27:47'),(2361,185,'142',0,'/portlet_entity/142','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2362,2361,'guest',0,'/portlet_entity/142/guest','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2363,2362,'preferences',0,'/portlet_entity/142/guest/preferences','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2364,185,'144',0,'/portlet_entity/144','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2365,2364,'guest',0,'/portlet_entity/144/guest','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2366,2365,'preferences',0,'/portlet_entity/144/guest/preferences','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2367,185,'141',0,'/portlet_entity/141','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2368,2367,'guest',0,'/portlet_entity/141/guest','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2369,2368,'preferences',0,'/portlet_entity/141/guest/preferences','2011-08-03 07:27:50','2011-08-03 07:27:50'),(2370,185,'60',0,'/portlet_entity/60','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2371,2370,'guest',0,'/portlet_entity/60/guest','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2372,2371,'preferences',0,'/portlet_entity/60/guest/preferences','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2373,185,'62',0,'/portlet_entity/62','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2374,2373,'guest',0,'/portlet_entity/62/guest','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2375,2374,'preferences',0,'/portlet_entity/62/guest/preferences','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2376,185,'59',0,'/portlet_entity/59','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2377,2376,'guest',0,'/portlet_entity/59/guest','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2378,2377,'preferences',0,'/portlet_entity/59/guest/preferences','2011-08-03 07:27:55','2011-08-03 07:27:55'),(2379,185,'69',0,'/portlet_entity/69','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2380,2379,'guest',0,'/portlet_entity/69/guest','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2381,2380,'preferences',0,'/portlet_entity/69/guest/preferences','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2382,185,'71',0,'/portlet_entity/71','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2383,2382,'guest',0,'/portlet_entity/71/guest','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2384,2383,'preferences',0,'/portlet_entity/71/guest/preferences','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2385,185,'68',0,'/portlet_entity/68','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2386,2385,'guest',0,'/portlet_entity/68/guest','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2387,2386,'preferences',0,'/portlet_entity/68/guest/preferences','2011-08-03 07:27:57','2011-08-03 07:27:57'),(2388,185,'16',0,'/portlet_entity/16','2011-08-03 08:29:06','2011-08-03 08:29:06'),(2389,2388,'guest',0,'/portlet_entity/16/guest','2011-08-03 08:29:06','2011-08-03 08:29:06'),(2390,2389,'preferences',0,'/portlet_entity/16/guest/preferences','2011-08-03 08:29:06','2011-08-03 08:29:06'),(4583,4582,'preferences',0,'/portlet_entity/187/admin/preferences','2011-11-23 08:18:00','2011-11-23 08:18:00'),(4584,1044,'admin',0,'/portlet_entity/189/admin','2011-11-23 08:18:00','2011-11-23 08:18:00'),(4585,4584,'preferences',0,'/portlet_entity/189/admin/preferences','2011-11-23 08:18:00','2011-11-23 08:18:00'),(4586,1047,'admin',0,'/portlet_entity/186/admin','2011-11-23 08:18:00','2011-11-23 08:18:00'),(4587,4586,'preferences',0,'/portlet_entity/186/admin/preferences','2011-11-23 08:18:00','2011-11-23 08:18:00'),(4588,941,'admin',0,'/portlet_entity/170/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4589,4588,'preferences',0,'/portlet_entity/170/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4590,944,'admin',0,'/portlet_entity/172/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4591,4590,'preferences',0,'/portlet_entity/172/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4592,947,'admin',0,'/portlet_entity/169/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4593,4592,'preferences',0,'/portlet_entity/169/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4594,950,'admin',0,'/portlet_entity/175/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4595,4594,'preferences',0,'/portlet_entity/175/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4596,953,'admin',0,'/portlet_entity/174/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4597,4596,'preferences',0,'/portlet_entity/174/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4598,956,'admin',0,'/portlet_entity/173/admin','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4599,4598,'preferences',0,'/portlet_entity/173/admin/preferences','2011-11-23 08:18:07','2011-11-23 08:18:07'),(4600,881,'mdek',0,'/portlet_entity/183/mdek','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4601,4600,'preferences',0,'/portlet_entity/183/mdek/preferences','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4602,884,'mdek',0,'/portlet_entity/185/mdek','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4603,4602,'preferences',0,'/portlet_entity/185/mdek/preferences','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4604,887,'mdek',0,'/portlet_entity/182/mdek','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4605,4604,'preferences',0,'/portlet_entity/182/mdek/preferences','2011-11-23 08:19:19','2011-11-23 08:19:19'),(4606,1041,'mdek',0,'/portlet_entity/187/mdek','2011-11-23 08:19:21','2011-11-23 08:19:21'),(4607,4606,'preferences',0,'/portlet_entity/187/mdek/preferences','2011-11-23 08:19:21','2011-11-23 08:19:21'),(4608,1044,'mdek',0,'/portlet_entity/189/mdek','2011-11-23 08:19:21','2011-11-23 08:19:21'),(4609,4608,'preferences',0,'/portlet_entity/189/mdek/preferences','2011-11-23 08:19:21','2011-11-23 08:19:21'),(4610,1047,'mdek',0,'/portlet_entity/186/mdek','2011-11-23 08:19:21','2011-11-23 08:19:21'),(2641,185,'150',0,'/portlet_entity/150','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2642,2641,'guest',0,'/portlet_entity/150/guest','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2643,2642,'preferences',0,'/portlet_entity/150/guest/preferences','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2644,185,'152',0,'/portlet_entity/152','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2645,2644,'guest',0,'/portlet_entity/152/guest','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2646,2645,'preferences',0,'/portlet_entity/152/guest/preferences','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2647,185,'149',0,'/portlet_entity/149','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2648,2647,'guest',0,'/portlet_entity/149/guest','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2649,2648,'preferences',0,'/portlet_entity/149/guest/preferences','2011-08-21 20:08:28','2011-08-21 20:08:28'),(2650,185,'52',0,'/portlet_entity/52','2011-08-21 21:19:30','2011-08-21 21:19:30'),(2651,2650,'guest',0,'/portlet_entity/52/guest','2011-08-21 21:19:30','2011-08-21 21:19:30'),(2652,2651,'preferences',0,'/portlet_entity/52/guest/preferences','2011-08-21 21:19:30','2011-08-21 21:19:30'),(2653,185,'50',0,'/portlet_entity/50','2011-08-21 21:19:30','2011-08-21 21:19:30'),(2654,2653,'guest',0,'/portlet_entity/50/guest','2011-08-21 21:19:30','2011-08-21 21:19:30'),(2655,2654,'preferences',0,'/portlet_entity/50/guest/preferences','2011-08-21 21:19:30','2011-08-21 21:19:30'),(4860,4859,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalLoginPortlet/preferences','2012-09-20 15:20:18','2012-09-20 15:20:18'),(4861,4682,'MyPortalOverviewPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalOverviewPortlet','2012-09-20 15:20:19','2012-09-20 15:20:19'),(4765,4758,'infoTemplate',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/infoTemplate','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4766,4765,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/infoTemplate/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4511,21,'ingrid-portal-mdek',1,'/portlet_application/ingrid-portal-mdek','2011-09-16 14:14:03','2011-09-16 14:14:03'),(4512,4511,'portlets',1,'/portlet_application/ingrid-portal-mdek/portlets','2011-09-16 14:14:03','2011-09-16 14:14:03'),(4513,4512,'MdekEntryPortlet',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekEntryPortlet','2011-09-16 14:14:03','2011-09-16 14:14:03'),(4514,4513,'preferences',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekEntryPortlet/preferences','2011-09-16 14:14:03','2011-09-16 14:14:03'),(4521,4512,'MdekPortalAdminPortlet',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekPortalAdminPortlet','2011-09-26 12:12:53','2011-09-26 12:12:53'),(4522,4521,'preferences',1,'/portlet_application/ingrid-portal-mdek/portlets/MdekPortalAdminPortlet/preferences','2011-09-26 12:12:53','2011-09-26 12:12:53'),(4641,21,'jetspeed-layouts',1,'/portlet_application/jetspeed-layouts','2011-11-25 14:03:51','2011-11-25 14:03:51'),(4642,4641,'portlets',1,'/portlet_application/jetspeed-layouts/portlets','2011-11-25 14:03:51','2011-11-25 14:03:51'),(4643,4642,'IngridTwoColumns',1,'/portlet_application/jetspeed-layouts/portlets/IngridTwoColumns','2011-11-25 14:03:51','2011-11-25 14:03:51'),(4644,4643,'preferences',1,'/portlet_application/jetspeed-layouts/portlets/IngridTwoColumns/preferences','2011-11-25 14:03:51','2011-11-25 14:03:51'),(4645,4642,'IngridClearLayout',1,'/portlet_application/jetspeed-layouts/portlets/IngridClearLayout','2011-11-25 14:03:52','2011-11-25 14:03:52'),(4646,4645,'preferences',1,'/portlet_application/jetspeed-layouts/portlets/IngridClearLayout/preferences','2011-11-25 14:03:52','2011-11-25 14:03:52'),(4851,4849,'size',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogHierarchy/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4852,4682,'SearchCatalogThesaurus',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurus','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4772,4771,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4773,4771,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4774,4758,'cmsKey',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/cmsKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4775,4774,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/cmsKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4776,4774,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/cmsKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4777,4682,'IngridWelcomePortlet',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4778,4777,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4779,4778,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4780,4779,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4759,4758,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4760,4759,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4761,4759,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4762,4758,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4763,4762,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(3151,185,'56',0,'/portlet_entity/56','2011-08-30 08:46:44','2011-08-30 08:46:44'),(3152,3151,'guest',0,'/portlet_entity/56/guest','2011-08-30 08:46:44','2011-08-30 08:46:44'),(3153,3152,'preferences',0,'/portlet_entity/56/guest/preferences','2011-08-30 08:46:44','2011-08-30 08:46:44'),(4857,4682,'InfoPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/InfoPortlet','2012-09-20 15:20:18','2012-09-20 15:20:18'),(3156,185,'55',0,'/portlet_entity/55','2011-08-30 08:46:45','2011-08-30 08:46:45'),(3157,3156,'guest',0,'/portlet_entity/55/guest','2011-08-30 08:46:45','2011-08-30 08:46:45'),(3158,3157,'preferences',0,'/portlet_entity/55/guest/preferences','2011-08-30 08:46:45','2011-08-30 08:46:45'),(4567,185,'820',0,'/portlet_entity/820','2011-11-23 08:16:27','2011-11-23 08:16:27'),(4568,4567,'admin',0,'/portlet_entity/820/admin','2011-11-23 08:16:27','2011-11-23 08:16:27'),(4569,4568,'preferences',0,'/portlet_entity/820/admin/preferences','2011-11-23 08:16:27','2011-11-23 08:16:27'),(4570,2379,'admin',0,'/portlet_entity/69/admin','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4571,4570,'preferences',0,'/portlet_entity/69/admin/preferences','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4572,2382,'admin',0,'/portlet_entity/71/admin','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4573,4572,'preferences',0,'/portlet_entity/71/admin/preferences','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4574,2385,'admin',0,'/portlet_entity/68/admin','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4575,4574,'preferences',0,'/portlet_entity/68/admin/preferences','2011-11-23 08:16:49','2011-11-23 08:16:49'),(4576,881,'admin',0,'/portlet_entity/183/admin','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4577,4576,'preferences',0,'/portlet_entity/183/admin/preferences','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4578,884,'admin',0,'/portlet_entity/185/admin','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4579,4578,'preferences',0,'/portlet_entity/185/admin/preferences','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4580,887,'admin',0,'/portlet_entity/182/admin','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4581,4580,'preferences',0,'/portlet_entity/182/admin/preferences','2011-11-23 08:17:58','2011-11-23 08:17:58'),(4582,1041,'admin',0,'/portlet_entity/187/admin','2011-11-23 08:18:00','2011-11-23 08:18:00'),(3585,185,'49',0,'/portlet_entity/49','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3586,3585,'guest',0,'/portlet_entity/49/guest','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3587,3586,'preferences',0,'/portlet_entity/49/guest/preferences','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3588,185,'47',0,'/portlet_entity/47','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3589,3588,'guest',0,'/portlet_entity/47/guest','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3590,3589,'preferences',0,'/portlet_entity/47/guest/preferences','2011-08-31 10:32:33','2011-08-31 10:32:33'),(3595,185,'749',0,'/portlet_entity/749','2011-08-31 10:33:38','2011-08-31 10:33:38'),(3596,3595,'admin',0,'/portlet_entity/749/admin','2011-08-31 10:33:38','2011-08-31 10:33:38'),(3597,3596,'preferences',0,'/portlet_entity/749/admin/preferences','2011-08-31 10:33:38','2011-08-31 10:33:38'),(3598,185,'750',0,'/portlet_entity/750','2011-08-31 10:33:38','2011-08-31 10:33:38'),(3599,3598,'admin',0,'/portlet_entity/750/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3600,3599,'preferences',0,'/portlet_entity/750/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3601,185,'751',0,'/portlet_entity/751','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3602,3601,'admin',0,'/portlet_entity/751/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3603,3602,'preferences',0,'/portlet_entity/751/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3604,185,'752',0,'/portlet_entity/752','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3605,3604,'admin',0,'/portlet_entity/752/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3606,3605,'preferences',0,'/portlet_entity/752/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3607,185,'753',0,'/portlet_entity/753','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3608,3607,'admin',0,'/portlet_entity/753/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3609,3608,'preferences',0,'/portlet_entity/753/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3610,185,'754',0,'/portlet_entity/754','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3611,3610,'admin',0,'/portlet_entity/754/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3612,3611,'preferences',0,'/portlet_entity/754/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3613,185,'755',0,'/portlet_entity/755','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3614,3613,'admin',0,'/portlet_entity/755/admin','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3615,3614,'preferences',0,'/portlet_entity/755/admin/preferences','2011-08-31 10:33:39','2011-08-31 10:33:39'),(3616,185,'766',0,'/portlet_entity/766','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3617,3616,'admin',0,'/portlet_entity/766/admin','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3618,3617,'preferences',0,'/portlet_entity/766/admin/preferences','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3619,185,'767',0,'/portlet_entity/767','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3620,3619,'admin',0,'/portlet_entity/767/admin','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3621,3620,'preferences',0,'/portlet_entity/767/admin/preferences','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3622,185,'768',0,'/portlet_entity/768','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3623,3622,'admin',0,'/portlet_entity/768/admin','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3624,3623,'preferences',0,'/portlet_entity/768/admin/preferences','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3625,633,'admin',0,'/portlet_entity/92/admin','2011-08-31 10:33:46','2011-08-31 10:33:46'),(3626,3625,'preferences',0,'/portlet_entity/92/admin/preferences','2011-08-31 10:33:46','2011-08-31 10:33:46'),(4850,4849,'values',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogHierarchy/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4764,4762,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridInformPortlet/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4647,4642,'IngridOneColumn',1,'/portlet_application/jetspeed-layouts/portlets/IngridOneColumn','2011-11-25 14:03:57','2011-11-25 14:03:57'),(4648,4647,'preferences',1,'/portlet_application/jetspeed-layouts/portlets/IngridOneColumn/preferences','2011-11-25 14:03:57','2011-11-25 14:03:57'),(4862,4861,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalOverviewPortlet/preferences','2012-09-20 15:20:19','2012-09-20 15:20:19'),(4859,4682,'MyPortalLoginPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/MyPortalLoginPortlet','2012-09-20 15:20:18','2012-09-20 15:20:18'),(4799,4795,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4800,4799,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4801,4799,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4802,4795,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4803,4802,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4804,4802,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4805,4795,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4806,4805,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4807,4805,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4808,4682,'MeasuresTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4809,4808,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4810,4809,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4811,4810,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4812,4810,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4813,4809,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4814,4813,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4815,4813,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4816,4809,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4817,4816,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4818,4816,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4819,4809,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4820,4819,'values',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4821,4819,'size',1,'/portlet_application/ingrid-portal-apps/portlets/MeasuresTeaser/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4822,4682,'ChronicleTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4823,4822,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4824,4823,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4825,4824,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4826,4824,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4827,4823,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4828,4827,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4829,4827,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4830,4823,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4831,4830,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4832,4830,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4833,4823,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4834,4833,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/helpKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4835,4833,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleTeaser/preferences/helpKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4836,4682,'WeatherTeaser',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4837,4836,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4838,4837,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4839,4838,'values',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4840,4838,'size',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4841,4837,'default-vertical-position',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/default-vertical-position','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4842,4841,'values',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/default-vertical-position/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4843,4841,'size',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/default-vertical-position/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4844,4837,'titleKey',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/titleKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4845,4844,'values',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/titleKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4846,4844,'size',1,'/portlet_application/ingrid-portal-apps/portlets/WeatherTeaser/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4847,4682,'SearchCatalogHierarchy',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogHierarchy','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4848,4847,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogHierarchy/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4849,4848,'helpKey',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogHierarchy/preferences/helpKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4790,4788,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/titleKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4791,4778,'cmsKey',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/cmsKey','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4792,4791,'values',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/cmsKey/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4793,4791,'size',1,'/portlet_application/ingrid-portal-apps/portlets/IngridWelcomePortlet/preferences/cmsKey/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(3729,185,'126',0,'/portlet_entity/126','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3730,3729,'admin',0,'/portlet_entity/126/admin','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3731,3730,'preferences',0,'/portlet_entity/126/admin/preferences','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3732,185,'124',0,'/portlet_entity/124','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3733,3732,'admin',0,'/portlet_entity/124/admin','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3734,3733,'preferences',0,'/portlet_entity/124/admin/preferences','2011-08-31 10:39:20','2011-08-31 10:39:20'),(3735,185,'120',0,'/portlet_entity/120','2011-08-31 10:39:21','2011-08-31 10:39:21'),(3736,3735,'admin',0,'/portlet_entity/120/admin','2011-08-31 10:39:21','2011-08-31 10:39:21'),(3737,3736,'preferences',0,'/portlet_entity/120/admin/preferences','2011-08-31 10:39:21','2011-08-31 10:39:21'),(3738,185,'137',0,'/portlet_entity/137','2011-08-31 10:39:25','2011-08-31 10:39:25'),(3739,3738,'admin',0,'/portlet_entity/137/admin','2011-08-31 10:39:25','2011-08-31 10:39:25'),(3740,3739,'preferences',0,'/portlet_entity/137/admin/preferences','2011-08-31 10:39:25','2011-08-31 10:39:25'),(3741,185,'132',0,'/portlet_entity/132','2011-08-31 10:39:26','2011-08-31 10:39:26'),(3742,3741,'admin',0,'/portlet_entity/132/admin','2011-08-31 10:39:26','2011-08-31 10:39:26'),(3743,3742,'preferences',0,'/portlet_entity/132/admin/preferences','2011-08-31 10:39:26','2011-08-31 10:39:26'),(3744,185,'98',0,'/portlet_entity/98','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3745,3744,'admin',0,'/portlet_entity/98/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3746,3745,'preferences',0,'/portlet_entity/98/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3747,185,'99',0,'/portlet_entity/99','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3748,3747,'admin',0,'/portlet_entity/99/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3749,3748,'preferences',0,'/portlet_entity/99/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3750,185,'100',0,'/portlet_entity/100','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3751,3750,'admin',0,'/portlet_entity/100/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3752,3751,'preferences',0,'/portlet_entity/100/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3753,185,'101',0,'/portlet_entity/101','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3754,3753,'admin',0,'/portlet_entity/101/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3755,3754,'preferences',0,'/portlet_entity/101/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3756,185,'102',0,'/portlet_entity/102','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3757,3756,'admin',0,'/portlet_entity/102/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3758,3757,'preferences',0,'/portlet_entity/102/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3759,185,'103',0,'/portlet_entity/103','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3760,3759,'admin',0,'/portlet_entity/103/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3761,3760,'preferences',0,'/portlet_entity/103/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3762,185,'104',0,'/portlet_entity/104','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3763,3762,'admin',0,'/portlet_entity/104/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3764,3763,'preferences',0,'/portlet_entity/104/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3765,185,'97',0,'/portlet_entity/97','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3766,3765,'admin',0,'/portlet_entity/97/admin','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3767,3766,'preferences',0,'/portlet_entity/97/admin/preferences','2011-08-31 10:44:43','2011-08-31 10:44:43'),(3768,2249,'admin',0,'/portlet_entity/54/admin','2011-08-31 10:45:27','2011-08-31 10:45:27'),(3769,3768,'preferences',0,'/portlet_entity/54/admin/preferences','2011-08-31 10:45:27','2011-08-31 10:45:27'),(3770,2252,'admin',0,'/portlet_entity/53/admin','2011-08-31 10:45:27','2011-08-31 10:45:27'),(3771,3770,'preferences',0,'/portlet_entity/53/admin/preferences','2011-08-31 10:45:27','2011-08-31 10:45:27'),(3781,361,'admin',0,'/portlet_entity/29/admin','2011-08-31 12:35:09','2011-08-31 12:35:09'),(3782,3781,'preferences',0,'/portlet_entity/29/admin/preferences','2011-08-31 12:35:09','2011-08-31 12:35:09'),(3783,364,'admin',0,'/portlet_entity/26/admin','2011-08-31 12:35:09','2011-08-31 12:35:09'),(3784,3783,'preferences',0,'/portlet_entity/26/admin/preferences','2011-08-31 12:35:09','2011-08-31 12:35:09'),(3785,2281,'admin',0,'/portlet_entity/801/admin','2011-08-31 12:55:30','2011-08-31 12:55:30'),(3786,3785,'preferences',0,'/portlet_entity/801/admin/preferences','2011-08-31 12:55:30','2011-08-31 12:55:30'),(3787,2286,'admin',0,'/portlet_entity/800/admin','2011-08-31 12:55:30','2011-08-31 12:55:30'),(3788,3787,'preferences',0,'/portlet_entity/800/admin/preferences','2011-08-31 12:55:30','2011-08-31 12:55:30'),(3801,621,'admin',0,'/portlet_entity/14/admin','2011-09-06 09:26:47','2011-09-06 09:26:47'),(3802,3801,'preferences',0,'/portlet_entity/14/admin/preferences','2011-09-06 09:26:47','2011-09-06 09:26:47'),(3821,2281,'mdek',0,'/portlet_entity/801/mdek','2011-09-13 12:57:41','2011-09-13 12:57:41'),(3822,3821,'preferences',0,'/portlet_entity/801/mdek/preferences','2011-09-13 12:57:41','2011-09-13 12:57:41'),(3823,2286,'mdek',0,'/portlet_entity/800/mdek','2011-09-13 12:57:41','2011-09-13 12:57:41'),(3824,3823,'preferences',0,'/portlet_entity/800/mdek/preferences','2011-09-13 12:57:41','2011-09-13 12:57:41'),(4795,4794,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4796,4795,'portlet-type',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/portlet-type','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4797,4796,'values',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/portlet-type/values','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4798,4796,'size',1,'/portlet_application/ingrid-portal-apps/portlets/ServiceTeaser/preferences/portlet-type/size','2012-09-20 15:20:07','2012-09-20 15:20:07'),(4863,4682,'AdminCMSPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/AdminCMSPortlet','2012-09-20 15:59:00','2012-09-20 15:59:00'),(4864,4863,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/AdminCMSPortlet/preferences','2012-09-20 15:59:00','2012-09-20 15:59:00'),(4865,4682,'AdminUserPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/AdminUserPortlet','2012-09-20 15:59:01','2012-09-20 15:59:01'),(4866,4865,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/AdminUserPortlet/preferences','2012-09-20 15:59:01','2012-09-20 15:59:01'),(4867,4682,'AdminUserMigrationPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/AdminUserMigrationPortlet','2012-09-20 15:59:01','2012-09-20 15:59:01'),(4868,4867,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/AdminUserMigrationPortlet/preferences','2012-09-20 15:59:01','2012-09-20 15:59:01'),(4869,9,'qa',0,'/user/qa','2012-09-20 15:59:02','2012-09-20 15:59:02'),(4870,4869,'userinfo',0,'/user/qa/userinfo','2012-09-20 15:59:02','2012-09-20 15:59:02'),(4871,9,'noqa',0,'/user/noqa','2012-09-20 15:59:04','2012-09-20 15:59:04'),(4872,4871,'userinfo',0,'/user/noqa/userinfo','2012-09-20 15:59:04','2012-09-20 15:59:04'),(4873,4682,'AdminIPlugPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/AdminIPlugPortlet','2012-09-20 15:59:53','2012-09-20 15:59:53'),(4874,4873,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/AdminIPlugPortlet/preferences','2012-09-20 15:59:53','2012-09-20 15:59:53'),(4881,4682,'ShowFeaturesPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/ShowFeaturesPortlet','2012-10-01 11:37:39','2012-10-01 11:37:39'),(4882,4881,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ShowFeaturesPortlet/preferences','2012-10-01 11:37:39','2012-10-01 11:37:39'),(4901,4682,'AdminComponentMonitorPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/AdminComponentMonitorPortlet','2012-10-01 16:05:19','2012-10-01 16:05:19'),(4902,4901,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/AdminComponentMonitorPortlet/preferences','2012-10-01 16:05:19','2012-10-01 16:05:19'),(4903,4682,'ContentRSSPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/ContentRSSPortlet','2012-10-01 16:15:26','2012-10-01 16:15:26'),(4904,4903,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ContentRSSPortlet/preferences','2012-10-01 16:15:26','2012-10-01 16:15:26'),(4921,4682,'ShowMapsPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/ShowMapsPortlet','2012-10-04 08:51:25','2012-10-04 08:51:25'),(4922,4921,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ShowMapsPortlet/preferences','2012-10-04 08:51:25','2012-10-04 08:51:25'),(4941,4682,'SaveMapsPortlet',1,'/portlet_application/ingrid-portal-apps/portlets/SaveMapsPortlet','2012-10-04 09:03:05','2012-10-04 09:03:05'),(4942,4941,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/SaveMapsPortlet/preferences','2012-10-04 09:03:05','2012-10-04 09:03:05'),(4961,185,'9931',0,'/portlet_entity/9931','2014-04-09 00:53:12','2014-04-09 00:53:12'),(4962,4961,'guest',0,'/portlet_entity/9931/guest','2014-04-09 00:53:12','2014-04-09 00:53:12'),(4963,4962,'preferences',0,'/portlet_entity/9931/guest/preferences','2014-04-09 00:53:12','2014-04-09 00:53:12'),(4964,4682,'ChronicleSearch',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleSearch','2014-04-09 01:28:30','2014-04-09 01:28:30'),(4965,4964,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/ChronicleSearch/preferences','2014-04-09 01:28:30','2014-04-09 01:28:30'),(4966,4682,'SearchCatalogThesaurusResult',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurusResult','2014-04-09 01:29:04','2014-04-09 01:29:04'),(4967,4966,'preferences',1,'/portlet_application/ingrid-portal-apps/portlets/SearchCatalogThesaurusResult/preferences','2014-04-09 01:29:04','2014-04-09 01:29:04');
/*!40000 ALTER TABLE `prefs_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefs_property_value`
--

DROP TABLE IF EXISTS `prefs_property_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prefs_property_value` (
  `PROPERTY_VALUE_ID` mediumint(9) NOT NULL,
  `NODE_ID` mediumint(9) DEFAULT NULL,
  `PROPERTY_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PROPERTY_VALUE` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CREATION_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODIFIED_DATE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`PROPERTY_VALUE_ID`),
  KEY `NODE_ID` (`NODE_ID`),
  KEY `PROPERTY_NAME` (`PROPERTY_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefs_property_value`
--

LOCK TABLES `prefs_property_value` WRITE;
/*!40000 ALTER TABLE `prefs_property_value` DISABLE KEYS */;
INSERT INTO `prefs_property_value` VALUES (1,11,'user.name.given','System','2007-06-08 13:57:08','2007-06-08 13:57:08'),(2,11,'user.name.family','Administrator','2007-06-08 13:57:08','2007-06-08 13:57:08'),(3,15,'user.name.given','Dev','2007-06-08 13:57:08','2007-06-08 13:57:08'),(4,15,'user.name.family','Manager','2007-06-08 13:57:08','2007-06-08 13:57:08'),(2339,4800,'0','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2286,4742,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2287,4741,'0','2','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2285,4737,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2283,4739,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2284,4738,'0','ingrid-home','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2264,4712,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2265,4717,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2266,4716,'0','searchSimple.title.search','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2267,4715,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2268,4720,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2269,4719,'0','search-1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2270,4718,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2271,4725,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2272,4724,'0','ingrid-home','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2273,4723,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2274,4728,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2275,4727,'0','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2276,4726,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2277,4731,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2278,4730,'0','teaser.environment.title','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2279,4729,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2280,4734,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2281,4733,'0','search-topics-1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2282,4732,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(232,562,'user.custom.ingrid.user.confirmid','b213b30ed57e5744e904fc0c82e11bec','2011-03-01 17:29:32','2011-03-01 17:29:32'),(231,562,'user.business-info.postal.postalcode','','2011-03-01 17:29:32','2011-03-01 17:29:32'),(230,562,'user.name.given','mdek','2011-03-01 17:29:32','2011-03-01 17:29:32'),(228,562,'user.custom.ingrid.user.profession','0','2011-03-01 17:29:32','2011-03-01 17:29:32'),(229,562,'user.name.prefix','0','2011-03-01 17:29:32','2011-03-01 17:29:32'),(227,562,'user.business-info.postal.city','','2011-03-01 17:29:32','2011-03-01 17:29:32'),(226,562,'user.custom.ingrid.user.age.group','0','2011-03-01 17:29:32','2011-03-01 17:29:32'),(225,562,'user.business-info.postal.street','','2011-03-01 17:29:32','2011-03-01 17:29:32'),(224,562,'user.custom.ingrid.user.attention.from','','2011-03-01 17:29:32','2011-03-01 17:29:32'),(223,562,'user.custom.ingrid.user.subscribe.newsletter','','2011-03-01 17:29:32','2011-03-01 17:29:32'),(222,562,'user.custom.ingrid.user.interest','0','2011-03-01 17:29:32','2011-03-01 17:29:32'),(221,562,'user.name.family','mdek','2011-03-01 17:29:32','2011-03-01 17:29:32'),(273,570,'user.name.family','user2','2011-03-01 18:04:23','2011-03-01 18:04:23'),(274,570,'user.custom.ingrid.user.interest','0','2011-03-01 18:04:23','2011-03-01 18:04:23'),(275,570,'user.custom.ingrid.user.subscribe.newsletter','','2011-03-01 18:04:23','2011-03-01 18:04:23'),(276,570,'user.custom.ingrid.user.attention.from','','2011-03-01 18:04:23','2011-03-01 18:04:23'),(277,570,'user.business-info.postal.street','','2011-03-01 18:04:23','2011-03-01 18:04:23'),(278,570,'user.custom.ingrid.user.age.group','0','2011-03-01 18:04:23','2011-03-01 18:04:23'),(279,570,'user.business-info.postal.city','','2011-03-01 18:04:23','2011-03-01 18:04:23'),(280,570,'user.custom.ingrid.user.profession','0','2011-03-01 18:04:23','2011-03-01 18:04:23'),(281,570,'user.name.prefix','0','2011-03-01 18:04:23','2011-03-01 18:04:23'),(282,570,'user.name.given','user2','2011-03-01 18:04:23','2011-03-01 18:04:23'),(283,570,'user.business-info.postal.postalcode','','2011-03-01 18:04:23','2011-03-01 18:04:23'),(233,562,'user.business-info.online.email','mdek@a.aa','2011-03-01 17:29:32','2011-03-01 17:29:32'),(272,568,'user.business-info.online.email','a@a.a','2011-03-01 18:03:56','2011-03-01 18:03:56'),(271,568,'user.custom.ingrid.user.confirmid','5e90f3819119980c462bfe935a91e3b3','2011-03-01 18:03:56','2011-03-01 18:03:56'),(270,568,'user.business-info.postal.postalcode','','2011-03-01 18:03:56','2011-03-01 18:03:56'),(269,568,'user.name.given','user1','2011-03-01 18:03:56','2011-03-01 18:03:56'),(268,568,'user.name.prefix','0','2011-03-01 18:03:56','2011-03-01 18:03:56'),(267,568,'user.custom.ingrid.user.profession','0','2011-03-01 18:03:56','2011-03-01 18:03:56'),(266,568,'user.business-info.postal.city','','2011-03-01 18:03:56','2011-03-01 18:03:56'),(265,568,'user.custom.ingrid.user.age.group','0','2011-03-01 18:03:56','2011-03-01 18:03:56'),(264,568,'user.business-info.postal.street','','2011-03-01 18:03:56','2011-03-01 18:03:56'),(263,568,'user.custom.ingrid.user.attention.from','','2011-03-01 18:03:56','2011-03-01 18:03:56'),(262,568,'user.custom.ingrid.user.subscribe.newsletter','','2011-03-01 18:03:56','2011-03-01 18:03:56'),(261,568,'user.custom.ingrid.user.interest','0','2011-03-01 18:03:56','2011-03-01 18:03:56'),(260,568,'user.name.family','user1','2011-03-01 18:03:56','2011-03-01 18:03:56'),(284,570,'user.custom.ingrid.user.confirmid','71067a6ba61853443820a4c054b6e26e','2011-03-01 18:04:23','2011-03-01 18:04:23'),(285,570,'user.business-info.online.email','a@a.a','2011-03-01 18:04:23','2011-03-01 18:04:23'),(2338,4801,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2337,4796,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2335,4798,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2336,4797,'0','ingrid-home-marginal','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2332,4793,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2333,4792,'0','ingrid.home.welcome','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2334,4791,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2331,4788,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2328,4785,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2329,4790,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2330,4789,'0','ingrid.home.welcome.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2327,4786,'0','/WEB-INF/templates/default_cms.vm','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2326,4787,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2325,4782,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2323,4784,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2324,4783,'0','3','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2322,4779,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2321,4780,'0','ingrid-home','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2318,4774,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2319,4769,'0','ingrid-inform-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2320,4781,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2317,4775,'0','portalu.teaser.inform','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2316,4776,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2315,4771,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2313,4773,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2314,4772,'0','teaser.ingridInform.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2303,4759,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2304,4764,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2305,4763,'0','0','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2306,4762,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2307,4767,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2308,4766,'0','/WEB-INF/templates/default_cms.vm','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2309,4765,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2310,4770,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2311,4769,'0','ingrid-inform-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2312,4768,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2301,4761,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2302,4760,'0','ingrid-home-marginal','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2300,4754,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2299,4755,'0','portalu.cms.default','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2298,4756,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2297,4749,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2288,4740,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2289,4745,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2290,4744,'0','news.teaser.title','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2291,4743,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2292,4748,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2293,4747,'0','rss-news-1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2294,4746,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2295,4751,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2296,4750,'0','4','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2263,4713,'0','0','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2241,4687,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2242,4686,'0','/WEB-INF/templates/myportal/myportal_navigation.vm','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2243,4685,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2244,4690,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2245,4689,'0','myPortal.info.navigation.title','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2246,4688,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2247,4695,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2248,4694,'0','/WEB-INF/templates/newsletter_teaser.vm','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2249,4693,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2250,4698,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2251,4697,'0','teaser.newsletter.title','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2252,4696,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2253,4703,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2254,4702,'0','/WEB-INF/templates/myportal/login_teaser.vm','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2255,4701,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2256,4706,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2257,4705,'0','teaser.login.title','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2258,4704,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2259,4711,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2260,4710,'0','ingrid-home','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2261,4709,'read_only','false','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2262,4714,'size','1','2012-09-20 15:20:06','2012-09-20 15:20:06'),(2340,4799,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2341,4804,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2342,4803,'0','teaser.service.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2343,4802,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2344,4807,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2345,4806,'0','search-service-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2346,4805,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2347,4812,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2348,4811,'0','ingrid-home-marginal','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2349,4810,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2350,4815,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2351,4814,'0','2','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2352,4813,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2353,4818,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2354,4817,'0','teaser.measures.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2355,4816,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2356,4821,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2357,4820,'0','search-measure-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2358,4819,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2359,4826,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2360,4825,'0','ingrid-home-marginal','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2361,4824,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2362,4829,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2363,4828,'0','3','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2364,4827,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2365,4832,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2366,4831,'0','chronicle.teaser.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2367,4830,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2368,4835,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2369,4834,'0','search-chronicle-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2370,4833,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2371,4840,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2372,4839,'0','ingrid-home-marginal','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2373,4838,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2374,4843,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2375,4842,'0','4','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2376,4841,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2377,4846,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2378,4845,'0','teaser.weather.title','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2379,4844,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2380,4851,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2381,4850,'0','search-catalog-1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2382,4849,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2383,4856,'size','1','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2384,4855,'0','search-catalog-2','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2385,4854,'read_only','false','2012-09-20 15:20:07','2012-09-20 15:20:07'),(2386,4870,'user.name.family','qa','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2387,4870,'user.custom.ingrid.user.interest','0','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2388,4870,'user.custom.ingrid.user.subscribe.newsletter','','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2389,4870,'user.custom.ingrid.user.attention.from','','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2390,4870,'user.business-info.postal.street','','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2391,4870,'user.custom.ingrid.user.age.group','0','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2392,4870,'user.business-info.postal.city','','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2393,4870,'user.custom.ingrid.user.profession','0','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2394,4870,'user.name.prefix','0','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2395,4870,'user.name.given','qa','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2396,4870,'user.business-info.postal.postalcode','','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2397,4870,'user.custom.ingrid.user.confirmid','c28950532cff241cad0b625e8fb16cdd','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2398,4870,'user.business-info.online.email','qa@wemove.com','2012-09-20 15:59:02','2012-09-20 15:59:02'),(2399,4872,'user.name.family','noqa','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2400,4872,'user.custom.ingrid.user.interest','0','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2401,4872,'user.custom.ingrid.user.subscribe.newsletter','','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2402,4872,'user.custom.ingrid.user.attention.from','','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2403,4872,'user.business-info.postal.street','','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2404,4872,'user.custom.ingrid.user.age.group','0','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2405,4872,'user.business-info.postal.city','','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2406,4872,'user.custom.ingrid.user.profession','0','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2407,4872,'user.name.prefix','0','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2408,4872,'user.name.given','noqa','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2409,4872,'user.business-info.postal.postalcode','','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2410,4872,'user.custom.ingrid.user.confirmid','70303b197580a27e3f61cf9816e6a1ca','2012-09-20 15:59:04','2012-09-20 15:59:04'),(2411,4872,'user.business-info.online.email','noqa@wemove.com','2012-09-20 15:59:04','2012-09-20 15:59:04');
/*!40000 ALTER TABLE `prefs_property_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `principal_permission`
--

DROP TABLE IF EXISTS `principal_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `principal_permission` (
  `PRINCIPAL_ID` int(11) NOT NULL,
  `PERMISSION_ID` int(11) NOT NULL,
  PRIMARY KEY (`PRINCIPAL_ID`,`PERMISSION_ID`),
  KEY `IX_PRINCIPAL_PERMISSION_1` (`PERMISSION_ID`),
  KEY `IX_PRINCIPAL_PERMISSION_2` (`PRINCIPAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `principal_permission`
--

LOCK TABLES `principal_permission` WRITE;
/*!40000 ALTER TABLE `principal_permission` DISABLE KEYS */;
INSERT INTO `principal_permission` VALUES (3,1),(3,2),(1,3),(3,4),(3,21),(3,22),(3,23),(3,41),(3,61);
/*!40000 ALTER TABLE `principal_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `principal_rule_assoc`
--

DROP TABLE IF EXISTS `principal_rule_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `principal_rule_assoc` (
  `PRINCIPAL_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATOR_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `RULE_ID` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PRINCIPAL_NAME`,`LOCATOR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `principal_rule_assoc`
--

LOCK TABLES `principal_rule_assoc` WRITE;
/*!40000 ALTER TABLE `principal_rule_assoc` DISABLE KEYS */;
INSERT INTO `principal_rule_assoc` VALUES ('admin','page','role-fallback'),('devmgr','page','user-role-fallback'),('guest','page','j2'),('jmeter0','page','user-role-fallback'),('jmeter1','page','user-role-fallback'),('jmeter2','page','user-role-fallback'),('jmeter3','page','user-role-fallback'),('jmeter4','page','user-role-fallback'),('jmeter5','page','user-role-fallback'),('jmeter6','page','user-role-fallback'),('jmeter7','page','user-role-fallback'),('jmeter8','page','user-role-fallback'),('jmeter9','page','user-role-fallback'),('mdek','page','user-role-fallback'),('noqa','page','user-role-fallback'),('qa','page','user-role-fallback'),('user1','page','user-role-fallback'),('user2','page','user-role-fallback');
/*!40000 ALTER TABLE `principal_rule_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processing_event`
--

DROP TABLE IF EXISTS `processing_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processing_event` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processing_event`
--

LOCK TABLES `processing_event` WRITE;
/*!40000 ALTER TABLE `processing_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `processing_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_page_assoc`
--

DROP TABLE IF EXISTS `profile_page_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_page_assoc` (
  `LOCATOR_HASH` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `PAGE_ID` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LOCATOR_HASH`,`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_page_assoc`
--

LOCK TABLES `profile_page_assoc` WRITE;
/*!40000 ALTER TABLE `profile_page_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_page_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiling_rule`
--

DROP TABLE IF EXISTS `profiling_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiling_rule` (
  `RULE_ID` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TITLE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`RULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiling_rule`
--

LOCK TABLES `profiling_rule` WRITE;
/*!40000 ALTER TABLE `profiling_rule` DISABLE KEYS */;
INSERT INTO `profiling_rule` VALUES ('group-fallback','org.apache.jetspeed.profiler.rules.impl.RoleFallbackProfilingRule','A role based fallback algorithm based on Jetspeed-1 group-based fallback'),('ip-address','org.apache.jetspeed.profiler.rules.impl.StandardProfilingRule','Resolves pages based on the clients remote IP address.'),('j1','org.apache.jetspeed.profiler.rules.impl.StandardProfilingRule','The default profiling rule following the Jetspeed-1 hard-coded profiler fallback algorithm.'),('j2','org.apache.jetspeed.profiler.rules.impl.StandardProfilingRule','The default profiling rule for users and mediatype minus language and country.'),('path','org.apache.jetspeed.profiler.rules.impl.StandardProfilingRule','use a path to locate.'),('role-fallback','org.apache.jetspeed.profiler.rules.impl.RoleFallbackProfilingRule','A role based fallback algorithm based on Jetspeed-1 role-based fallback'),('role-group','org.apache.jetspeed.profiler.rules.impl.RoleFallbackProfilingRule','A role based fallback algorithm that searches all groups and roles for a user'),('security','org.apache.jetspeed.profiler.rules.impl.StandardProfilingRule','The security profiling rule needed for credential change requirements.'),('user-role-fallback','org.apache.jetspeed.profiler.rules.impl.RoleFallbackProfilingRule','A role based fallback algorithm based on Jetspeed-1 role-based fallback'),('user-rolecombo-fallback','org.apache.jetspeed.profiler.rules.impl.RoleFallbackProfilingRule','A role based fallback algorithm based on Jetspeed-1 role-based fallback');
/*!40000 ALTER TABLE `profiling_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_parameter`
--

DROP TABLE IF EXISTS `public_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `public_parameter` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IDENTIFIER` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_parameter`
--

LOCK TABLES `public_parameter` WRITE;
/*!40000 ALTER TABLE `public_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishing_event`
--

DROP TABLE IF EXISTS `publishing_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishing_event` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `LOCAL_PART` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `NAMESPACE` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREFIX` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishing_event`
--

LOCK TABLES `publishing_event` WRITE;
/*!40000 ALTER TABLE `publishing_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `publishing_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_blob_triggers`
--

DROP TABLE IF EXISTS `qrtz_blob_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_blob_triggers` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_blob_triggers`
--

LOCK TABLES `qrtz_blob_triggers` WRITE;
/*!40000 ALTER TABLE `qrtz_blob_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_blob_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_calendars`
--

DROP TABLE IF EXISTS `qrtz_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_calendars` (
  `CALENDAR_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`CALENDAR_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_calendars`
--

LOCK TABLES `qrtz_calendars` WRITE;
/*!40000 ALTER TABLE `qrtz_calendars` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_cron_triggers`
--

DROP TABLE IF EXISTS `qrtz_cron_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_cron_triggers` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CRON_EXPRESSION` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TIME_ZONE_ID` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_cron_triggers`
--

LOCK TABLES `qrtz_cron_triggers` WRITE;
/*!40000 ALTER TABLE `qrtz_cron_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_cron_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_fired_triggers`
--

DROP TABLE IF EXISTS `qrtz_fired_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_fired_triggers` (
  `ENTRY_ID` varchar(95) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `INSTANCE_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_STATEFUL` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ENTRY_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_fired_triggers`
--

LOCK TABLES `qrtz_fired_triggers` WRITE;
/*!40000 ALTER TABLE `qrtz_fired_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_fired_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_job_details`
--

DROP TABLE IF EXISTS `qrtz_job_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_job_details` (
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `IS_DURABLE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `IS_STATEFUL` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_job_details`
--

LOCK TABLES `qrtz_job_details` WRITE;
/*!40000 ALTER TABLE `qrtz_job_details` DISABLE KEYS */;
INSERT INTO `qrtz_job_details` VALUES ('AnniversaryFetcherJob','DEFAULT','job fetching all anniversaries from SNS for tomorrow and store them into DB.','de.ingrid.portal.scheduler.jobs.AnniversaryFetcherJob','0','0','1','0','��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0%component.monitor.general.status.codet\0$component.monitor.general.error.nonet\0*component.monitor.general.event.occurencessr\0java.lang.Integer⠤���8\0I\0valuexr\0java.lang.Number������\0\0xp\0\0\0t\0,component.monitor.general.last.errorfree.runt\02018-04-04 18:26:56t\0#component.monitor.general.timer.numsq\0~\0\n\0\0\0t\0\'component.monitor.general.timer.averagesr\0java.lang.Long;��̏#�\0J\0valuexq\0~\0\0\0\0\0\0\0\0-t\0 component.monitor.general.statussq\0~\0\n\0\0\0\0x\0'),('UpdateCodelistsJob','DEFAULT','A job for updating the codelists from a repository via the management iPlug.','de.ingrid.portal.scheduler.jobs.UpdateCodelistsFromPortalJob','0','0','1','0','��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0%component.monitor.general.status.codet\0\'component.monitor.general.error.no.hitst\0*component.monitor.general.event.occurencessr\0java.lang.Integer⠤���8\0I\0valuexr\0java.lang.Number������\0\0xp\0\0\0t\0,component.monitor.general.last.errorfree.runt\02018-04-04 18:36:55t\0#component.monitor.general.timer.numsq\0~\0\n\0\0\0t\0\'component.monitor.general.timer.averagesr\0java.lang.Long;��̏#�\0J\0valuexq\0~\0\0\0\0\0\0\0\0�t\0 component.monitor.general.statussq\0~\0\n\0\0\0x\0'),('UpgradeClientJob','UPDATE',NULL,'de.ingrid.portal.scheduler.jobs.UpgradeClientJob','0','0','1','0','��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0COMPONENT_TYPESsr\0java.util.HashSet�D�����4\0\0xpw\0\0\0?@\0\0\0\0\0\0xt\0%component.monitor.general.status.codet\0,component.monitor.update.error.not.availablet\0,component.monitor.general.last.errorfree.runt\02012-10-03 16:23:50t\0*component.monitor.general.event.occurencessr\0java.lang.Integer⠤���8\0I\0valuexr\0java.lang.Number������\0\0xp\0\0\0t\0INSTALLED_COMPONENTSsr\0java.util.ArrayListx����a�\0I\0sizexp\0\0\0w\0\0\0\nsr\0.de.ingrid.portal.upgradeclient.IngridComponentXs�M(�n�\0Z\0hasBeenSentZ\0isIPlugZ\0\nwasUnknownL\0\rchangelogLinkt\0Ljava/lang/String;L\0	connectedq\0~\0L\0downloadLinkq\0~\0L\0	emailSentt\0Ljava/util/Date;L\0emailst\0Ljava/util/List;L\0errorStatusq\0~\0L\0	extraInfoq\0~\0L\0idq\0~\0L\0infoTextq\0~\0L\0nameq\0~\0L\0statusq\0~\0L\0typeq\0~\0L\0versionq\0~\0L\0versionAvailableq\0~\0L\0versionAvailableBuildq\0~\0xp\0\0pt\0(component.update.component.not.availableppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0t\0\rPROVIDER_INFOsq\0~\0\0\0\0w\0\0\0\nt\0Koordinierungsstelle PortalUxt\0PARTNER_INFOsq\0~\0\0\0\0w\0\0\0\nt\0Bundxxt\0/ingrid-group:iplug-g2k-testpt\0\"IPlug G2K wemove ingrid-testservert\0component.update.same.versiont\0	IPLUG_G2Kt\03.2.0 Build:20215ppsq\0~\0\0\0pq\0~\0\Zppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0q\0~\0sq\0~\0\0\0\0w\0\0\0\nq\0~\0xq\0~\0 sq\0~\0\0\0\0w\0\0\0\nq\0~\0\"xxt\0/ingrid-group:iplug-excel-testpt\0$Iplug EXCEL wemove ingrid-testserverq\0~\0%t\0IPLUG_EXCELt\03.2.1 Build:20836ppsq\0~\0\0\0pq\0~\0\Zppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0q\0~\0sq\0~\0\0\0\0w\0\0\0\nq\0~\0xq\0~\0 sq\0~\0\0\0\0w\0\0\0\nq\0~\0\"xxt\0#/ingrid-group:iplug-opensearch-testpt\0)IPlug OPENSEARCH wemove ingrid-testserverq\0~\0%t\0IPLUG_OPENSEARCHt\03.2.0 Build:20261ppsq\0~\0\0pt\0\'component.update.component.is.availableppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0t\0\rPROVIDER_INFOsq\0~\0\0\0\0\0w\0\0\0\nxt\0PARTNER_INFOsq\0~\0\0\0\0\0w\0\0\0\nxxt\0#/ingrid-group:iplug-management-testpt\0)IPlug MANAGEMENT wemove ingrid-testserverq\0~\0%t\0OTHERt\044.0.0 Build:fc82f925b74002210ad838e92718fcac6e9626d8ppsq\0~\0\0\0pq\0~\0\Zppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0q\0~\0sq\0~\0\0\0\0w\0\0\0\nq\0~\0xq\0~\0 sq\0~\0\0\0\0w\0\0\0\nq\0~\0\"xxt\0/ingrid-group:iplug-xml-testpt\0\"IPlug XML wemove ingrid-testserverq\0~\0%t\0	IPLUG_XMLt\03.2.1 Build:20836ppsq\0~\0\0\0pq\0~\0\Zppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0q\0~\0sq\0~\0\0\0\0w\0\0\0\nq\0~\0xq\0~\0 sq\0~\0\0\0\0w\0\0\0\nq\0~\0\"xxt\0)/ingrid-group:iplug-dsc-scripted-igc_testpt\0<IPlug DSC SCRIPTED igc_test OBJEKTE wemove ingrid-testserverq\0~\0%t\0	IPLUG_DSCt\03.2.1 Build:20844ppsq\0~\0\0\0pq\0~\0\Zppsq\0~\0\0\0\0\0w\0\0\0\nxpsq\0~\0?@\0\0\0\0\0w\0\0\0\0\0\0q\0~\0sq\0~\0\0\0\0w\0\0\0\nq\0~\0xq\0~\0 sq\0~\0\0\0\0w\0\0\0\nq\0~\0\"xxt\0/ingrid-group:iplug-sns-testpt\0\"IPlug SNS wemove ingrid-testserverq\0~\0%t\0	IPLUG_SNSt\03.2.0 Build:20207ppxt\0#component.monitor.general.timer.numsq\0~\0\0\0\0�t\0 component.monitor.general.statussq\0~\0\0\0\0t\0\'component.monitor.general.timer.averagesr\0java.lang.Long;��̏#�\0J\0valuexq\0~\0\0\0\0\0\0\0\0/x\0'),('RSSFetcherJob','DEFAULT','fetching all RSS feeds in database table ingrid_rss_source. Older entries will be deleted.','de.ingrid.portal.scheduler.jobs.RSSFetcherJob','0','0','1','0','��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0%component.monitor.general.status.codet\0$component.monitor.general.error.nonet\0*component.monitor.general.event.occurencessr\0java.lang.Integer⠤���8\0I\0valuexr\0java.lang.Number������\0\0xp\0\0\0t\0,component.monitor.general.last.errorfree.runt\02018-04-04 18:26:56t\0#component.monitor.general.timer.numsq\0~\0\n\0\0\0t\0\'component.monitor.general.timer.averagesr\0java.lang.Long;��̏#�\0J\0valuexq\0~\0\0\0\0\0\0\0\0t\0 component.monitor.general.statussq\0~\0\n\0\0\0\0x\0');
/*!40000 ALTER TABLE `qrtz_job_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_job_listeners`
--

DROP TABLE IF EXISTS `qrtz_job_listeners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_job_listeners` (
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_LISTENER` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`,`JOB_LISTENER`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_job_listeners`
--

LOCK TABLES `qrtz_job_listeners` WRITE;
/*!40000 ALTER TABLE `qrtz_job_listeners` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_job_listeners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_locks`
--

DROP TABLE IF EXISTS `qrtz_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_locks` (
  `LOCK_NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LOCK_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_locks`
--

LOCK TABLES `qrtz_locks` WRITE;
/*!40000 ALTER TABLE `qrtz_locks` DISABLE KEYS */;
INSERT INTO `qrtz_locks` VALUES ('CALENDAR_ACCESS'),('JOB_ACCESS'),('MISFIRE_ACCESS'),('STATE_ACCESS'),('TRIGGER_ACCESS');
/*!40000 ALTER TABLE `qrtz_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_paused_trigger_grps`
--

DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`TRIGGER_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_paused_trigger_grps`
--

LOCK TABLES `qrtz_paused_trigger_grps` WRITE;
/*!40000 ALTER TABLE `qrtz_paused_trigger_grps` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_paused_trigger_grps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_scheduler_state`
--

DROP TABLE IF EXISTS `qrtz_scheduler_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_scheduler_state` (
  `INSTANCE_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`INSTANCE_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_scheduler_state`
--

LOCK TABLES `qrtz_scheduler_state` WRITE;
/*!40000 ALTER TABLE `qrtz_scheduler_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_scheduler_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_simple_triggers`
--

DROP TABLE IF EXISTS `qrtz_simple_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_simple_triggers` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(7) NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_simple_triggers`
--

LOCK TABLES `qrtz_simple_triggers` WRITE;
/*!40000 ALTER TABLE `qrtz_simple_triggers` DISABLE KEYS */;
INSERT INTO `qrtz_simple_triggers` VALUES ('UpgradeClientJob','UPDATE',-1,86400000,2542),('AnniversaryTrigger','DEFAULT',-1,3600000,1),('UpdateCodelistsTrigger','DEFAULT',-1,300000,8),('RSSFetcherTrigger','DEFAULT',-1,3600000,1);
/*!40000 ALTER TABLE `qrtz_simple_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_trigger_listeners`
--

DROP TABLE IF EXISTS `qrtz_trigger_listeners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_trigger_listeners` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_LISTENER` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_LISTENER`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_trigger_listeners`
--

LOCK TABLES `qrtz_trigger_listeners` WRITE;
/*!40000 ALTER TABLE `qrtz_trigger_listeners` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_trigger_listeners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtz_triggers`
--

DROP TABLE IF EXISTS `qrtz_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_triggers` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_TYPE` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `JOB_NAME` (`JOB_NAME`,`JOB_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtz_triggers`
--

LOCK TABLES `qrtz_triggers` WRITE;
/*!40000 ALTER TABLE `qrtz_triggers` DISABLE KEYS */;
INSERT INTO `qrtz_triggers` VALUES ('AnniversaryTrigger','DEFAULT','AnniversaryFetcherJob','DEFAULT','0',NULL,1522862815121,1522859215121,5,'WAITING','SIMPLE',1522859215121,0,NULL,0,''),('UpgradeClientJob','UPDATE','UpgradeClientJob','UPDATE','0',NULL,1522938229856,1481639029856,5,'WAITING','SIMPLE',1303309429856,0,NULL,0,''),('UpdateCodelistsTrigger','DEFAULT','UpdateCodelistsJob','DEFAULT','0',NULL,1522861615123,1522861315123,5,'WAITING','SIMPLE',1522859215123,0,NULL,0,''),('RSSFetcherTrigger','DEFAULT','RSSFetcherJob','DEFAULT','0',NULL,1522862815120,1522859215120,5,'WAITING','SIMPLE',1522859215120,0,NULL,0,'');
/*!40000 ALTER TABLE `qrtz_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_criterion`
--

DROP TABLE IF EXISTS `rule_criterion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_criterion` (
  `CRITERION_ID` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `RULE_ID` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `FALLBACK_ORDER` int(11) NOT NULL,
  `REQUEST_TYPE` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `COLUMN_VALUE` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FALLBACK_TYPE` int(11) DEFAULT '1',
  PRIMARY KEY (`CRITERION_ID`),
  KEY `IX_RULE_CRITERION_1` (`RULE_ID`),
  KEY `IX_RULE_CRITERION_2` (`RULE_ID`,`FALLBACK_ORDER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_criterion`
--

LOCK TABLES `rule_criterion` WRITE;
/*!40000 ALTER TABLE `rule_criterion` DISABLE KEYS */;
INSERT INTO `rule_criterion` VALUES ('1','group-fallback',0,'group','group',NULL,2),('10','j2',1,'group.role.user','user',NULL,0),('11','j2',2,'mediatype','mediatype',NULL,1),('12','path',0,'path','path','/',0),('13','role-fallback',0,'role','role',NULL,2),('14','role-fallback',1,'path.session','page','default-page',0),('15','role-group',0,'role','role',NULL,2),('16','role-group',1,'navigation','navigation','/',2),('17','role-group',2,'group','group',NULL,2),('18','security',0,'hard.coded','page','/my-account.psml',0),('19','user-role-fallback',0,'user','user',NULL,2),('2','group-fallback',1,'path.session','page','default-page',0),('20','user-role-fallback',1,'navigation','navigation','/',2),('21','user-role-fallback',2,'role','role',NULL,2),('22','user-role-fallback',3,'path.session','page','default-page',1),('23','user-rolecombo-fallback',0,'user','user',NULL,2),('24','user-rolecombo-fallback',1,'navigation','navigation','/',2),('25','user-rolecombo-fallback',2,'rolecombo','role',NULL,2),('26','user-rolecombo-fallback',3,'path.session','page','default-page',1),('3','ip-address',0,'ip','ip',NULL,0),('4','j1',0,'path.session','page','default-page',0),('5','j1',1,'group.role.user','user',NULL,0),('6','j1',2,'mediatype','mediatype',NULL,1),('7','j1',3,'language','language',NULL,1),('8','j1',4,'country','country',NULL,1),('9','j2',0,'path.session','page','default-page',0);
/*!40000 ALTER TABLE `rule_criterion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runtime_option`
--

DROP TABLE IF EXISTS `runtime_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_option` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `OWNER_CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runtime_option`
--

LOCK TABLES `runtime_option` WRITE;
/*!40000 ALTER TABLE `runtime_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `runtime_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runtime_value`
--

DROP TABLE IF EXISTS `runtime_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_value` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `RVALUE` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runtime_value`
--

LOCK TABLES `runtime_value` WRITE;
/*!40000 ALTER TABLE `runtime_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `runtime_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_version` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `schema_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_version`
--

LOCK TABLES `schema_version` WRITE;
/*!40000 ALTER TABLE `schema_version` DISABLE KEYS */;
INSERT INTO `schema_version` VALUES (1,'4.0.1','<< Flyway Baseline >>','BASELINE','<< Flyway Baseline >>',NULL,'root','2017-11-20 13:34:20',0,1),(2,'4.0.2','mysql update','SQL','V4_0_2__mysql_update.sql',1808296311,'root','2017-11-20 13:34:20',21,1),(3,'4.0.2.1','mysql update','SQL','V4_0_2_1__mysql_update.sql',-67484534,'root','2017-11-20 13:34:20',1,1),(4,'4.1.0','mysql update','SQL','V4_1_0__mysql_update.sql',1243853449,'root','2017-11-20 13:34:20',8,1),(5,NULL,'toggleMetadataMenu','SQL','MetadataMenu/R__toggleMetadataMenu.sql',76211824,'root','2017-11-20 13:34:20',0,1),(6,'4.1.6','mysql update','SQL','V4_1_6__mysql_update.sql',-589746862,'root','2018-04-04 16:26:47',1141,1),(7,'4.2.0','mysql update','SQL','V4_2_0__mysql_update.sql',-541047334,'root','2018-04-04 16:26:47',385,1);
/*!40000 ALTER TABLE `schema_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secured_portlet`
--

DROP TABLE IF EXISTS `secured_portlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secured_portlet` (
  `ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secured_portlet`
--

LOCK TABLES `secured_portlet` WRITE;
/*!40000 ALTER TABLE `secured_portlet` DISABLE KEYS */;
/*!40000 ALTER TABLE `secured_portlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_attribute`
--

DROP TABLE IF EXISTS `security_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_attribute` (
  `ATTR_ID` int(11) NOT NULL,
  `PRINCIPAL_ID` int(11) NOT NULL,
  `ATTR_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ATTR_VALUE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ATTR_ID`,`PRINCIPAL_ID`,`ATTR_NAME`),
  KEY `IX_NAME_LOOKUP` (`ATTR_NAME`),
  KEY `IX_PRINCIPAL_ATTR` (`PRINCIPAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_attribute`
--

LOCK TABLES `security_attribute` WRITE;
/*!40000 ALTER TABLE `security_attribute` DISABLE KEYS */;
INSERT INTO `security_attribute` VALUES (1,10,'user.name.family','Administrator'),(2,10,'user.name.given','System'),(3,12,'user.name.family','Manager'),(4,12,'user.name.given','Dev'),(5,13,'user.business-info.online.email','mdek@a.aa'),(6,13,'user.business-info.postal.city',''),(7,13,'user.business-info.postal.postalcode',''),(8,13,'user.business-info.postal.street',''),(9,13,'user.custom.ingrid.user.age.group','0'),(10,13,'user.custom.ingrid.user.attention.from',''),(11,13,'user.custom.ingrid.user.confirmid','b213b30ed57e5744e904fc0c82e11bec'),(12,13,'user.custom.ingrid.user.interest','0'),(13,13,'user.custom.ingrid.user.profession','0'),(14,13,'user.custom.ingrid.user.subscribe.newsletter',''),(15,13,'user.name.family','mdek'),(16,13,'user.name.given','mdek'),(17,13,'user.name.prefix','0'),(18,14,'user.business-info.online.email','a@a.a'),(19,14,'user.business-info.postal.city',''),(20,14,'user.business-info.postal.postalcode',''),(21,14,'user.business-info.postal.street',''),(22,14,'user.custom.ingrid.user.age.group','0'),(23,14,'user.custom.ingrid.user.attention.from',''),(24,14,'user.custom.ingrid.user.confirmid','71067a6ba61853443820a4c054b6e26e'),(25,14,'user.custom.ingrid.user.interest','0'),(26,14,'user.custom.ingrid.user.profession','0'),(27,14,'user.custom.ingrid.user.subscribe.newsletter',''),(28,14,'user.name.family','user2'),(29,14,'user.name.given','user2'),(30,14,'user.name.prefix','0'),(31,15,'user.business-info.online.email','a@a.a'),(32,15,'user.business-info.postal.city',''),(33,15,'user.business-info.postal.postalcode',''),(34,15,'user.business-info.postal.street',''),(35,15,'user.custom.ingrid.user.age.group','0'),(36,15,'user.custom.ingrid.user.attention.from',''),(37,15,'user.custom.ingrid.user.confirmid','5e90f3819119980c462bfe935a91e3b3'),(38,15,'user.custom.ingrid.user.interest','0'),(39,15,'user.custom.ingrid.user.profession','0'),(40,15,'user.custom.ingrid.user.subscribe.newsletter',''),(41,15,'user.name.family','user1'),(42,15,'user.name.given','user1'),(43,15,'user.name.prefix','0'),(44,16,'user.business-info.online.email','qa@wemove.com'),(45,16,'user.business-info.postal.city',''),(46,16,'user.business-info.postal.postalcode',''),(47,16,'user.business-info.postal.street',''),(48,16,'user.custom.ingrid.user.age.group','0'),(49,16,'user.custom.ingrid.user.attention.from',''),(50,16,'user.custom.ingrid.user.confirmid','c28950532cff241cad0b625e8fb16cdd'),(51,16,'user.custom.ingrid.user.interest','0'),(52,16,'user.custom.ingrid.user.profession','0'),(53,16,'user.custom.ingrid.user.subscribe.newsletter',''),(54,16,'user.name.family','qa'),(55,16,'user.name.given','qa'),(56,16,'user.name.prefix','0'),(57,17,'user.business-info.online.email','noqa@wemove.com'),(58,17,'user.business-info.postal.city',''),(59,17,'user.business-info.postal.postalcode',''),(60,17,'user.business-info.postal.street',''),(61,17,'user.custom.ingrid.user.age.group','0'),(62,17,'user.custom.ingrid.user.attention.from',''),(63,17,'user.custom.ingrid.user.confirmid','70303b197580a27e3f61cf9816e6a1ca'),(64,17,'user.custom.ingrid.user.interest','0'),(65,17,'user.custom.ingrid.user.profession','0'),(66,17,'user.custom.ingrid.user.subscribe.newsletter',''),(67,17,'user.name.family','noqa'),(68,17,'user.name.given','noqa'),(69,17,'user.name.prefix','0'),(81,21,'user.name.family','jmeter0'),(82,21,'user.custom.ingrid.user.interest','0'),(83,21,'user.custom.ingrid.user.attention.from',''),(84,21,'user.name.prefix','0'),(85,21,'user.custom.ingrid.user.age.group','0'),(86,21,'user.business-info.postal.street',''),(87,21,'user.business-info.postal.city',''),(88,21,'user.business-info.postal.postalcode',''),(89,21,'user.name.given','jmeter0'),(90,21,'user.custom.ingrid.user.confirmid','a67878e3cfffe592ccfe38dc52215667'),(91,21,'user.custom.ingrid.user.profession','0'),(92,21,'user.business-info.online.email','jmeter0@jmeter0.de'),(93,21,'org.apache.jetspeed.user.subsite','/_user/jmeter0'),(94,22,'user.name.family','jmeter1'),(95,22,'user.custom.ingrid.user.interest','0'),(96,22,'user.custom.ingrid.user.attention.from',''),(97,22,'user.name.prefix','0'),(98,22,'user.custom.ingrid.user.age.group','0'),(99,22,'user.business-info.postal.street',''),(100,22,'user.business-info.postal.city',''),(101,22,'user.business-info.postal.postalcode',''),(102,22,'user.name.given','jmeter1'),(103,22,'user.custom.ingrid.user.confirmid','a83a9a59df8a9dee4d22f739faa19946'),(104,22,'user.custom.ingrid.user.profession','0'),(105,22,'user.business-info.online.email','jmeter1@jmeter1.de'),(106,22,'org.apache.jetspeed.user.subsite','/_user/jmeter1'),(107,23,'user.name.family','jmeter2'),(108,23,'user.custom.ingrid.user.interest','0'),(109,23,'user.custom.ingrid.user.attention.from',''),(110,23,'user.name.prefix','0'),(111,23,'user.custom.ingrid.user.age.group','0'),(112,23,'user.business-info.postal.street',''),(113,23,'user.business-info.postal.city',''),(114,23,'user.business-info.postal.postalcode',''),(115,23,'user.name.given','jmeter2'),(116,23,'user.custom.ingrid.user.confirmid','ba95670214bed5454c33150a28a8549d'),(117,23,'user.custom.ingrid.user.profession','0'),(118,23,'user.business-info.online.email','jmeter2@jmeter2.de'),(119,23,'org.apache.jetspeed.user.subsite','/_user/jmeter2'),(120,24,'user.name.family','jmeter3'),(121,24,'user.custom.ingrid.user.interest','0'),(122,24,'user.custom.ingrid.user.attention.from',''),(123,24,'user.name.prefix','0'),(124,24,'user.custom.ingrid.user.age.group','0'),(125,24,'user.business-info.postal.street',''),(126,24,'user.business-info.postal.city',''),(127,24,'user.business-info.postal.postalcode',''),(128,24,'user.name.given','jmeter3'),(129,24,'user.custom.ingrid.user.confirmid','bd6fd16d0e46834cb0bed0abc8bc33e3'),(130,24,'user.custom.ingrid.user.profession','0'),(131,24,'user.business-info.online.email','jmeter3@jmeter3.de'),(132,24,'org.apache.jetspeed.user.subsite','/_user/jmeter3'),(133,25,'user.name.family','jmeter4'),(134,25,'user.custom.ingrid.user.interest','0'),(135,25,'user.custom.ingrid.user.attention.from',''),(136,25,'user.name.prefix','0'),(137,25,'user.custom.ingrid.user.age.group','0'),(138,25,'user.business-info.postal.street',''),(139,25,'user.business-info.postal.city',''),(140,25,'user.business-info.postal.postalcode',''),(141,25,'user.name.given','jmeter4'),(142,25,'user.custom.ingrid.user.confirmid','d53493efb912adb7c0f2547fbffd0a59'),(143,25,'user.custom.ingrid.user.profession','0'),(144,25,'user.business-info.online.email','jmeter4@jmeter4.de'),(145,25,'org.apache.jetspeed.user.subsite','/_user/jmeter4'),(146,26,'user.name.family','jmeter5'),(147,26,'user.custom.ingrid.user.interest','0'),(148,26,'user.custom.ingrid.user.attention.from',''),(149,26,'user.name.prefix','0'),(150,26,'user.custom.ingrid.user.age.group','0'),(151,26,'user.business-info.postal.street',''),(152,26,'user.business-info.postal.city',''),(153,26,'user.business-info.postal.postalcode',''),(154,26,'user.name.given','jmeter5'),(155,26,'user.custom.ingrid.user.confirmid','6892d22d8e7f70d1a53f4f0dee87ce7f'),(156,26,'user.custom.ingrid.user.profession','0'),(157,26,'user.business-info.online.email','jmeter5@jmeter5.de'),(158,26,'org.apache.jetspeed.user.subsite','/_user/jmeter5'),(159,27,'user.name.family','jmeter6'),(160,27,'user.custom.ingrid.user.interest','0'),(161,27,'user.custom.ingrid.user.attention.from',''),(162,27,'user.name.prefix','0'),(163,27,'user.custom.ingrid.user.age.group','0'),(164,27,'user.business-info.postal.street',''),(165,27,'user.business-info.postal.city',''),(166,27,'user.business-info.postal.postalcode',''),(167,27,'user.name.given','jmeter6'),(168,27,'user.custom.ingrid.user.confirmid','a327c13d112731456a8a39199d81e951'),(169,27,'user.custom.ingrid.user.profession','0'),(170,27,'user.business-info.online.email','jmeter6@jmeter6.de'),(171,27,'org.apache.jetspeed.user.subsite','/_user/jmeter6'),(172,28,'user.name.family','jmeter7'),(173,28,'user.custom.ingrid.user.interest','0'),(174,28,'user.custom.ingrid.user.attention.from',''),(175,28,'user.name.prefix','0'),(176,28,'user.custom.ingrid.user.age.group','0'),(177,28,'user.business-info.postal.street',''),(178,28,'user.business-info.postal.city',''),(179,28,'user.business-info.postal.postalcode',''),(180,28,'user.name.given','jmeter7'),(181,28,'user.custom.ingrid.user.confirmid','d7d3c965f13cbc0451ffcdb8d40fd118'),(182,28,'user.custom.ingrid.user.profession','0'),(183,28,'user.business-info.online.email','jmeter7@jmeter7.de'),(184,28,'org.apache.jetspeed.user.subsite','/_user/jmeter7'),(185,29,'user.name.family','jmeter8'),(186,29,'user.custom.ingrid.user.interest','0'),(187,29,'user.custom.ingrid.user.attention.from',''),(188,29,'user.name.prefix','0'),(189,29,'user.custom.ingrid.user.age.group','0'),(190,29,'user.business-info.postal.street',''),(191,29,'user.business-info.postal.city',''),(192,29,'user.business-info.postal.postalcode',''),(193,29,'user.name.given','jmeter8'),(194,29,'user.custom.ingrid.user.confirmid','04c5ab445fbaa0b6770b7da62cb175a3'),(195,29,'user.custom.ingrid.user.profession','0'),(196,29,'user.business-info.online.email','jmeter8@jmeter8.de'),(197,29,'org.apache.jetspeed.user.subsite','/_user/jmeter8'),(198,30,'user.name.family','jmeter9'),(199,30,'user.custom.ingrid.user.interest','0'),(200,30,'user.custom.ingrid.user.attention.from',''),(201,30,'user.name.prefix','0'),(202,30,'user.custom.ingrid.user.age.group','0'),(203,30,'user.business-info.postal.street',''),(204,30,'user.business-info.postal.city',''),(205,30,'user.business-info.postal.postalcode',''),(206,30,'user.name.given','jmeter9'),(207,30,'user.custom.ingrid.user.confirmid','d3074795a1a25ccdc36e8f8eba5c6cdc'),(208,30,'user.custom.ingrid.user.profession','0'),(209,30,'user.business-info.online.email','jmeter9@jmeter9.de'),(210,30,'org.apache.jetspeed.user.subsite','/_user/jmeter9');
/*!40000 ALTER TABLE `security_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_credential`
--

DROP TABLE IF EXISTS `security_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_credential` (
  `CREDENTIAL_ID` int(11) NOT NULL,
  `PRINCIPAL_ID` int(11) NOT NULL,
  `CREDENTIAL_VALUE` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` smallint(6) NOT NULL,
  `UPDATE_ALLOWED` smallint(6) NOT NULL,
  `IS_STATE_READONLY` smallint(6) NOT NULL,
  `UPDATE_REQUIRED` smallint(6) NOT NULL,
  `IS_ENCODED` smallint(6) NOT NULL,
  `IS_ENABLED` smallint(6) NOT NULL,
  `AUTH_FAILURES` smallint(6) NOT NULL,
  `IS_EXPIRED` smallint(6) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `MODIFIED_DATE` datetime NOT NULL,
  `PREV_AUTH_DATE` datetime DEFAULT NULL,
  `LAST_AUTH_DATE` datetime DEFAULT NULL,
  `EXPIRATION_DATE` date DEFAULT NULL,
  PRIMARY KEY (`CREDENTIAL_ID`),
  KEY `IX_SECURITY_CREDENTIAL_1` (`PRINCIPAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_credential`
--

LOCK TABLES `security_credential` WRITE;
/*!40000 ALTER TABLE `security_credential` DISABLE KEYS */;
INSERT INTO `security_credential` VALUES (1,10,'liiHgKcA1sEBisdWUN9fLEc2gBo=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2018-04-04 18:49:00','2016-12-13 15:31:52','2018-04-04 18:49:00',NULL),(2,12,'BbKbeW83cuCk0x/yyqL+WyKSUxE=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-01-22 16:51:33',NULL,NULL,NULL),(3,13,'8yuD7JPOJCLDwy11EvjxXaoLD3s=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-01-22 16:51:33',NULL,NULL,NULL),(4,14,'sCjez47me34nEYo2HFrDTkCjh54=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-01-22 16:51:33',NULL,NULL,NULL),(5,15,'eyv1fJ+sb9QOBwGzdvQ1+RRwx4g=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-11-05 14:29:35',NULL,'2015-11-05 14:29:35',NULL),(6,16,'0acFjBljQd8NtRoeSAHN1PsZbNg=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-01-22 16:51:33',NULL,NULL,NULL),(7,17,'g+UkG5me7TgwgUc7ii5ZJyfvoNU=',0,1,0,0,1,1,0,0,'2015-01-22 16:51:33','2015-01-22 16:51:33',NULL,NULL,NULL),(21,21,'YMGEBrnGqGWLw1lFxLrtXLSe1ww=',0,1,0,0,1,1,0,0,'2016-12-13 15:34:07','2016-12-13 15:34:07',NULL,NULL,NULL),(22,22,'Hh8dZs39/cbERPcI3+GC9sflv9o=',0,1,0,0,1,1,0,0,'2016-12-13 15:34:25','2016-12-13 15:34:25',NULL,NULL,NULL),(23,23,'cEwp+8IIE1b7Q9g0Ezt14tawkHk=',0,1,0,0,1,1,0,0,'2016-12-13 15:34:54','2016-12-13 15:34:54',NULL,NULL,NULL),(24,24,'oMhx3noO8kAM71r8sm2JCsNCjQk=',0,1,0,0,1,1,0,0,'2016-12-13 15:35:08','2016-12-13 15:35:08',NULL,NULL,NULL),(25,25,'/sjpBn1nmIIcfMIitsoZpVv+GDI=',0,1,0,0,1,1,0,0,'2016-12-13 15:35:20','2016-12-13 15:35:20',NULL,NULL,NULL),(26,26,'c/sDXdi4IMxslLVYa7aA9QPmdeM=',0,1,0,0,1,1,0,0,'2016-12-13 15:35:33','2016-12-13 15:35:33',NULL,NULL,NULL),(27,27,'xB+KRSTZVR9ZJIV/k8kcH7TkhbU=',0,1,0,0,1,1,0,0,'2016-12-13 15:35:46','2016-12-13 15:35:46',NULL,NULL,NULL),(28,28,'npEtsHSF8/fT8VAXTRpXxyhB/hM=',0,1,0,0,1,1,0,0,'2016-12-13 15:35:59','2016-12-13 15:35:59',NULL,NULL,NULL),(29,29,'ouLyaplXJAKKsFBBa/rmW9W/SuQ=',0,1,0,0,1,1,0,0,'2016-12-13 15:36:12','2016-12-13 15:36:12',NULL,NULL,NULL),(30,30,'eL0fetnqL/8gMJzTko10RBAJSfw=',0,1,0,0,1,1,0,0,'2016-12-13 15:36:24','2016-12-13 15:36:24',NULL,NULL,NULL);
/*!40000 ALTER TABLE `security_credential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_domain`
--

DROP TABLE IF EXISTS `security_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_domain` (
  `DOMAIN_ID` int(11) NOT NULL,
  `DOMAIN_NAME` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REMOTE` smallint(6) DEFAULT '0',
  `ENABLED` smallint(6) DEFAULT '1',
  `OWNER_DOMAIN_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`DOMAIN_ID`),
  UNIQUE KEY `UIX_DOMAIN_NAME` (`DOMAIN_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_domain`
--

LOCK TABLES `security_domain` WRITE;
/*!40000 ALTER TABLE `security_domain` DISABLE KEYS */;
INSERT INTO `security_domain` VALUES (1,'[default]',0,1,NULL),(2,'[system]',0,1,NULL);
/*!40000 ALTER TABLE `security_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_group_role`
--

DROP TABLE IF EXISTS `security_group_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_group_role` (
  `GROUP_ID` mediumint(9) NOT NULL,
  `ROLE_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`ROLE_ID`),
  KEY `ROLE_ID` (`ROLE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_group_role`
--

LOCK TABLES `security_group_role` WRITE;
/*!40000 ALTER TABLE `security_group_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_group_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_permission`
--

DROP TABLE IF EXISTS `security_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_permission` (
  `PERMISSION_ID` int(11) NOT NULL,
  `PERMISSION_TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIONS` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PERMISSION_ID`),
  UNIQUE KEY `UIX_SECURITY_PERMISSION` (`PERMISSION_TYPE`,`NAME`,`ACTIONS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_permission`
--

LOCK TABLES `security_permission` WRITE;
/*!40000 ALTER TABLE `security_permission` DISABLE KEYS */;
INSERT INTO `security_permission` VALUES (41,'portlet','ingrid-portal-apps::*','view, edit'),(22,'portlet','ingrid-portal-mdek::*','view, edit'),(3,'portlet','j2-admin::*','view, edit'),(61,'portlet','jetspeed-layouts::*','view, edit');
/*!40000 ALTER TABLE `security_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_principal`
--

DROP TABLE IF EXISTS `security_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_principal` (
  `PRINCIPAL_ID` int(11) NOT NULL,
  `PRINCIPAL_TYPE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `PRINCIPAL_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `IS_MAPPED` smallint(6) NOT NULL,
  `IS_ENABLED` smallint(6) NOT NULL,
  `IS_READONLY` smallint(6) NOT NULL,
  `IS_REMOVABLE` smallint(6) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `MODIFIED_DATE` datetime NOT NULL,
  `DOMAIN_ID` int(11) NOT NULL,
  PRIMARY KEY (`PRINCIPAL_ID`),
  UNIQUE KEY `UIX_SECURITY_PRINCIPAL` (`PRINCIPAL_TYPE`,`PRINCIPAL_NAME`,`DOMAIN_ID`),
  KEY `IX_SECURITY_DOMAIN_1` (`DOMAIN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_principal`
--

LOCK TABLES `security_principal` WRITE;
/*!40000 ALTER TABLE `security_principal` DISABLE KEYS */;
INSERT INTO `security_principal` VALUES (1,'role','admin',1,1,0,1,'2015-01-22 16:51:32','2015-01-22 16:51:32',1),(2,'role','guest',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(3,'role','user',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(4,'role','dev',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(5,'role','devmgr',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(6,'role','admin-portal',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(7,'role','admin-partner',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(8,'role','admin-provider',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(9,'role','mdek',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(10,'user','admin',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(11,'user','guest',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(12,'user','devmgr',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(13,'user','mdek',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(16,'user','qa',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1),(17,'user','noqa',1,1,0,1,'2015-01-22 16:51:33','2015-01-22 16:51:33',1);
/*!40000 ALTER TABLE `security_principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_principal_assoc`
--

DROP TABLE IF EXISTS `security_principal_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_principal_assoc` (
  `ASSOC_NAME` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `FROM_PRINCIPAL_ID` int(11) NOT NULL,
  `TO_PRINCIPAL_ID` int(11) NOT NULL,
  PRIMARY KEY (`ASSOC_NAME`,`FROM_PRINCIPAL_ID`,`TO_PRINCIPAL_ID`),
  KEY `IX_TO_PRINCIPAL_ASSOC_LOOKUP` (`ASSOC_NAME`,`TO_PRINCIPAL_ID`),
  KEY `IX_FROM_PRINCIPAL_ASSOC` (`FROM_PRINCIPAL_ID`),
  KEY `IX_TO_PRINCIPAL_ASSOC` (`TO_PRINCIPAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_principal_assoc`
--

LOCK TABLES `security_principal_assoc` WRITE;
/*!40000 ALTER TABLE `security_principal_assoc` DISABLE KEYS */;
INSERT INTO `security_principal_assoc` VALUES ('isMemberOf',10,1),('isMemberOf',10,3),('isMemberOf',11,2),('isMemberOf',12,3),('isMemberOf',12,4),('isMemberOf',12,5),('isMemberOf',13,3),('isMemberOf',13,9),('isMemberOf',14,3),('isMemberOf',14,9),('isMemberOf',15,3),('isMemberOf',15,9),('isMemberOf',16,3),('isMemberOf',17,3),('isMemberOf',21,3),('isMemberOf',21,9),('isMemberOf',22,3),('isMemberOf',22,9),('isMemberOf',23,3),('isMemberOf',23,9),('isMemberOf',24,3),('isMemberOf',24,9),('isMemberOf',25,3),('isMemberOf',25,9),('isMemberOf',26,3),('isMemberOf',26,9),('isMemberOf',27,3),('isMemberOf',27,9),('isMemberOf',28,3),('isMemberOf',28,9),('isMemberOf',29,3),('isMemberOf',29,9),('isMemberOf',30,3),('isMemberOf',30,9);
/*!40000 ALTER TABLE `security_principal_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_role`
--

DROP TABLE IF EXISTS `security_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_role` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_role`
--

LOCK TABLES `security_role` WRITE;
/*!40000 ALTER TABLE `security_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_role_reference`
--

DROP TABLE IF EXISTS `security_role_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_role_reference` (
  `ID` int(11) NOT NULL,
  `PORTLET_DEFINITION_ID` int(11) NOT NULL,
  `ROLE_NAME` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `ROLE_LINK` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_role_reference`
--

LOCK TABLES `security_role_reference` WRITE;
/*!40000 ALTER TABLE `security_role_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_role_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_user_group`
--

DROP TABLE IF EXISTS `security_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_user_group` (
  `USER_ID` mediumint(9) NOT NULL,
  `GROUP_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`USER_ID`,`GROUP_ID`),
  KEY `GROUP_ID` (`GROUP_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_user_group`
--

LOCK TABLES `security_user_group` WRITE;
/*!40000 ALTER TABLE `security_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_user_role`
--

DROP TABLE IF EXISTS `security_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_user_role` (
  `USER_ID` mediumint(9) NOT NULL,
  `ROLE_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`USER_ID`,`ROLE_ID`),
  KEY `ROLE_ID` (`ROLE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_user_role`
--

LOCK TABLES `security_user_role` WRITE;
/*!40000 ALTER TABLE `security_user_role` DISABLE KEYS */;
INSERT INTO `security_user_role` VALUES (6,1),(6,3),(7,2),(8,3),(8,4),(8,5),(81,3),(81,21),(84,3),(84,21),(85,3),(85,21),(121,3),(122,3);
/*!40000 ALTER TABLE `security_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_cookie`
--

DROP TABLE IF EXISTS `sso_cookie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_cookie` (
  `COOKIE_ID` mediumint(9) NOT NULL,
  `COOKIE` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`COOKIE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_cookie`
--

LOCK TABLES `sso_cookie` WRITE;
/*!40000 ALTER TABLE `sso_cookie` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_cookie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_cookie_to_remote`
--

DROP TABLE IF EXISTS `sso_cookie_to_remote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_cookie_to_remote` (
  `COOKIE_ID` mediumint(9) NOT NULL,
  `REMOTE_PRINCIPAL_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`COOKIE_ID`,`REMOTE_PRINCIPAL_ID`),
  KEY `REMOTE_PRINCIPAL_ID` (`REMOTE_PRINCIPAL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_cookie_to_remote`
--

LOCK TABLES `sso_cookie_to_remote` WRITE;
/*!40000 ALTER TABLE `sso_cookie_to_remote` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_cookie_to_remote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_principal_to_remote`
--

DROP TABLE IF EXISTS `sso_principal_to_remote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_principal_to_remote` (
  `PRINCIPAL_ID` mediumint(9) NOT NULL,
  `REMOTE_PRINCIPAL_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`PRINCIPAL_ID`,`REMOTE_PRINCIPAL_ID`),
  KEY `REMOTE_PRINCIPAL_ID` (`REMOTE_PRINCIPAL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_principal_to_remote`
--

LOCK TABLES `sso_principal_to_remote` WRITE;
/*!40000 ALTER TABLE `sso_principal_to_remote` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_principal_to_remote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_site`
--

DROP TABLE IF EXISTS `sso_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_site` (
  `SITE_ID` int(11) NOT NULL,
  `NAME` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `ALLOW_USER_SET` smallint(6) DEFAULT '0',
  `REQUIRES_CERTIFICATE` smallint(6) DEFAULT '0',
  `CHALLENGE_RESPONSE_AUTH` smallint(6) DEFAULT '0',
  `FORM_AUTH` smallint(6) DEFAULT '0',
  `FORM_USER_FIELD` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORM_PWD_FIELD` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REALM` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DOMAIN_ID` int(11) NOT NULL,
  PRIMARY KEY (`SITE_ID`),
  UNIQUE KEY `UIX_SITE_NAME` (`NAME`),
  UNIQUE KEY `UIX_SITE_URL` (`URL`),
  KEY `IX_SECURITY_DOMAIN_2` (`DOMAIN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_site`
--

LOCK TABLES `sso_site` WRITE;
/*!40000 ALTER TABLE `sso_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_site_to_principals`
--

DROP TABLE IF EXISTS `sso_site_to_principals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_site_to_principals` (
  `SITE_ID` mediumint(9) NOT NULL,
  `PRINCIPAL_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`SITE_ID`,`PRINCIPAL_ID`),
  KEY `PRINCIPAL_ID` (`PRINCIPAL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_site_to_principals`
--

LOCK TABLES `sso_site_to_principals` WRITE;
/*!40000 ALTER TABLE `sso_site_to_principals` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_site_to_principals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_site_to_remote`
--

DROP TABLE IF EXISTS `sso_site_to_remote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_site_to_remote` (
  `SITE_ID` mediumint(9) NOT NULL,
  `PRINCIPAL_ID` mediumint(9) NOT NULL,
  PRIMARY KEY (`SITE_ID`,`PRINCIPAL_ID`),
  KEY `PRINCIPAL_ID` (`PRINCIPAL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_site_to_remote`
--

LOCK TABLES `sso_site_to_remote` WRITE;
/*!40000 ALTER TABLE `sso_site_to_remote` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_site_to_remote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_table`
--

DROP TABLE IF EXISTS `tmp_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item_key` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `item_value` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `item_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_table`
--

LOCK TABLES `tmp_table` WRITE;
/*!40000 ALTER TABLE `tmp_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmp_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity` (
  `ACTIVITY` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CATEGORY` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_STAMP` datetime DEFAULT NULL,
  `IPADDRESS` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_VALUE_BEFORE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTR_VALUE_AFTER` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_attribute`
--

DROP TABLE IF EXISTS `user_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_attribute` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_attribute`
--

LOCK TABLES `user_attribute` WRITE;
/*!40000 ALTER TABLE `user_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_attribute_ref`
--

DROP TABLE IF EXISTS `user_attribute_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_attribute_ref` (
  `ID` int(11) NOT NULL,
  `APPLICATION_ID` int(11) NOT NULL,
  `NAME` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME_LINK` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_attribute_ref`
--

LOCK TABLES `user_attribute_ref` WRITE;
/*!40000 ALTER TABLE `user_attribute_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_attribute_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_statistics`
--

DROP TABLE IF EXISTS `user_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_statistics` (
  `IPADDRESS` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_STAMP` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `ELAPSED_TIME` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_statistics`
--

LOCK TABLES `user_statistics` WRITE;
/*!40000 ALTER TABLE `user_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_application`
--

DROP TABLE IF EXISTS `web_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_application` (
  `ID` mediumint(9) NOT NULL,
  `CONTEXT_ROOT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_application`
--

LOCK TABLES `web_application` WRITE;
/*!40000 ALTER TABLE `web_application` DISABLE KEYS */;
INSERT INTO `web_application` VALUES (282,'/ingrid-portal-mdek'),(321,'<portal>'),(341,'/ingrid-portal-apps');
/*!40000 ALTER TABLE `web_application` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-04 17:02:22
